<?php

// This file was auto-generated from sdk-root/src/data/sms/2016-10-24/paginators-1.json
return ['pagination' => ['GetReplicationJobs' => ['input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'replicationJobList',], 'GetReplicationRuns' => ['input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'replicationRunList',], 'GetConnectors' => ['input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'connectorList',], 'GetServers' => ['input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'serverList',],],];
