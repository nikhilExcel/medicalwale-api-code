<?php

// This file was auto-generated from sdk-root/src/data/machinelearning/2014-12-12/paginators-1.json
return ['pagination' => ['DescribeBatchPredictions' => ['limit_key' => 'Limit', 'output_token' => 'NextToken', 'input_token' => 'NextToken', 'result_key' => 'Results',], 'DescribeDataSources' => ['limit_key' => 'Limit', 'output_token' => 'NextToken', 'input_token' => 'NextToken', 'result_key' => 'Results',], 'DescribeEvaluations' => ['limit_key' => 'Limit', 'output_token' => 'NextToken', 'input_token' => 'NextToken', 'result_key' => 'Results',], 'DescribeMLModels' => ['limit_key' => 'Limit', 'output_token' => 'NextToken', 'input_token' => 'NextToken', 'result_key' => 'Results',],],];
