<?php

// This file was auto-generated from sdk-root/src/data/ecr/2015-09-21/paginators-1.json
return ['pagination' => ['DescribeImages' => ['input_token' => 'nextToken', 'limit_key' => 'maxResults', 'output_token' => 'nextToken', 'result_key' => 'imageDetails',], 'DescribeRepositories' => ['input_token' => 'nextToken', 'limit_key' => 'maxResults', 'output_token' => 'nextToken', 'result_key' => 'repositories',], 'ListImages' => ['input_token' => 'nextToken', 'limit_key' => 'maxResults', 'output_token' => 'nextToken', 'result_key' => 'imageIds',],],];
