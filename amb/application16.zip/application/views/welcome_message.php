<div class="vd_content-wrapper">
    <div class="vd_container">
        <h3>Welcome to Win-Win</h3>
    </div>
</div>