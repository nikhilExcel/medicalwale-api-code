<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class HealthrecordModel extends CI_Model {

    var $client_service = "frontend-client";
    var $auth_key = "medicalwalerestapi";

    public function check_auth_client() {
        $client_service = $this->input->get_request_header('Client-Service', TRUE);
        $auth_key = $this->input->get_request_header('Auth-Key', TRUE);
        if ($client_service == $this->client_service && $auth_key == $this->auth_key) {
            return true;
        } else {
            return json_output(401, array('status' => 401, 'message' => 'Unauthorized.'));
        }
    }

    public function auth() {
        date_default_timezone_set('Asia/Kolkata');
        $users_id = $this->input->get_request_header('User-ID', TRUE);
        $token = $this->input->get_request_header('Authorizations', TRUE);
        $q = $this->db->select('expired_at')->from('api_users_authentication')->where('users_id', $users_id)->where('token', $token)->get()->row();
        if ($q == "") {
            return json_output(401, array('status' => 401, 'message' => 'Unauthorized.'));
        } else {
            if ($q->expired_at < date('Y-m-d H:i:s')) {
                return json_output(401, array('status' => 401, 'message' => 'Your session has been expired.'));
            } else {
                $updated_at = date('Y-m-d H:i:s');
                $expired_at = '2030-11-12 08:57:58';
                $this->db->where('users_id', $users_id)->where('token', $token)->update('api_users_authentication', array('expired_at' => $expired_at, 'updated_at' => $updated_at));
                return array('status' => 200, 'message' => 'Authorized.');
            }
        }
    }
    
 
     public function add_folder($user_id,$patient_id,$folder_name,$date) {
        date_default_timezone_set('Asia/Calcutta');
        $created_at = date('Y-m-d');

        $health_record = array(
            'user_id' => $user_id,
            'health_record_id' => $patient_id,
            'folder_name' => $folder_name,
            'date' => $date,
            'created_at' => $created_at
        );
        $this->db->insert('health_record_folder', $health_record);
        $folder_id = $this->db->insert_id();
        return array(
            'status' => 200,
            'message' => 'success',
            'folder_id' => $folder_id
        );
    }
    
     public function health_folder_delete($user_id,$id)
    {
        
      
        $this->db->where('id', $id)->where('user_id',$user_id)->delete('health_record_folder');
        
        return array(
            'status' => 200,
            'message' => 'Health Folder has been deleted.'
        );
    }
    
    
     public function folder_list($health_record_id) {
            //echo "SELECT * FROM health_record WHERE user_id='$user_id' and vendor_type='$vendor_type' order by id desc";
        $query = $this->db->query("SELECT * FROM health_record_folder WHERE health_record_id='$health_record_id' order by id desc");
        $count = $query->num_rows();
        if ($count > 0) {
            foreach ($query->result_array() as $row) {
                $folder_id        = $row['id'];
                $folder_name        = $row['folder_name'];
                $date       = $row['date'];
                $user_id = $row['user_id'];
                $created_at = $row['created_at'];


                        
                $resultpost[] = array(
                    'id' => $folder_id,
                    'user_id'=>$user_id,
                    'folder_name' => $folder_name,
                    'date'=>$date,
                    'created_at'=>$created_at,
                   
                );
            }
        } else {
            $resultpost = array();
        }
        return $resultpost;
    }

    public function add_record($user_id, $patient_name, $relationship, $date_of_birth, $gender) {
        date_default_timezone_set('Asia/Calcutta');
        $created_at = date('Y-m-d');

        $health_record = array(
            'user_id' => $user_id,
            'patient_name' => $patient_name,
            'relationship' => $relationship,
            'date_of_birth' => $date_of_birth,
            'gender' => $gender,
            'created_at' => $created_at
        );
        $this->db->insert('health_record', $health_record);
        $patient_id = $this->db->insert_id();
        return array(
            'status' => 200,
            'message' => 'success',
            'patient_id' => $patient_id
        );
    }
    
    // Family tree function by ghanshyam parihar starts
    public function healthrecord_familytree_list($user_id) {
        //echo "SELECT * FROM health_record WHERE user_id='$user_id' order by id desc";
        $query = $this->db->query("SELECT * FROM health_record WHERE user_id='$user_id' order by id desc");
        $count = $query->num_rows();
        
        $health_record_grandparent = array();
        $health_record_parent = array();
        $health_record_subparent = array();
        $health_record_neighbour = array();
        $health_record_spouse = array();
        $health_record_myself = array();
        $health_record_sibling = array();
        $health_record_child = array();
        
        if ($count > 0) {
            foreach ($query->result_array() as $row) {
                $patient_age        = $row['patient_age'];
                $patient_city       = $row['patient_city'];
                $patient_condition  = $row['patient_condition'];
                
                $health_record_id = $row['id'];
                $user_id = $row['user_id'];
                $patient_name = $row['patient_name'];
                $relationship = $row['relationship'];
                $date_of_birth = $row['date_of_birth'];
                $gender = $row['gender'];
                $created_at = $row['created_at'];

                $query2 = $this->db->query("SELECT id,media,created_at,type FROM health_record_media WHERE health_record_id='$health_record_id' order by created_at desc");
                $count2 = $query2->num_rows();
                if ($count2 > 0) {
                    foreach ($query2->result_array() as $row_media) {
                        $media_id = $row_media['id'];
                        $media = $row_media['media'];
                        $created_at = $row_media['created_at'];
                        $type_ = $row_media['type'];
                        if ($type_ == 'pdf') {
                            $type_ = 'files';
                        } else {
                            $type_ = 'image';
                        }
                        $media_source = 'https://d2c8oti4is0ms3.cloudfront.net/images/health_record_media/' . $type_ . '/' . $media;
                        $health_record_media[] = array(
                            'document_id' => $media_id,
                            'document_link' => $media_source,
                            'document_date' => $created_at
                        );
                    }
                } else {
                    $health_record_media = array();
                }

                if($relationship==='Grand Father' || $relationship==='Grand Mother'){
                    $health_record_grandparent_[] = array(
                            'id' => $health_record_id,
                            'patient_name' => $patient_name,
                            'patient_age'=>$patient_age,
                            'patient_city'=>$patient_city,
                            'patient_condition'=>$patient_condition,
                            'date_of_birth' => $date_of_birth,
                            'relationship' => $relationship,
                            'gender' => $gender,
                            'document_count' => sizeof($health_record_media),
                            'document_list' => $health_record_media,
                            'created_at' => $created_at
                        );
                }
                else{
                    $health_record_grandparent_ = array();
                }
                
                if($relationship==='Mother' || $relationship==='Father'){
                    $health_record_parent_[] = array(
                            'id' => $health_record_id,
                            'patient_name' => $patient_name,
                            'patient_age'=>$patient_age,
                            'patient_city'=>$patient_city,
                            'patient_condition'=>$patient_condition,
                            'date_of_birth' => $date_of_birth,
                            'relationship' => $relationship,
                            'gender' => $gender,
                            'document_count' => sizeof($health_record_media),
                            'document_list' => $health_record_media,
                            'created_at' => $created_at
                        );
                }
                else{
                    $health_record_parent_ = array();
                }
                
                 if($relationship==='Aunty' || $relationship==='Uncle'){
                    $health_record_subparent_[] = array(
                            'id' => $health_record_id,
                            'patient_name' => $patient_name,
                            'patient_age'=>$patient_age,
                            'patient_city'=>$patient_city,
                            'patient_condition'=>$patient_condition,
                            'date_of_birth' => $date_of_birth,
                            'relationship' => $relationship,
                            'gender' => $gender,
                            'document_count' => sizeof($health_record_media),
                            'document_list' => $health_record_media,
                            'created_at' => $created_at
                        );
                }
                else{
                    $health_record_subparent_ = array();
                }
                
                if($relationship==='Friend' || $relationship==='Neighbour'){
                    $health_record_neighbour_[] = array(
                            'id' => $health_record_id,
                            'patient_name' => $patient_name,
                            'patient_age'=>$patient_age,
                            'patient_city'=>$patient_city,
                            'patient_condition'=>$patient_condition,
                            'date_of_birth' => $date_of_birth,
                            'relationship' => $relationship,
                            'gender' => $gender,
                            'document_count' => sizeof($health_record_media),
                            'document_list' => $health_record_media,
                            'created_at' => $created_at
                        );
                }
                else{
                    $health_record_neighbour_ = array();
                }
                
                if($relationship==='Brother' || $relationship==='Sister'){
                    $health_record_sibling_[] = array(
                            'id' => $health_record_id,
                            'patient_name' => $patient_name,
                            'patient_age'=>$patient_age,
                            'patient_city'=>$patient_city,
                            'patient_condition'=>$patient_condition,
                            'date_of_birth' => $date_of_birth,
                            'relationship' => $relationship,
                            'gender' => $gender,
                            'document_count' => sizeof($health_record_media),
                            'document_list' => $health_record_media,
                            'created_at' => $created_at
                        );
                }
                else{
                    $health_record_sibling_ = array();
                }
                
                if($relationship==='Husband' || $relationship==='Wife'){
                    $health_record_spouse_[] = array(
                            'id' => $health_record_id,
                            'patient_name' => $patient_name,
                            'patient_age'=>$patient_age,
                            'patient_city'=>$patient_city,
                            'patient_condition'=>$patient_condition,
                            'date_of_birth' => $date_of_birth,
                            'relationship' => $relationship,
                            'gender' => $gender,
                            'document_count' => sizeof($health_record_media),
                            'document_list' => $health_record_media,
                            'created_at' => $created_at
                        );
                }
                else{
                    $health_record_spouse_ = array();
                }
                
                if($relationship==='Myself'){
                    $health_record_myself_[] = array(
                            'id' => $health_record_id,
                            'patient_name' => $patient_name,
                            'patient_age'=>$patient_age,
                            'patient_city'=>$patient_city,
                            'patient_condition'=>$patient_condition,
                            'date_of_birth' => $date_of_birth,
                            'relationship' => $relationship,
                            'gender' => $gender,
                            'document_count' => sizeof($health_record_media),
                            'document_list' => $health_record_media,
                            'created_at' => $created_at
                        );
                }
                else{
                    $health_record_myself_ = array();
                }
                
                if($relationship==='Son' || $relationship==='Daughter'){
                    $health_record_child_[] = array(
                            'id' => $health_record_id,
                            'patient_name' => $patient_name,
                            'patient_age'=>$patient_age,
                            'patient_city'=>$patient_city,
                            'patient_condition'=>$patient_condition,
                            'date_of_birth' => $date_of_birth,
                            'relationship' => $relationship,
                            'gender' => $gender,
                            'document_count' => sizeof($health_record_media),
                            'document_list' => $health_record_media,
                            'created_at' => $created_at
                        );
                }
                else{
                    $health_record_child_ = array();
                }
                
                if(!empty($health_record_grandparent_)){        
                    $health_record_grandparent = $this->super_unique(array_merge($health_record_grandparent,$health_record_grandparent_),'id');
                }
                if(!empty($health_record_parent_)){        
                    $health_record_parent = $this->super_unique(array_merge($health_record_parent,$health_record_parent_),'id');
                }
                if(!empty($health_record_subparent_)){        
                    $health_record_subparent = $this->super_unique(array_merge($health_record_subparent,$health_record_subparent_),'id');
                }
                if(!empty($health_record_neighbour_)){        
                    $health_record_neighbour = $this->super_unique(array_merge($health_record_neighbour,$health_record_neighbour_),'id');
                }
                if(!empty($health_record_spouse_)){        
                    $health_record_spouse = $this->super_unique(array_merge($health_record_spouse,$health_record_spouse_),'id');
                }
                if(!empty($health_record_myself_)){        
                    $health_record_myself = $this->super_unique(array_merge($health_record_myself,$health_record_myself_),'patient_name');
                }
                if(!empty($health_record_sibling_)){        
                    $health_record_sibling = $this->super_unique(array_merge($health_record_sibling,$health_record_sibling_),'id');
                }
                if(!empty($health_record_child_)){        
                    $health_record_child = $this->super_unique(array_merge($health_record_child,$health_record_child_),'id');
                }
            }
            $resultpost[] = array(
                        'health_record_myself'=>$health_record_myself,
                        'health_record_grandparent' => $health_record_grandparent,
                        'health_record_parent' => $health_record_parent,
                        'health_record_subparent_aunty_uncle' => $health_record_subparent,
                        'health_record_friend_neighbour' => $health_record_neighbour,
                        '$health_record_spouse' => $health_record_spouse,
                        'health_record_sibling'=>$health_record_sibling,
                        'health_record_child'=>$health_record_child
                    );
        } else {
            $resultpost = array();
        }
        return $resultpost;
    }
    // Family tree function by ghanshyam parihar ends 
    
    // Family Tree User details by ghanshyam parihar starts
    public function healthrecord_familytree_user_list($user_id) {
        //echo "SELECT * FROM health_record WHERE user_id='$user_id' and vendor_type='$vendor_type' order by id desc";
        $query = $this->db->query("SELECT * FROM health_record WHERE id='$user_id' order by id desc");
        $count = $query->num_rows();
        if ($count > 0) {
            foreach ($query->result_array() as $row) {

                $patient_age        = $row['patient_age'];
                $patient_city       = $row['patient_city'];
                $patient_condition  = $row['patient_condition'];
                
                $health_record_id = $row['id'];
                $user_id = $row['user_id'];
                $patient_name = $row['patient_name'];
                $relationship = $row['relationship'];
                $date_of_birth = $row['date_of_birth'];
                $gender = $row['gender'];
                $created_at = $row['created_at'];


                $query2 = $this->db->query("SELECT id,media,created_at,type FROM health_record_media WHERE health_record_id='$health_record_id' order by created_at desc");
                $count2 = $query2->num_rows();
                if ($count2 > 0) {
                    foreach ($query2->result_array() as $row_media) {
                        $media_id = $row_media['id'];
                        $media = $row_media['media'];
                        $created_at = $row_media['created_at'];
                        $type_ = $row_media['type'];
                        if ($type_ == 'pdf') {
                            $type_ = 'files';
                        } else {
                            $type_ = 'image';
                        }
                        $media_source = 'https://d2c8oti4is0ms3.cloudfront.net/images/health_record_media/' . $type_ . '/' . $media;
                        $health_record_media[] = array(
                            'document_id' => $media_id,
                            'document_link' => $media_source,
                            'document_date' => $created_at
                        );
                    }
                } else {
                    $health_record_media = array();
                }
                
                   
                        
                $resultpost[] = array(
                    'id' => $health_record_id,
                    'patient_name' => $patient_name,
                    'patient_age'=>$patient_age,
                    'patient_city'=>$patient_city,
                    'patient_condition'=>$patient_condition,
                    'date_of_birth' => $date_of_birth,
                    'relationship' => $relationship,
                    'gender' => $gender,
                    'document_count' => sizeof($health_record_media),
                    'document_list' => $health_record_media,
                    'created_at' => $created_at
                );
                   

                
            }
        } else {
            $resultpost = array();
        }
        return $resultpost;
    }
    // Family Tree User details by ghanshyam parihar ends
    
    public function healthrecord_list($user_id) {
        //echo "SELECT * FROM health_record WHERE user_id='$user_id' and vendor_type='$vendor_type' order by id desc";
        $query = $this->db->query("SELECT * FROM health_record WHERE user_id='$user_id' order by id desc");
        $count = $query->num_rows();
        if ($count > 0) {
            foreach ($query->result_array() as $row) {

                $patient_age        = $row['patient_age'];
                $patient_city       = $row['patient_city'];
                $patient_condition  = $row['patient_condition'];
                
                $health_record_id = $row['id'];
                $user_id = $row['user_id'];
                $patient_name = $row['patient_name'];
                $relationship = $row['relationship'];
                $date_of_birth = $row['date_of_birth'];
                $gender = $row['gender'];
                $created_at = $row['created_at'];


                $query2 = $this->db->query("SELECT id,media,created_at,type FROM health_record_media WHERE health_record_id='$health_record_id' order by created_at desc");
                $count2 = $query2->num_rows();
                if ($count2 > 0) {
                    foreach ($query2->result_array() as $row_media) {
                        $media_id = $row_media['id'];
                        $media = $row_media['media'];
                        $created_at = $row_media['created_at'];
                        $type_ = $row_media['type'];
                        if ($type_ == 'pdf') {
                            $type_ = 'files';
                        } else {
                            $type_ = 'image';
                        }
                        $media_source = 'https://d2c8oti4is0ms3.cloudfront.net/images/health_record_media/' . $type_ . '/' . $media;
                        $health_record_media[] = array(
                            'document_id' => $media_id,
                            'document_link' => $media_source,
                            'document_date' => $created_at
                        );
                    }
                } else {
                    $health_record_media = array();
                }
                
                   
                        
                $resultpost[] = array(
                    'id' => $health_record_id,
                    'patient_name' => $patient_name,
                    'patient_age'=>$patient_age,
                    'patient_city'=>$patient_city,
                    'patient_condition'=>$patient_condition,
                    'date_of_birth' => $date_of_birth,
                    'relationship' => $relationship,
                    'gender' => $gender,
                    'document_count' => sizeof($health_record_media),
                    'document_list' => $health_record_media,
                    'created_at' => $created_at
                );
                   

                
            }
        } else {
            $resultpost = array();
        }
        return $resultpost;
    }
    
    
     public function healthrecord_list_group($user_id) {
        //echo "SELECT * FROM health_record WHERE user_id='$user_id' and vendor_type='$vendor_type' order by id desc";
        $query = $this->db->query("SELECT * FROM health_record WHERE user_id='$user_id' order by id desc");
        $count = $query->num_rows();
        $parents = array();
        $brothers = array();
        $myself = array();
        $friendsandother = array();
        if ($count > 0) {
            foreach ($query->result_array() as $row) {

                $patient_age        = $row['patient_age'];
                $patient_city       = $row['patient_city'];
                $patient_condition  = $row['patient_condition'];
                
                $health_record_id = $row['id'];
                $user_id = $row['user_id'];
                $patient_name = $row['patient_name'];
                $relationship = $row['relationship'];
                $date_of_birth = $row['date_of_birth'];
                $gender = $row['gender'];
                $created_at = $row['created_at'];
                
                   $img_count = $this->db->select('media.id')->from('media')->join('users', 'users.avatar_id=media.id')->where('users.id', $user_id)->get()->num_rows();

                if ($img_count > 0) {
                    $media = $this->db->select('media.source')->from('media')->join('users', 'users.avatar_id=media.id')->where('users.id', $user_id)->get()->row();
                    $img_file = $media->source;
                    $image = 'https://d2c8oti4is0ms3.cloudfront.net/images/healthwall_avatar/' . $img_file;
                   // $image_status = '5';
                } else {
                    $image = 'https://d2c8oti4is0ms3.cloudfront.net/images/img/default_user.jpg';
                  //  $image_status = '0';
                }

                $query2 = $this->db->query("SELECT id,media,created_at,type FROM health_record_media WHERE health_record_id='$health_record_id' order by created_at desc");
                $count2 = $query2->num_rows();
                if ($count2 > 0) {
                    foreach ($query2->result_array() as $row_media) {
                        $media_id = $row_media['id'];
                        $media = $row_media['media'];
                        $created_at = $row_media['created_at'];
                        $type_ = $row_media['type'];
                        if ($type_ == 'pdf') {
                            $type_ = 'files';
                        } else {
                            $type_ = 'image';
                        }
                        $media_source = 'https://d2c8oti4is0ms3.cloudfront.net/images/health_record_media/' . $type_ . '/' . $media;
                        $health_record_media[] = array(
                            'document_id' => $media_id,
                            'document_link' => $media_source,
                            'document_date' => $created_at
                        );
                    }
                } else {
                    $health_record_media = array();
                }
                
                if($relationship == 'father' ||  $relationship == 'mother' || $relationship == 'uncle' || $relationship == 'aunty' || $relationship == 'Father' ||  $relationship == 'Mother' || $relationship == 'Uncle' || $relationship == 'Aunty')   
                        {
                      $parents[]  =    array(
                    'id' => $health_record_id,
                    'patient_name' => $patient_name,
                    'patient_age'=>$patient_age,
                    'image' => $image,
                    'patient_city'=>$patient_city,
                    'patient_condition'=>$patient_condition,
                    'date_of_birth' => $date_of_birth,
                    'relationship' => $relationship,
                    'gender' => $gender,
                    'document_count' => sizeof($health_record_media),
                    'document_list' => $health_record_media,
                    'created_at' => $created_at
                );
                        }
                        else   if($relationship == 'brother' || $relationship == 'sister' || $relationship == 'cousin' || $relationship == 'Brother' || $relationship == 'Sister' || $relationship == 'Cousin')   
                        {
                      $brothers[]  =    array(
                    'id' => $health_record_id,
                    'patient_name' => $patient_name,
                    'patient_age'=>$patient_age,
                    'image' => $image,
                    'patient_city'=>$patient_city,
                    'patient_condition'=>$patient_condition,
                    'date_of_birth' => $date_of_birth,
                    'relationship' => $relationship,
                    'gender' => $gender,
                    'document_count' => sizeof($health_record_media),
                    'document_list' => $health_record_media,
                    'created_at' => $created_at
                );
                        }
                         else   if($relationship == 'myself' || $relationship == 'wife' || $relationship == 'Myself' || $relationship == 'Wife' || $relationship == 'Husband' || $relationship == 'husband' )   
                        {
                      $myself[]  =    array(
                    'id' => $health_record_id,
                    'patient_name' => $patient_name,
                    'patient_age'=>$patient_age,
                    'image' => $image,
                    'patient_city'=>$patient_city,
                    'patient_condition'=>$patient_condition,
                    'date_of_birth' => $date_of_birth,
                    'relationship' => $relationship,
                    'gender' => $gender,
                    'document_count' => sizeof($health_record_media),
                    'document_list' => $health_record_media,
                    'created_at' => $created_at
                );
                        }
                        else
                        {
                             $friendsandother[]  =    array(
                    'id' => $health_record_id,
                    'patient_name' => $patient_name,
                    'patient_age'=>$patient_age,
                    'image' => $image,
                    'patient_city'=>$patient_city,
                    'patient_condition'=>$patient_condition,
                    'date_of_birth' => $date_of_birth,
                    'relationship' => $relationship,
                    'gender' => $gender,
                    'document_count' => sizeof($health_record_media),
                    'document_list' => $health_record_media,
                    'created_at' => $created_at
                );
                        }
                        
            }
            $resultpost[] = array(
                    'parents' => $parents,
                    'brothers' => $brothers,
                    'myself'=>$myself,
                    'friends_others'=>$friendsandother
                );
        } else {
            $resultpost = array();
        }
        return $resultpost;
    }
    
    //added for web for perticular patient details 
    public function healthrecord_details($user_id,$patient_id)
    {
          $query = $this->db->query("SELECT * FROM health_record WHERE user_id='$user_id' and id='$patient_id'order by id desc");
        $count = $query->num_rows();
        if ($count > 0) {
            foreach ($query->result_array() as $row) {

                $patient_age        = $row['patient_age'];
                $patient_city       = $row['patient_city'];
                $patient_condition  = $row['patient_condition'];
                
                $health_record_id = $row['id'];
                $user_id = $row['user_id'];
                $patient_name = $row['patient_name'];
                $relationship = $row['relationship'];
                
                $health_condition   = $row['health_condition'];
                $allergies          = $row['allergies'];
                $heradiatry_problem = $row['heradiatry_problem'];
                
                $date_of_birth = $row['date_of_birth'];
                $gender = $row['gender'];
                $created_at = $row['created_at'];


                $query2 = $this->db->query("SELECT id,media,created_at,type FROM health_record_media WHERE health_record_id='$health_record_id' order by created_at desc");
                $count2 = $query2->num_rows();
                if ($count2 > 0) {
                    foreach ($query2->result_array() as $row_media) {
                        $media_id = $row_media['id'];
                        $media = $row_media['media'];
                        $created_at = $row_media['created_at'];
                        $type_ = $row_media['type'];
                        if ($type_ == 'pdf') {
                            $type_ = 'files';
                        } else {
                            $type_ = 'image';
                        }
                        $media_source = 'https://d2c8oti4is0ms3.cloudfront.net/images/health_record_media/' . $type_ . '/' . $media;
                        $health_record_media[] = array(
                            'document_id' => $media_id,
                            'document_link' => $media_source,
                            'document_date' => $created_at
                        );
                    }
                } else {
                    $health_record_media = array();
                }
                
                   
                        
                $resultpost = array(
                    'id' => $health_record_id,
                    'patient_name' => $patient_name,
                    'patient_age'=>$patient_age,
                    'patient_city'=>$patient_city,
                    'patient_condition'=>$patient_condition,
                    'health_condition'=>$health_condition,
                    'allergies'=>$allergies,
                    'heradiatry_problem'=>$heradiatry_problem,
                    'date_of_birth' => $date_of_birth,
                    'relationship' => $relationship,
                    'gender' => $gender,
                    'document_count' => sizeof($health_record_media),
                    'document_list' => $health_record_media,
                    'created_at' => $created_at
                );
                   

                
            }
        } else {
            $resultpost = array();
        }
        return $resultpost;
    }
    //end 
    
    function super_unique($array,$key)
    {
       $temp_array = [];
       foreach ($array as &$v) {
           if (!isset($temp_array[$v[$key]]))
           $temp_array[$v[$key]] =& $v;
       }
       $array = array_values($temp_array);
       return $array;

    }

    public function health_list_by_date($patient_id) {

        $resultpost = '';
        $query = $this->db->query("SELECT id,media,date,created_at FROM health_record_media WHERE health_record_id='$patient_id' GROUP BY date order by date desc");
        $count = $query->num_rows();
        if ($count > 0) {
            foreach ($query->result_array() as $row_media_) {
                $date = $row_media_['date'];

                $query2 = $this->db->query("SELECT id,media,date,created_at,type FROM health_record_media WHERE date='$date' and health_record_id='$patient_id' order by id desc");
                $health_record_doc = '';
                foreach ($query2->result_array() as $row_media) {
                    $media_id = $row_media['id'];
                    $media = $row_media['media'];
                    $date = $row_media['date'];
                    $created_at = $row_media['created_at'];

                    $type_ = $row_media['type'];
                    if ($type_ == 'pdf') {
                        $type_ = 'files';
                    } else {
                        $type_ = 'image';
                    }
                    $media_source = 'https://d2c8oti4is0ms3.cloudfront.net/images/health_record_media/' . $type_ . '/' . $media;

                    $health_record_doc[] = array(
                        'document_id' => $media_id,
                        'document_link' => $media_source
                    );
                }

                $resultpost[] = array(
                    'document_date' => $date,
                    'document_array' => $health_record_doc,
                    'created_at' => $created_at
                );
            }
        } else {
            $resultpost = array();
        }
        return $resultpost;
    }
    
    public function health_record_delete($user_id,$id)
    {
        $this->db->where('id', $id)->where('user_id',$user_id)->delete('health_record');
        $this->db->where('health_record_id',$id)->delete('health_record_media');
        return array(
            'status' => 200,
            'message' => 'Health record has been deleted.'
        );
    }
    
    public function health_document_delete($user_id,$id,$docmunt_id)
    {
        $document_id_array = explode(',',$docmunt_id);
        // print_r($document_id_array);
        // die();
        foreach($document_id_array as $doc_array)
        {
            
         $this->db->where('health_record_id',$id)->where('id',$doc_array)->delete('health_record_media');
        }
        return array(
            'status' => 200,
            'message' => 'Health record document has been deleted.'
        );
    }

}
