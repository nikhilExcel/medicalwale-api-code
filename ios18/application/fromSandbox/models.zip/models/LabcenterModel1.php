<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class LabcenterModel1 extends CI_Model
{
    
    
    public function encrypt($str)
    {
        $this->key = hash('MD5', '8655328655mdwale', true);
        $this->iv  = hash('MD5', 'mdwale8655328655', true);
        $module    = mcrypt_module_open(MCRYPT_RIJNDAEL_128, '', MCRYPT_MODE_CBC, '');
        mcrypt_generic_init($module, $this->key, $this->iv);
        $block = mcrypt_get_block_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC);
        $pad   = $block - (strlen($str) % $block);
        $str .= str_repeat(chr($pad), $pad);
        $encrypted = mcrypt_generic($module, $str);
        mcrypt_generic_deinit($module);
        mcrypt_module_close($module);
        return base64_encode($encrypted);
    }
    public function decrypt($str)
    {
        $this->key = hash('MD5', '8655328655mdwale', true);
        $this->iv  = hash('MD5', 'mdwale8655328655', true);
        $module    = mcrypt_module_open(MCRYPT_RIJNDAEL_128, '', MCRYPT_MODE_CBC, '');
        mcrypt_generic_init($module, $this->key, $this->iv);
        $str = mdecrypt_generic($module, base64_decode($str));
        mcrypt_generic_deinit($module);
        mcrypt_module_close($module);
        $slast = ord(substr($str, -1));
        $str   = substr($str, 0, strlen($str) - $slast);
        return $str;
    }
    
    
    // only those tests will come which are present in lab_test_details1 table
    public function lab_tests($user_id){
        $result = $this->db->query("SELECT DISTINCT lt.`id`, lt.`category_id`, lt.`test`, lt.`description` , lt.`description`, lt.`instructions` FROM `lab_all_test1` as lt JOIN `lab_test_details1` as ld ON ( lt.id = ld.test_id )")->result_array();
          return $result;
    }
    
    //you will get all vendors by test id
    public function lab_vendor_by_test($user_id,$test_id,$per_page,$page_no){
            $testInfo = $this->db->query("SELECT * FROM `lab_all_test1` WHERE `id` = '$test_id'")->row_array();
            $testName = $testInfo['test'];
        if(sizeof($testInfo) > 0 ){
            if($per_page == 0 || $page_no == 0){
            $results = $this->db->query("SELECT lt.* FROM `lab_test_details1` as lt join lab_center as lc on (lt.user_id = lc.user_id ) WHERE `test_id` = '$test_id'")->result_array();
            $totalData = sizeof($results);
            
             $per_page = $totalData;
                $page_no = 1;
                $last_page = 1;
            
          } else {
            $offset = $per_page*($page_no - 1);
            $results = $this->db->query("SELECT lt.* FROM `lab_test_details` as lt join lab_center as lc on (lt.user_id = lc.user_id ) WHERE `test_id` = '$test_id' LIMIT $per_page OFFSET $offset")->result_array();
            $totalRowCount = $this->db->query("SELECT count(lt.id) as count FROM `lab_test_details` as lt join lab_center as lc on (lt.user_id = lc.user_id ) WHERE `test_id` = '$test_id'")->row_array();
            
            $totalData = $totalRowCount['count'];
            $last_page = ceil($totalData/$per_page);
        }
            
            foreach($results as $r){
                $vendorId = $r['user_id'];
                $vendorInfo = $this->db->query("SELECT * FROM `lab_center` WHERE `user_id` = '$vendorId'")->row_array();
                if(!empty($vendorInfo)){
                    foreach($vendorInfo as $key => $value){
                       if($key == 'profile_pic' ){
                            $vendorInfo[$key] = 'https://d2c8oti4is0ms3.cloudfront.net/images/healthwall_avatar/'.$vendorInfo['profile_pic'] ;
                        }
                    }
                    $r['vendor_info'] = $vendorInfo;
                } else {
                    $r['vendor_info'] = (object)[];
                }
                $res[] = $r;
            }
            $test['test_name'] = $testName;
            $test['data_count'] = $totalData;
            $test['per_page'] = $per_page;
            $test['current_page'] = $page_no;
            $test['first_page'] = 1;
            $test['last_page'] = $last_page;
            $test['test_available'] = $res;
            
            
        } else {
            $test['test_name'] = "";
            $test['data_count'] = 0;
            $test['per_page'] = 0;
            $test['current_page'] = 0;
            $test['first_page'] = 0;
            $test['last_page'] = 0;
            $test['test_available'] = array();
           
        }    
        return $test;
          
    }
    
    public function lab_test_by_vendor($vendor_id){
        $data = array();
        $data =  $this->db->query("SELECT * FROM `lab_test_details1` WHERE `user_id` = '$vendor_id'")->result_array();
     
        return $data;
    }
}