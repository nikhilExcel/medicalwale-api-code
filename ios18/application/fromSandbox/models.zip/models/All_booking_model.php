<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class All_booking_model extends CI_Model
{
    var $client_service = "frontend-client";
    var $auth_key = "medicalwalerestapi";
    public function check_auth_client()
    {
        $client_service = $this->input->get_request_header('Client-Service', TRUE);
        $auth_key       = $this->input->get_request_header('Auth-Key', TRUE);
        if ($client_service == $this->client_service && $auth_key == $this->auth_key) {
            return true;
        } else {
            return json_output(401, array(
                'status' => 401,
                'message' => 'Unauthorized.'
            ));
        }
    }
    public function auth()
    {
        date_default_timezone_set('Asia/Kolkata');
        $users_id = $this->input->get_request_header('User-ID', TRUE);
        $token    = $this->input->get_request_header('Authorizations', TRUE);
        $q        = $this->db->select('expired_at')->from('api_users_authentication')->where('users_id', $users_id)->where('token', $token)->get()->row();
        if ($q == "") {
            return json_output(401, array(
                'status' => 401,
                'message' => 'Unauthorized.'
            ));
        } else {
            if ($q->expired_at < date('Y-m-d H:i:s')) {
                return json_output(401, array(
                    'status' => 401,
                    'message' => 'Your session has been expired.'
                ));
            } else {
                $updated_at = date('Y-m-d H:i:s');
                $expired_at = '2030-11-12 08:57:58';
                $this->db->where('users_id', $users_id)->where('token', $token)->update('api_users_authentication', array(
                    'expired_at' => $expired_at,
                    'updated_at' => $updated_at
                ));
                return array(
                    'status' => 200,
                    'message' => 'Authorized.'
                );
            }
        }
    }
   
    

    
    
 
    
    
    public function pharmacy_presciption_appointment_listing($user_id )
    {
          
          /*pharmacy prescription Start Here*/
                 $query = $this->db->query("SELECT user_order.*,medical_stores.medical_name FROM user_order LEFT JOIN medical_stores on user_order.listing_id=medical_stores.id WHERE order_type='prescription' AND listing_type='13' AND user_order.user_id='$user_id'");



                $count = $query->num_rows();
                if ($count > 0) {
                    
                       foreach ($query->result_array() as $row) {
              
               
                    $invoice_no = $row['invoice_no'];
                    $order_date = $row['order_date'];
                    $status  = $row['order_status'];
                    $customer_name              = $row['name'];
                    $customer_no                = $row['mobile'];
                    $address1          = $row['address1'];
                    $address2 = $row['address2'];
                    $landmark = $row['landmark'];
                    $pincode = $row['pincode'];
                    $city = $row['city'];
                    $state = $row['state'];
                    $payment_method = $row['payment_method'];
                 
                    $home_delievery_charge = $row['delivery_charge'];
                    $total_discount = $row['order_total'];

                

                $resultpost[] = array(
                    'invoice_no' => $invoice_no,
                    'order_date' => $order_date,
                    'order_status' => $status,
                    'name' => $customer_name,
                    'mobile' => $customer_no,
                    'address1' => $address1,
                    'address2' => $address2,
                    'landmark' => $landmark,
                    'pincode' => $pincode,
                    'city' => $city,
                    'state' => $state,
                    'payment_method' => $payment_method,
                    'delivery_charge' => $home_delievery_charge,
                    'order_total' => $total_discount
                );
            }
                   
                       
                
           
              
             
                } else {
                    $resultpost = array();
                }
                
                
                /*pharmacy Prescription End Here*/
                
                
                /*nursing booking Start Here*/
                $query1 = $this->db->query("SELECT ua.landmark,ua.address1,ua.address2,ua.state as patient_state,ua.city as patient_city,ua.pincode as patient_pincode,ua.name as patient_name,b.*,nas.*,nsb.id as order_id,nsb.user_id as change_user_id,u.name,u.phone,b.id as book,u.id as userid ,nsb.package_amount as amts,na.name as listing_name,na.contact as nursing_contact From nursing_attendant_services nas LEFT JOIN nursing_attendant na ON(nas.user_id=na.user_id) LEFT JOIN booking_master b ON(b.package_id=nas.id) LEFT JOIN users u ON(u.id=b.user_id) LEFT JOIN nursing_booking_details nsb ON(b.booking_id=nsb.booking_id) LEFT JOIN user_address ua ON(ua.user_id=b.user_id) where b.user_id ='$user_id'");
$count1 = $query1->num_rows();
   if ($count1 > 0) {
                    
                       foreach ($query1->result_array() as $row) {
              
               
                    $booking_id = $row['booking_id'];
                    $booking_date = $row['booking_date'];
                    $status  = $row['status'];
                    $user_name  = $row['user_name'];
                    $user_mobile = $row['user_mobile'];
                    $user_gender = $row['user_gender'];
                    $booking_date   = $row['booking_date'];
                    $listing_name   = $row['listing_name'];
                    $nursing_contact   = $row['nursing_contact'];
                    $patient_name   = $row['patient_name'];
                     $address1 = $row['address1'];
                    $address2 = $row['address2'];
                    $landmark = $row['landmark'];
                    $pincode = $row['patient_pincode'];
                    $city = $row['patient_city'];
                    $state = $row['patient_state'];
                    $payment_method = $row['payment_mode'];
                    $service_name = $row['service_name'];
                    $description = $row['description'];
                    $rate = $row['rate'];
                

                $resultpost1[] = array(
                    'booking_id' => $booking_id,
                    'booking_date' => $booking_date,
                    'status' => $status,
                    'user_gender'=>$user_gender,
                    'user_name' => $user_name,
                    'user_mobile' => $user_mobile,
                    'booking_date' => $booking_date,
                    'listing_name' => $listing_name,
                    'nursing_contact' => $nursing_contact,
                    'patient_name' => $patient_name,
                    'address1' => $address1,
                    'address2' => $address2,
                    'landmark' => $landmark,
                    'patient_pincode' => $pincode,
                    'patient_city' => $city,
                    'patient_state' => $state,
                    'payment_mode' => $payment_method,
                    'service_name' => $service_name,
                    'description' => $description,
                    'rate' => $rate,
                );
            }
                   
                       
                
           
              
             
                } else {
                    $resultpost1 = array();
                }
                
                /*Nursing  Booking End Here*/
                
                /*pharmacy general order Start here*/
                   $query2 = $this->db->query("SELECT user_order.cancel_reason,user_order.user_id, user_order.action_by,user_order.is_night_delivery,user_order.order_status,user_order.order_id,user_order.pincode,user_order.delivery_charge,user_order.invoice_no,user_order.order_date,user_order.payment_method,user_order.name, user_order.address1,user_order.address2,user_order.landmark,user_order.city,user_order.state,user_order.mobile, user_order_product.product_name,user_order_product.product_unit,user_order_product.product_unit_value,user_order_product.id,user_order_product.product_img,user_order_product.product_quantity,user_order_product.product_price,user_order_product.product_discount,user_order_product.sub_total,users.name as customer_name FROM user_order LEFT JOIN user_order_product on user_order.order_id=user_order_product.order_id LEFT JOIN users on user_order.user_id=users.id WHERE user_order.user_id='$user_id'");
$count2 = $query2->num_rows();
   if ($count2 > 0) {
                    
                       foreach ($query2->result_array() as $row) {
              
               
                    $invoice_no = $row['invoice_no'];
                    $order_date = $row['order_date'];
                    $status  = $row['order_status'];
                    $user_name  = $row['customer_name'];
                    $user_mobile = $row['mobile'];
                    $address1 = $row['address1'];
                    $landmark = $row['landmark'];
                    $pincode = $row['pincode'];
                    $city = $row['city'];
                    $state = $row['state'];
                    $payment_method = $row['payment_method'];
                    $night_delivery_charge = $row['is_night_delivery'];
                    $product_quantity = $row['product_quantity'];
                    $product_price = $row['product_price'];
                    $product_discount = $row['product_discount'];
                    $delivery_charge   = $row['delivery_charge'];
                    $product_name   = $row['product_name'];
                    $product_id  = $row['id'];
                    $product_unit_value   = $row['product_unit_value'];
                    $product_unit = $row['product_unit'];
                
                $resultpost2[] = array(
                    'invoice_no' => $invoice_no,
                    'order_date' => $order_date,
                    'order_status' => $status,
                    'customer_name'=>$user_name,
                    'mobile' => $user_name,
                    'address1' => $address1,
                    'landmark' => $landmark,
                    'pincode' => $pincode,
                    'city' => $city,
                    'state' => $state,
                    'payment_method' => $payment_method,
                    'is_night_delivery' => $night_delivery_charge,
                    'product_quantity' => $product_quantity,
                    'product_price' => $product_price,
                    'product_discount' => $product_discount,
                    'delivery_charge' => $delivery_charge,
                    'product_name' => $product_name,
                    'id' => $product_id,
                    'product_unit_value' => $product_unit_value,
                    'product_unit' => $product_unit,
                    
                );
            }
                   
                       
                
           
              
             
                } else {
                    $resultpost2 = array();
                } 
                /*pharmacy general Order End Here*/
                
                
                /*fitness booking Start Here*/
                
                $query3 = $this->db->query("select fitness_center_branch.branch_name,business_category.category, fitness_center.center_name, packages.package_name,packages.price, booking_master.id as order_id,booking_master.booking_id,booking_master.user_id as change_user_id, booking_master.user_name, booking_master.user_mobile, booking_master.user_email, booking_master.user_gender, booking_master.listing_id, booking_master.booking_date,booking_master.status FROM booking_master LEFT JOIN fitness_center_branch ON (booking_master.branch_id=fitness_center_branch.id) LEFT JOIN packages ON (booking_master.package_id= packages.id) LEFT JOIN business_category ON (business_category.id = booking_master.category_id) LEFT JOIN fitness_center ON (fitness_center.user_id= booking_master.user_id) WHERE booking_master.user_id = '$user_id'");
                
    $count3 = $query3->num_rows();
   if ($count3 > 0) {
                    
                       foreach ($query3->result_array() as $row) {
              
               
                    $booking_id = $row['booking_id'];
                    $booking_date = $row['booking_date'];
                    $status  = $row['status'];
                    $user_name  = $row['user_name'];
                    $user_mobile = $row['user_mobile'];
                    $user_email = $row['user_email'];
                    $user_gender = $row['user_gender'];
                    $booking_date = $row['booking_date'];
                    $center_name = $row['center_name'];
                    $branch_name = $row['branch_name'];
                    
                $resultpost3[] = array(
                    'booking_id' => $booking_id,
                    'booking_date' => $booking_date,
                    'status' => $status,
                    'user_name' => $user_name,
                    'user_mobile' => $user_mobile,
                    'user_email' => $user_email,
                    'user_gender' => $user_gender,
                    'booking_date' => $booking_date,
                    'center_name'=>$center_name,
                    'branch_name' => $branch_name,
                   
                    
                );
            }
                   
                       
                
           
              
             
                } else {
                    $resultpost3 = array();
                }   
                /*fitness booking end here*/
                
                
                /*labs Booking Start Here*/
                
                
                       $query4 = $this->db->query("SELECT booking_master.*,booking_master.user_id as change_user_id,booking_master.id as book_id,lab_booking_details.* FROM booking_master INNER join lab_booking_details on(booking_master.booking_id=lab_booking_details.booking_id) where booking_master.vendor_id='10' And booking_master.user_id = '$user_id'");
                       
              
                
    $count4 = $query4->num_rows();
   if ($count4 > 0) {
                    
                       foreach ($query4->result_array() as $row) {
              
               
                    $booking_id = $row['booking_id'];
                    $booking_date = $row['booking_date'];
                    $status  = $row['status'];
                    $user_name  = $row['user_name'];
                    $user_mobile = $row['user_mobile'];
                    $user_email = $row['user_email'];
                    $user_gender = $row['user_gender'];
                   
                    $branch_name = $row['branch_name'];
                    $mobile_no = $row['mobile_no'];
                    $address1 = $row['address_line1'];
                    $address2 = $row['address_line2'];
                   /* $landmark = $row['landmark'];*/
                    $pincode = $row['pincode'];
                    $city = $row['city'];
                    $state = $row['state'];
                    $payment_mode = $row['payment_mode'];
                
                
                $resultpost4[] = array(
                    'booking_id' => $booking_id,
                    'booking_date' => $booking_date,
                    'status' => $status,
                    'user_name' => $user_name,
                    'user_mobile' => $user_mobile,
                    'user_email' => $user_email,
                    'user_gender' => $user_gender,
                    'branch_name' => $branch_name,
                    'address_line1' => $address1,
                    'address_line2' => $address2,
                   
                    'pincode' => $pincode,
                    'city' => $city,
                    'state' => $state,
                    'payment_mode' => $payment_mode,
                   
                    
                );
            }
                   
                       
                
           
              
             
                } else {
                    $resultpost4 = array();
                }
                /*labs Booking End Here*/
                
                /*Tyrocare Booking Start Here  */
                      
                       $query5 = $this->db->query("SELECT booking_master.*,booking_master.id as book_id,booking_master.user_id as change_user_id,lab_booking_details.* FROM booking_master INNER join lab_booking_details on(booking_master.booking_id=lab_booking_details.booking_id) where booking_master.vendor_id='31' And booking_master.user_id = '$user_id'");
                       
              
                
    $count5 = $query5->num_rows();
   if ($count5 > 0) {
                    
                       foreach ($query5->result_array() as $row) {
              
               
                    $booking_id = $row['booking_id'];
                    $booking_date = $row['booking_date'];
                    $status  = $row['status'];
                    $user_name  = $row['user_name'];
                    $user_mobile = $row['user_mobile'];
                    $user_gender = $row['user_gender'];
                    $branch_name = $row['branch_name'];
                    $mobile_no = $row['mobile_no'];
                    $address1 = $row['address_line1'];
                    $address2 = $row['address_line2'];
                    $pincode = $row['pincode'];
                    $city = $row['city'];
                    $state = $row['state'];
                    $payment_mode = $row['payment_mode'];
                
                
                $resultpost5[] = array(
                    'booking_id' => $booking_id,
                    'booking_date' => $booking_date,
                    'status' => $status,
                    'user_name' => $user_name,
                    'user_mobile' => $user_mobile,
                    'user_email' => $user_email,
                    'user_gender' => $user_gender,
                    'branch_name' => $branch_name,
                    'address_line1' => $address1,
                    'address_line2' => $address2,
                    'pincode' => $pincode,
                    'city' => $city,
                    'state' => $state,
                    'payment_mode' => $payment_mode,
                   
                    
                );
            }
                   
            
             
                } else {
                    $resultpost5 = array();
                }
                
                
                /*Tyrocare Booking End Here  */
                
                
                
                /* Hospital Surgery booking Start*/
                
             $query6 = $this->db->query("SELECT packages.*, u.name, u.phone, u.email, u.gender, u.age, u.height, u.weight, u.exercise_level, u.diet_fitness, u.health_condition, u.dob, u.blood_group, u.bmi,booking_master.package_id,booking_master.status,booking_master.booking_id,booking_master.id as book_id, booking_master.listing_id, booking_master.user_id as change_user_id, booking_master.user_name, booking_master.user_mobile, booking_master.user_email, booking_master.user_gender, booking_master.branch_id, booking_master.vendor_id, booking_master.booking_date, booking_master.category_id, booking_master.trail_booking_date, booking_master.trail_booking_time, booking_master.joining_date FROM booking_master
               INNER JOIN hospital_packages as packages ON           (booking_master.package_id=packages.id) 
               INNER JOIN users as u ON( booking_master.user_id=u.id)
               WHERE booking_master.user_id='$user_id' AND booking_master.vendor_id='8'");
                       
              
                
    $count6 = $query6->num_rows();
   if ($count6 > 0) {
                    
                       foreach ($query6->result_array() as $row) {
              
               
                    $booking_id = $row['booking_id'];
                    
                     $query7 = $this->db->query("SELECT hospital_booking_details.*,hospital_wards.*,users.* from hospital_booking_details inner join hospital_wards on (hospital_booking_details.ward_id=hospital_wards.id) inner join users on (hospital_booking_details.user_id=users.id) where hospital_booking_details.user_id ='$user_id' AND booking_id='$booking_id'");
                          $count7 = $query7->num_rows();
                        if ($count7 > 0) {
                    $resultpost7 = array();
                       foreach ($query7->result_array() as $row1) {
              
               
                    $room_type = $row1['room_type'];
                    $capacity = $row1['capacity'];
                    $details  = $row1['details'];
                    $price  = $row1['price'];
                   
                   
                
                
                $resultpost7[] = array(
                    'room_type' => $room_type,
                    'capacity' => $capacity,
                    'details' => $details,
                    'price' => $price,
                   
                    
                );
            }
                   
            
             
                } else {
                    $resultpost7 = array();
                } 
                     
                     
                     
                     ///***********************
                    
                    $booking_date = $row['booking_date'];
                    $status  = $row['status'];
                    $user_name  = $row['name'];
                    $user_mobile = $row['phone'];
                    $user_email = $row['email'];
                    $user_gender = $row['gender'];
                    $user_height = $row['height'];
                    $user_weight = $row['weight'];
                    $user_blood_group = $row['blood_group'];
                    $user_bmi = $row['bmi'];
                    $user_health_condition = $row['health_condition'];
                    $user_diet_fitness = $row['diet_fitness'];
                    $package_name = $row['package_name'];
                    $package_desc = $row['package_desc'];
                    $package_amount = $row['package_amount'];
                  
                $resultpost6[] = array(
                    'booking_id' => $booking_id,
                    'booking_date' => $booking_date,
                    'status' => $status,
                    'name' => $user_name,
                    'phone' => $user_mobile,
                    'email' => $user_email,
                    'gender' => $user_gender,
                    'height' => $branch_name,
                    'weight' => $address1,
                    'blood_group' => $user_blood_group,
                    'bmi' => $user_bmi,
                    'health_condition' => $user_health_condition,
                    'diet_fitness' => $user_diet_fitness,
                    'package_name' => $package_name,
                    'package_desc' => $package_desc,
                    'package_amount' => $package_amount,
                    'ward_details' => $resultpost7
                   
                    
                );
            }
                   
            
             
                } else {
                    $resultpost6 = array();
                } 
                
               
               
               
                    
                /*Hospital Opd Booking Start Here  */
                      
                       $query8 = $this->db->query("select u.name user_name,hp.name_of_hospital,h.*,health_record.*,h.user_id as change_user_id,d.doctor_name,h.id as book_id from hospital_booking_master as h INNER JOIN hospital_doctor_list as d ON h.doctor_id = d.id 
                           LEFT JOIN hospitals hp ON(hp.user_id=d.hospital_id)
                           LEFT JOIN health_record  ON(hp.user_id=health_record.user_id)
                           LEFT JOIN users u ON(u.id=h.user_id) WHERE h.user_id='$user_id'");
                       
              
                
    $count8 = $query8->num_rows();
   if ($count8 > 0) {
                    
                       foreach ($query8->result_array() as $row) {
              
               
                    $booking_id = $row['booking_id'];
                    $booking_date = $row['booking_date'];
                    $status  = $row['status'];
                    $doctor_name  = $row['doctor_name'];
                    $consultation_type = $row['consultation_type'];
                    $patient_name = $row['patient_name'];
                    $gender = $row['gender'];
                    $date_of_birth = $row['date_of_birth'];
                    $height = $row['height'];
                    $weight = $row['weight'];
                    $activity_level = $row['activity_level'];
                    $marital_status = $row['marital_status'];
                    $blood_group = $row['blood_group'];
                    $sex_history = $row['sex_history'];
                    $health_condition = $row['health_condition'];
                    $addiction = $row['addiction']; 
                    $allergies = $row['allergies']; 
                    
                
                
                $resultpost8[] = array(
                    'booking_id' => $booking_id,
                    'booking_date' => $booking_date,
                    'status' => $status,
                    'user_name' => $user_name,
                    'user_mobile' => $user_mobile,
                    'user_email' => $user_email,
                    'user_gender' => $user_gender,
                    'branch_name' => $branch_name,
                    'address_line1' => $address1,
                    'address_line2' => $address2,
                    'pincode' => $pincode,
                    'city' => $city,
                    'state' => $state,
                    'payment_mode' => $payment_mode,
                   
                    
                );
            }
                   
            
             
                } else {
                    $resultpost8 = array();
                }
                
                
                /*Hospital Opd Booking End Here  */
              
              
              
                  
               
                    
                /*Doctor Appoinnment Start Here  */
                      
                       $query9 = $this->db->query("SELECT user_order.order_status,user_order.order_id,user_order.pincode,user_order.delivery_charge,user_order.invoice_no,user_order.order_date,user_order.payment_method,user_order.name, user_order.address1,user_order.address2,user_order.landmark,user_order.city,user_order.state,user_order.mobile, user_order_product.product_name,user_order_product.product_img,user_order_product.product_quantity,user_order_product.product_price,user_order_product.product_discount,user_order_product.sub_total,users.name as customer_name,medical_stores.medical_name,medical_stores.email,medical_stores.contact_no FROM user_order LEFT JOIN medical_stores on user_order.listing_id=medical_stores.id LEFT JOIN user_order_product on user_order.order_id=user_order_product.order_id LEFT JOIN users on user_order.user_id=users.id WHERE user_order.user_id='$user_id'");
                       
              
                
    $count9 = $query9->num_rows();
   if ($count9 > 0) {
                    
                       foreach ($query9->result_array() as $row) {
              
               
                    $invoice_no = $row['invoice_no'];
                    $order_date = $row['order_date'];
                    $status  = $row['order_status'];
                    $customer_name  = $row['customer_name'];
                    $mobile = $row['mobile'];
                    $medical_name = $row['medical_name'];
                    $email = $row['email'];
                    $contact_no = $row['contact_no'];
                    $name = $row['name'];
                    $address1 = $row['address1'];
                    $address2 = $row['address2'];
                    $landmark = $row['landmark'];
                    $pincode = $row['pincode'];
                    $city = $row['city'];
                    $state = $row['state'];
                    $payment_method = $row['payment_method']; 
                  
                    
                
                
                $resultpost9[] = array(
                    'invoice_no' => $invoice_no,
                    'order_date' => $order_date,
                    'order_status' => $status,
                    'customer_name' => $customer_name,
                    'mobile' => $mobile,
                    'medical_name' => $medical_name,
                    'email' => $email,
                    'contact_no' => $contact_no,
                    'name' => $name,
                    'address1' => $address1,
                    'address2' => $address2,
                    'landmark' => $landmark,
                    'pincode' => $pincode,
                     'city' => $city,
                    'state' => $state,
                    'payment_method' => $payment_method,
                   
                    
                );
            }
                   
            
             
                } else {
                    $resultpost9 = array();
                }
                
                
                /*Doctor Appoinnment Booking End Here  */
              
               
                  /*Heallmall Appointment Booking End Here  */
                      
                       $query10 = $this->db->query("SELECT uo.order_id,uo.order_status,uo.user_id,uo.invoice_no,uo.address_id,uo.name,uo.mobile,uo.pincode,uo.address1, uo.address2,uo.landmark,uo.city,uo.state,uo.order_total, uo.payment_method,uo.order_date,uo.delivery_charge,uop.product_id,uop.product_name, uop.product_name,uop.product_img,uop.product_quantity,uop.product_price,uop.sub_total,uop.product_discount,uop.product_price,pd.uni_id,t.name as customer_name,u.phone as customer_number,medical_stores.medical_name,medical_stores.email,medical_stores.contact_no FROM user_order as uo  LEFT JOIN medical_stores on uo.listing_id=medical_stores.user_id 
LEFT JOIN user_order_product uop ON(uo.order_id =uop.order_id) LEFT JOIN prescription_order_details as pd ON(uo.order_id=pd.order_id) 
LEFT JOIN users as t ON(uo.user_id=t.id) LEFT JOIN users as u ON(uo.user_id=u.id)
where uo.user_id = '$user_id';");
                       
              
                
    $count10 = $query10->num_rows();
   if ($count10 > 0) {
                    
                       foreach ($query10->result_array() as $row) {
              
               
                    $invoice_no = $row['invoice_no'];
                    $order_date = $row['order_date'];
                    $status  = $row['order_status'];
                    $customer_name  = $row['customer_name'];
                    $mobile = $row['mobile'];
                    $medical_name = $row['medical_name'];
                    $email = $row['email'];
                    $contact_no = $row['mobile'];
                    $name = $row['name'];
                    $address1 = $row['address1'];
                    $address2 = $row['address2'];
                    $landmark = $row['landmark'];
                    $pincode = $row['pincode'];
                    $city = $row['city'];
                    $state = $row['state'];
                    $payment_method = $row['payment_method']; 
                  
                    
                
                
                $resultpost10[] = array(
                    'invoice_no' => $invoice_no,
                    'order_date' => $order_date,
                    'order_status' => $status,
                    'customer_name' => $customer_name,
                    'mobile' => $mobile,
                    'medical_name' => $medical_name,
                    'email' => $email,
                    'contact_no' => $contact_no,
                    'name' => $name,
                    'address1' => $address1,
                    'address2' => $address2,
                    'landmark' => $landmark,
                    'pincode' => $pincode,
                     'city' => $city,
                    'state' => $state,
                    'payment_method' => $payment_method,
                   
                    
                );
            }
                   
            
             
                } else {
                    $resultpost10 = array();
                }
                
                
                /*Heallmall Appointment Booking End Here  */
              
               
            $all_booking[] = array(
              
                'Pharamacy Precriptions' => $resultpost,
                'Pharamacy General Order' => $resultpost2,
                'Fitness Booking' => $resultpost3,
                'Nursing Booking'=>$resultpost1,
                'Labs Booking'=>$resultpost4,
                'Tyrocare Booking'=>$resultpost5,
                'Hospital Surgery Booking'=>$resultpost6,
                'Hospital OPD Booking'=>$resultpost8,
                'Doctor Appointment'=>$resultpost9,
                'HeathMall Appointment'=>$resultpost10,
            );
                
             return $all_booking;
    }
    
   
   
   

  
 
  
  
    
    
    
 
    
    
   
  
    
    
  
  

    public function user_read_slot($clinic_id, $doctor_id, $consultation_type)
    {
        $todayDay  = date('l');
        $todayDate = date('Y-m-d H:i:s');
        for ($i = 0; $i < 7; $i++) {
            $time_array           = array();
            $time_array1          = array();
            $time_array2          = array();
            $time_array3          = array();
            $time_slott           = array();
            $todayDate            = date('Y-m-d', strtotime($todayDate . ' +1 day'));
            $todayDay             = date('l', strtotime($todayDate));
            
            // doctor_slot_details
            
            if($clinic_id == '0'){
                $day_time_slots       = $this->db->query("SELECT * FROM `doctor_clinic_timing` WHERE `doctor_id` = '$doctor_id' AND `clinic_id` = '$clinic_id' AND `consultation_type` = '$consultation_type' AND `day` = '$todayDay'");
                //  echo "SELECT * FROM `doctor_clinic_timing` WHERE `doctor_id` = '$doctor_id' AND `clinic_id` = '$clinic_id' AND `consultation_type` = '$consultation_type' AND `day` = '$todayDay'";
            }else{
                $day_time_slots       = $this->db->query("SELECT `id`,`consultation_type`,`clinic_id`,`doctor_id`,`day`,`timeSlot`,`time`,`from_time`,`to_time`,`status` FROM `doctor_clinic_timing` WHERE `doctor_id` = '$doctor_id' AND `clinic_id` = '$clinic_id' AND `consultation_type` = '$consultation_type' AND `day` = '$todayDay'");
                //  echo "SELECT `id`,`consultation_type`,`clinic_id`,`doctor_id`,`day`,`timeSlot`,`time`,`from_time`,`to_time`,`status` FROM `doctor_clinic_timing` WHERE `doctor_id` = '$doctor_id' AND `clinic_id` = '$clinic_id' AND `consultation_type` = '$consultation_type' AND `day` = '$todayDay'";
            }
            $count_day_time_slots = $day_time_slots->num_rows();
            foreach ($day_time_slots->result_array() as $row) {
                if($clinic_id == '0'){
                      $timeSlot              = $row['timeSlot'];
                } else {
                      $timeSlot              = $row['timeSlot'];
                }
                
              
                $from_time             = $row['from_time'];
                $to_time               = $row['to_time'];
                // $status                = $row['status'];
                $day_time_status       = $this->db->query("SELECT `id`,`clinic_id`,`listing_id`,`booking_date`,`from_time`,`to_time`,`status` FROM `doctor_booking_master` WHERE `listing_id` = '$doctor_id' AND  `clinic_id`='$clinic_id' AND `booking_date` = '$todayDate' And `from_time` = '$from_time' And `to_time` = '$to_time' AND `status` != '3' ");
                $count_day_time_status = $day_time_status->num_rows();
                if ($count_day_time_status) {
                    if ($timeSlot == 'Morning') {
                        $time_array[] = array(
                            'from_time' => $from_time,
                            'to_time' => $to_time,
                            'status' => '1'
                        );
                    } else if ($timeSlot == 'Afternoon') {
                        $time_array1[] = array(
                            'from_time' => $from_time,
                            'to_time' => $to_time,
                            'status' => '1'
                        );
                    } else if ($timeSlot == 'Evening') {
                        $time_array3[] = array(
                            'from_time' => $from_time,
                            'to_time' => $to_time,
                            'status' => '1'
                        );
                    } else if ($timeSlot == 'Night') {
                        $time_array2[] = array(
                            'from_time' => $from_time,
                            'to_time' => $to_time,
                            'status' => '1'
                        );
                    }
                } else {
                    if ($timeSlot == 'Morning') {
                        $time_array[] = array(
                            'from_time' => $from_time,
                            'to_time' => $to_time,
                            'status' => '0'
                        );
                    } else if ($timeSlot == 'Afternoon') {
                        $time_array1[] = array(
                            'from_time' => $from_time,
                            'to_time' => $to_time,
                            'status' => '0'
                        );
                    } else if ($timeSlot == 'Evening') {
                        $time_array3[] = array(
                            'from_time' => $from_time,
                            'to_time' => $to_time,
                            'status' => '0'
                        );
                    } else if ($timeSlot == 'Night') {
                        $time_array2[] = array(
                            'from_time' => $from_time,
                            'to_time' => $to_time,
                            'status' => '0'
                        );
                    }
                }
            }
            $time_slott[] = array(
                'Morning' => $time_array,
                'time_slot' => 'Morning'
            );
            $time_slott[] = array(
                'Afternoon' => $time_array1,
                'time_slot' => 'Afternoon'
            );
            $time_slott[] = array(
                'Evening' => $time_array3,
                'time_slot' => 'Evening'
            );
            $time_slott[] = array(
                'Night' => $time_array2,
                'time_slot' => 'Night'
            );
            $time_slots[] = array(
                'day' => $todayDay,
                'date' => $todayDate,
                'timings' => $time_slott
            );
        }
        return $time_slots;
    }
    public function insert_doctor_users_feedback($doctor_id, $user_id, $type, $feedback, $ratings, $recommend,$booking_id,$booking_type)
    {
        date_default_timezone_set('Asia/Kolkata');
        $date           = date('Y-m-d H:i:s');
        $feedback_array = array(
            'type' => $type,
            'user_id' => $user_id,
            'doctor_id' => $doctor_id,
            'feedback' => $feedback,
            'created_at' => $date,
            'ratings' => $ratings,
            'recommend' => $recommend
        );
        $this->db->insert('doctor_user_feedback', $feedback_array);
        
        if($booking_type == 'inperson')
           {
            //$query = $this->db->query("UPDATE doctor_booking_master SET status='7' WHERE booking_id =$booking_id  AND user_id='$patient_id'");
           }
           else
           {
            $query = $this->db->query("UPDATE doctor_booking_master SET status='7' WHERE booking_id =$booking_id");

           }
        
           //added by jakir on 17-july-2018 for notification on add prescription 
                $user_plike = $this->db->query("SELECT name FROM users WHERE id='$doctor_id'");
                $img_count = $this->db->select('media.source')->from('media')->join('users', 'users.avatar_id=media.id')->where('users.id', $doctor_id)->get()->num_rows();
                if ($img_count > 0) {
                    $profile_query = $this->db->select('media.source')->from('media')->join('users', 'users.avatar_id=media.id')->where('users.id', $doctor_id)->get()->row();
                    $img_file = $profile_query->source;
                    $userimage = 'https://d2c8oti4is0ms3.cloudfront.net/images/healthwall_avatar/' . $img_file;
                } else {
                    $userimage = 'https://d2c8oti4is0ms3.cloudfront.net/images/img/default_user.jpg';
                }
                $user_details = $this->db->query("SELECT name FROM users WHERE id='$user_id'"); 
                 $getdetails = $user_details ->row_array();
                 $user_name = $getdetails['name'];
                 
                $getusr = $user_plike->row_array();
                $usr_name = $getusr['name'];
                $msg = $usr_name . ', You got the feedback from' . $user_name;
                $customer_token = $this->db->query("SELECT token,agent, token_status FROM users WHERE id = '$doctor_id'");
                $title = $usr_name . ', YouYou got the feedback from' . $user_name;
                $customer_token_count = $customer_token->num_rows();

                if ($customer_token_count > 0) {
                    $token_status = $customer_token->row_array();
                    $agent = $token_status['agent'];
                    $reg_id = $token_status['token'];
                    $img_url = $userimage;
                    $tag = 'text';
                    $key_count = '1';
                    $this->send_gcm_notify_feedback($title, $reg_id, $msg, $img_url,$tag,$agent);
                }
        return array(
            'status' => 201,
            'message' => 'success'
        );
    }
    
    public function send_gcm_notify_feedback($title, $reg_id, $msg, $img_url,$tag,$agent) {
        date_default_timezone_set('Asia/Kolkata');
        $date = date('j M Y h:i A');
        if (!defined("GOOGLE_GCM_URL"))
            define("GOOGLE_GCM_URL", "https://fcm.googleapis.com/fcm/send");
        $fields = array(
            'to' => $reg_id,
            'priority' => "high",
            $agent === 'android' ? 'data' : 'notification' => array(
                "title" => $title,
                "message" => $msg,
                "notification_image" => $img_url,
                "tag" => $tag,
                'sound' => 'default',
                "notification_type" => 'user_feedback',
                "notification_date" => $date,
            )
        );
        $headers = array(
            GOOGLE_GCM_URL,
            'Content-Type: application/json',
            $agent === 'android' ? 'Authorization: key=AIzaSyDTr3BzDHKj_6FnUiZXT__VCmamH-_gupM' : 'Authorization: key=AIzaSyCN1vVES0Jb3zVHeNCYPAMNnPYTl96H1uE'
        );
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, GOOGLE_GCM_URL);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch
        , CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
        $result = curl_exec($ch);
        if ($result === FALSE) {
            die('Problem occurred: ' . curl_error($ch));
        }
        curl_close($ch);
    }
    
    //view appointment list by jakir 
    public function view_appointments_module($user_id)
    {
        $Appointment_dataList   = $this->db->query("SELECT * FROM `doctor_booking_master` where `user_id`= '$user_id' ");
        $count_appointment_slot = $Appointment_dataList->num_rows();
        if ($count_appointment_slot > 0) {
            foreach ($Appointment_dataList->result_array() as $row) {
                $booking_id        = $row['booking_id'];
                $user_id           = $row['user_id'];
                $listing_id        = $row['listing_id'];
                $clinic_id         = $row['patient_id'];
                $booking_date      = $row['booking_date'];
                $consultation_type = $row['consultation_type'];
                $from_time         = $row['from_time'];
                $to_time           = $row['to_time'];
                $description       = $row['description'];
                $status            = $row['status'];
                $query12           = $this->db->query("SELECT `name` FROM `users` where `id`= '$listing_id' ");
                $doctor            = $query12->row_array();
                $doctor_name       = $doctor['name'];
                $query12           = $this->db->query("SELECT `clinic_name` FROM `doctor_clinic` where `doctor_id`= '$listing_id' AND `id` = '$clinic_id'");
                $clinic            = $query12->row_array();
                $clinic_name       = $clinic['clinic_name'];
                $resultpost[]      = array(
                    'booking_id' => $booking_id,
                    'user_id' => $user_id,
                    'doctor_name' => $doctor_name,
                    'clinic_name' => $clinic_name,
                    'booking_date' => $booking_date,
                    'consultation_type' => $consultation_type,
                    'from_time' => $from_time,
                    'to_time' => $to_time,
                    'description' => $description,
                    'status' => $status
                );
            }
            return $resultpost;
        } else
            return array();
    }
    public function get_doctor_name($doctor_id)
    {
        // doctor_list
        $doctorNameRow = $this->db->query("SELECT * FROM `doctor_list` where `id`= '$doctor_id' ");
        foreach ($doctorNameRow->result_array() as $row) {
            $doctorName = $row['doctor_name'];
        }
        return $doctorName;
    }
    // doctor_prescription
    public function get_doctor_prescription($patient_id)
    {
        // $doctorprescriptionRows = $this->db->query("SELECT * FROM `doctor_prescription` where `doctor_id`= '$doctor_id' AND `patient_id`= '$patient_id' ");
        $doctorprescriptionRows = $this->db->query("SELECT * FROM `doctor_prescription` where `patient_id`= '$patient_id' ");
        return $doctorprescriptionRows;
    }
    // get_clinic_name
    public function get_clinic_name($clinic_id)
    {
        // doctor_list
        $clinicNameRow = $this->db->query("SELECT * FROM `doctor_clinic` where `id`= '$clinic_id' ");
        foreach ($clinicNameRow->result_array() as $row) {
            $clinicName = $row['clinic_name'];
        }
        return $clinicName;
    }
    // get_doctor_prescription_medicine
    public function get_doctor_prescription_medicine($prescription_id)
    {
        // doctor_list
        $prescriptionIdRow = $this->db->query("SELECT * FROM `doctor_prescription_medicine` where `prescription_id`= '$prescription_id' ");
        foreach ($prescriptionIdRow->result_array() as $rowId) {
            $medicineDetails['medicine_name']    = $rowId['medicine_name'];
            $medicineDetails['dosage_unit']      = $rowId['dosage_unit'];
            $medicineDetails['frequency_first']  = $rowId['frequency_first'];
            $medicineDetails['frequency_second'] = $rowId['frequency_second'];
            $medicineDetails['frequency_third']  = $rowId['frequency_third'];
            $medicineDetails['instruction']      = $rowId['instruction'];
            // $medicineDetails['prescription_id'] = $rowId['id'];
            $allMedicine[]                       = $medicineDetails;
        }
        return $allMedicine;
    }
    // get_doctor_prescription_test
    public function get_doctor_prescription_test($prescription_id)
    {
        // doctor_list
        $prescriptionTestRow = $this->db->query("SELECT * FROM `doctor_prescription_test` where `prescription_id`= '$prescription_id' ");
        foreach ($prescriptionTestRow->result_array() as $rowRow) {
            $testDetailsCategory = $rowRow['category'];
            $testCatRow          = $this->db->query("SELECT * FROM `doctor_test` where `id`= '$testDetailsCategory' ");
            foreach ($testCatRow->result_array() as $cat) {
                $testCategory = $cat['test_name'];
            }
            $test['category'] = $testCategory;
            $test['test']     = $rowRow['test'];
            $testDetails[]    = $test;
        }
        return $testDetails;
    }
    public function booking_details($booking_id)
    {
        //echo "SELECT `doctor_booking_master`.*,doctor_list.*,doctor_clinic.lat,doctor_clinic.lng,doctor_clinic.consultation_charges,doctor_clinic.map_location,doctor_clinic.address,vendor_discount.* FROM `doctor_booking_master` LEFT JOIN doctor_clinic ON(doctor_booking_master.clinic_id = doctor_clinic.id) LEFT JOIN doctor_list ON(doctor_booking_master.listing_id = doctor_list.user_id) LEFT JOIN vendor_discount ON(doctor_booking_master.listing_id = vendor_discount.vendor_id AND vendor_discount.discount_category = 'doctor_visit') WHERE doctor_booking_master.`booking_id` = '$booking_id' AND  ";
        $booking_details           = $this->db->query("SELECT `doctor_booking_master`.*,doctor_list.*,doctor_clinic.lat,doctor_clinic.lng,doctor_clinic.consultation_charges,doctor_clinic.map_location,doctor_clinic.address,vendor_discount.* FROM `doctor_booking_master` LEFT JOIN doctor_clinic ON(doctor_booking_master.clinic_id = doctor_clinic.id) LEFT JOIN doctor_list ON(doctor_booking_master.listing_id = doctor_list.user_id) LEFT JOIN vendor_discount ON(doctor_booking_master.listing_id = vendor_discount.vendor_id AND vendor_discount.discount_category = 'doctor_visit') WHERE doctor_booking_master.`booking_id` = '$booking_id'");
        $booking_details           = $booking_details->row_array();
        $doctor_id                 = $booking_details['listing_id'];
        $clinic_id                 = $booking_details['clinic_id'];
        $booking_id                = $booking_details['booking_id'];
        $booking_date              = $booking_details['booking_date'];
        $booking_time              = $booking_details['booking_time'];
        $created_date              = $booking_details['created_date'];
        $consultation_type         = $booking_details['consultation_type'];
        $status                    = $booking_details['status'];
        $doctor_name               = $booking_details['doctor_name'];
        $doctor_email              = $booking_details['email'];
        $doctor_experience         = $booking_details['experience'];
        $speciality                = $booking_details['speciality'];
        $doctor_dob                = $booking_details['dob'];
        $doctor_telephone          = $booking_details['telephone'];
        $doctor_lat                = $booking_details['lat'];
        $doctor_lng                = $booking_details['lng'];
        $doctor_address            = $booking_details['map_location'];
        $doctor_consultation_visit = $booking_details['consultation_charges'];
        $discount_amount           = $booking_details['discount_min'];
        $discount_type             = $booking_details['discount_type'];
        $discount_limit            = $booking_details['discount_limit'];
        $discount_category         = $booking_details['discount_category'];
        $visit_charge              = "";
        if ($discount_category == "doctor_visit") {
            if ($discount_type == "percent") {
                $visit_discount_amount = $doctor_consultation_visit * ($discount_amount / 100);
                if ($visit_discount_amount > $discount_limit) {
                    $visit_discount_amount = $discount_limit;
                } else {
                    $visit_discount_amount = $visit_discount_amount;
                }
                $visit_charge = $doctor_consultation_visit - $visit_discount_amount;
            } else if ($discount_type == "rupees") {
                $visit_discount_amount = $doctor_consultation_visit - $discount_amount;
                if ($visit_discount_amount > $discount_limit) {
                    $visit_discount_amount = $discount_limit;
                } else {
                    $visit_discount_amount = $visit_discount_amount;
                }
                $visit_charge = $doctor_consultation_visit - $visit_discount_amount;
            }
            if ($visit_charge < 0) {
                $visit_charge = 0;
            }
        }
        
        //doctor consultaion
        if($consultation_type == 'visit')
        {
            
        }
        else
        {
        $clinic_id = 0;
        }
        $results = array();
        $available_call = "0";
        $available_video = "0";
        $available_chat = "0";
        $results_call = array();
        $results_video = array();
        $results_chat = array();
        $q = $this->db->query("SELECT * FROM `doctor_consultation` WHERE `doctor_user_id` = '$doctor_id' AND consultation_name<>'visit'");
        
        $qRows = $q->result_array();
        
        foreach($qRows as $qRow){
            if($qRow['consultation_name'] == 'chat' && $qRow['is_active'] == 1){
                $available_call = $qRow['is_active'];
                $duration = $qRow['duration'];
                $charges = $qRow['charges'];
                
                $results_call['consultation_type'] = 'call';
                $results_call['info'] = array(
                        'duration' => $duration,
                        'charges' => $charges
                    );    
            }
            
            if($qRow['consultation_name'] == 'video' && $qRow['is_active'] == 1){
                $available_video = $qRow['is_active'];
                $duration = $qRow['duration'];
                $charges = $qRow['charges'];
                
                $results_video['consultation_type'] = 'video';
                $results_video['info'] = array(
                        'duration' => $duration,
                        'charges' => $charges
                    );    
            }
            
             if($qRow['consultation_name'] == 'chat' && $qRow['is_active'] == 1){
                $available_chat = $qRow['is_active'];
                $duration = $qRow['duration'];
                $charges = $qRow['charges'];
                
                $results_chat['consultation_type'] = 'chat';
                $results_chat['info'] = array(
                        'duration' => $duration,
                        'charges' => $charges
                    );    
            }
            
        }
      
      if($results_call){$results[] = $results_call;}
      if($results_video){$results[] = $results_video;}
      if($results_chat){$results[] = $results_chat;}
        
        
        // doctor_consultation
        if($clinic_id == "0"){
          
            $charges = $this->db->query("SELECT * FROM `doctor_consultation`  WHERE `doctor_user_id` = '$doctor_id' AND `consultation_name` = '$consultation_type'");
            // [charges]
            foreach($charges->result_array() as $charge ){
                $doctor_consultation_visit = $charge['charges'];
            }
              
        }
        $doctor_consultation_video      = $booking_details['consultaion_video'];
        $doctor_consultation_voice_call = $booking_details['consultation_voice_call'];
        $doctor_image                   = $booking_details['image'];
        if ($doctor_image != '') {
            $doctor_image = str_replace(' ', '%20', $doctor_image);
            $doctor_image = 'https://d2c8oti4is0ms3.cloudfront.net/images/healthwall_avatar/' . $doctor_image;
        } else {
            $doctor_image = 'https://d2c8oti4is0ms3.cloudfront.net/images/img/default_profile_pic_user.png';
        }
        $doctor_ratings       = $booking_details['rating'];
        $doctor_qualification = $booking_details['qualification'];
        $doctor_category      = $booking_details['category'];
        $area_expertise       = array();
        $query_sp             = $this->db->query("SELECT id,`category` AS area_expertise FROM `business_category` WHERE  FIND_IN_SET(id,'" . $doctor_category . "')");
        $total_category       = $query_sp->num_rows();
        if ($total_category > 0) {
            foreach ($query_sp->result_array() as $get_sp) {
                $id               = $get_sp['id'];
                $area_expertised  = $get_sp['area_expertise'];
                $area_expertise[] = array(
                    'id' => $id,
                    'area_expertise' => $area_expertised
                );
            }
        } else {
            $area_expertise = array();
        }
        $degree_array  = array();
        $degree_       = explode(',', $doctor_qualification);
        $count_degree_ = count($degree_);
        if ($count_degree_ > 1) {
            foreach ($degree_ as $degree_) {
                $degree_array[] = array(
                    'degree' => $degree_
                );
            }
        } else {
            $degree_array = array();
        }
        $special_array = array();
        $speciality    = explode(",", $speciality);
        $specialitycnt = count($speciality);
        //$specialitycnt--;
        if ($specialitycnt > 0) {
            for ($j = 0; $j < $specialitycnt; $j++) {
                $special_array[] = array(
                    'specialization' => $speciality[$j]
                );
            }
        } else {
            $special_array = array();
        }
        // $special_ = explode(',', $speciality);
        // $count_special_ = count($special_);
        // if ($count_special_ > 1) {
        //     foreach ($special_ as $special_) {
        //         $special_array[] = array(
        //             'specialization' => $special_
        //         );
        //     }
        // } else {
        //     $special_array = array();
        // }
        $testDetails = array(
            'doctor_id' => $doctor_id,
            'clinic_id' => $clinic_id,
            'booking_id' => $booking_id,
            'booking_date' => $booking_date,
            'booking_time' => $booking_time,
            'created_date' => $created_date,
            'consultation_type' => $consultation_type,
            'doctor_name' => $doctor_name,
            'email' => $doctor_email,
            'experience' => $doctor_experience,
            'dob' => $doctor_dob,
            'telephone' => $doctor_telephone,
            'info' => $results,
            'lat' => $doctor_lat,
            'lng' => $doctor_lng,
            'doctor_address' => $doctor_address,
            'doctor_image' => $doctor_image,
            'rating' => $doctor_ratings,
            'degree' => $degree_array,
            'status' => $status,
            'doctor_specialization' => $special_array,
            'area_expertise' => $area_expertise,
            'consultation_charges' => $doctor_consultation_visit,
            'discount_amount_min' => $booking_details['discount_min'],
            'discount_amount_max' => $booking_details['discount_max'],
            'discount_type' => $booking_details['discount_type'],
            'discount_limit' => $booking_details['discount_limit'],
            'discount_category' => $booking_details['discount_category'],
            'payable_amount' => $visit_charge
        );
        return $testDetails;
    }
    // vendor_discount
    public function vendor_discount($vendor_id, $clinic_id)
    {
        $discount      = array();
        $call          = array();
        $text          = array();
        $video         = array();
        $clinic        = array();
        $today         = date('Y-m-d');
        $doctorCharges = $this->db->query("SELECT * FROM `doctor_list` WHERE id = '$vendor_id'");
        $count         = $doctorCharges->num_rows();
        if ($count > 0) {
            foreach ($doctorCharges->result_array() as $row) {
                $consultation_video     = $row['consultation_video'];
                $consultaion_chat       = $row['consultaion_chat'];
                $consultaion_voice_call = $row['consultaion_voice_call'];
            }
        }
        // $clinic_id
        if ($clinic_id > 0) {
            $doctorClinicCharges = $this->db->query("SELECT * FROM `doctor_clinic` WHERE id = '$clinic_id' AND doctor_id = '$vendor_id'");
            $doctorClinicCount   = $doctorClinicCharges->num_rows();
            if ($doctorClinicCount > 0) {
                foreach ($doctorClinicCharges->result_array() as $rowClinic) {
                    $consultation_visit = $rowClinic['consultation_charges'];
                }
            }
        }
        $vendorDiscount      = $this->db->query("SELECT * FROM `vendor_discount` WHERE vendor_id = '$vendor_id'");
        //  doctor_voice
        $vendorDiscountCount = $vendorDiscount->num_rows();
        if ($vendorDiscountCount > 0) {
            foreach ($vendorDiscount->result_array() as $row1) {
                // print_r($row1);
                $discountAmt   = $row1['discount_amount'];
                $discountLimit = $row1['discount_limit'];
                $discountExp   = $row1['discount_exp'];
                if (strtotime($today) <= strtotime($discountExp)) {
                    if ($row1['discount_category'] == "doctor_chat") {
                        if ($row1['discount_type'] == "percent") {
                            $chatDisCharge = $consultaion_chat * ($discountAmt / 100);
                            if ($chatDisCharge > $discountLimit) {
                                $chatDisCharge = $discountLimit;
                            } else {
                                $chatDisCharge = $chatDisCharge;
                            }
                            $chatCharge = $consultaion_chat - $chatDisCharge;
                        } else if ($row1['discount_type'] == "rupees") {
                            $chatDisCharge = $consultaion_chat - $discountAmt;
                            if ($chatDisCharge > $discountLimit) {
                                $chatDisCharge = $discountLimit;
                            } else {
                                $chatDisCharge = $chatDisCharge;
                            }
                            $chatCharge = $consultaion_chat - $chatDisCharge;
                        }
                        $details['amount']         = $consultaion_chat;
                        $details['payable_amount'] = $chatCharge;
                        $details['total_discount'] = $chatDisCharge;
                        $details['discount']       = $discountAmt;
                        $details['discount_type']  = $row1['discount_type'];
                        $details['discount_limit'] = $discountLimit;
                        $details['category']       = $row1['discount_category'];
                        $details['expiry']         = $discountExp;
                        $detailsAll[]              = $details;
                    }
                    if ($row1['discount_category'] == "doctor_call") {
                        if ($row1['discount_type'] == "percent") {
                            $voiceDisCharge = $consultaion_voice_call * ($discountAmt / 100);
                            if ($voiceDisCharge > $discountLimit) {
                                $voiceDisCharge = $discountLimit;
                            } else {
                                $voiceDisCharge = $voiceDisCharge;
                            }
                            $voiceCharge = $consultaion_voice_call - $voiceDisCharge;
                        } else if ($row1['discount_type'] == "rupees") {
                            $voiceDisCharge = $consultaion_voice_call - $discountAmt;
                            if ($voiceDisCharge > $discountLimit) {
                                $voiceDisCharge = $discountLimit;
                            } else {
                                $voiceDisCharge = $voiceDisCharge;
                            }
                            $voiceCharge = $consultaion_voice_call - $voiceDisCharge;
                        }
                        $details['amount']         = $consultaion_voice_call;
                        $details['payable_amount'] = $voiceCharge;
                        $details['total_discount'] = $voiceDisCharge;
                        $details['discount']       = $discountAmt;
                        $details['discount_type']  = $row1['discount_type'];
                        $details['discount_limit'] = $discountLimit;
                        $details['category']       = $row1['discount_category'];
                        $details['expiry']         = $discountExp;
                        $detailsAll[]              = $details;
                    }
                    if ($row1['discount_category'] == "doctor_video") {
                        if ($row1['discount_type'] == "percent") {
                            $videoDisCharge = $consultation_video * ($discountAmt / 100);
                            if ($videoDisCharge > $discountLimit) {
                                $videoDisCharge = $discountLimit;
                            } else {
                                $videoDisCharge = $videoDisCharge;
                            }
                            $videoCharge = $consultation_video - $videoDisCharge;
                        } else if ($row1['discount_type'] == "rupees") {
                            $videoDisCharge = $consultation_video - $discountAmt;
                            if ($videoDisCharge > $discountLimit) {
                                $videoDisCharge = $discountLimit;
                            } else {
                                $videoDisCharge = $videoDisCharge;
                            }
                            $videoCharge = $consultation_video - $videoDisCharge;
                        }
                        $details['amount']         = $consultation_video;
                        $details['payable_amount'] = $videoCharge;
                        $details['total_discount'] = $videoDisCharge;
                        $details['discount']       = $discountAmt;
                        $details['discount_type']  = $row1['discount_type'];
                        $details['discount_limit'] = $discountLimit;
                        $details['category']       = $row1['discount_category'];
                        $details['expiry']         = $discountExp;
                        $detailsAll[]              = $details;
                    }
                    if ($clinic_id > 0) {
                        if ($row1['discount_category'] == "doctor_visit") {
                            // $consultation_visit
                            /* $visitCharge = "";
                            $visitDisCharge = "";*/
                            if ($row1['discount_type'] == "percent") {
                                $visitDisCharge = $consultation_visit * ($discountAmt / 100);
                                if ($visitDisCharge > $discountLimit) {
                                    $visitDisCharge = $discountLimit;
                                } else {
                                    $visitDisCharge = $visitDisCharge;
                                }
                                $visitCharge = $consultation_visit - $visitDisCharge;
                            } else if ($row1['discount_type'] == "rupees") {
                                $visitDisCharge = $consultation_visit - $discountAmt;
                                if ($visitDisCharge > $discountLimit) {
                                    $visitDisCharge = $discountLimit;
                                } else {
                                    $visitDisCharge = $visitDisCharge;
                                }
                                $visitCharge = $consultation_visit - $visitDisCharge;
                            }
                            $details['amount']         = $consultation_visit;
                            $details['payable_amount'] = $visitCharge;
                            $details['total_discount'] = $visitDisCharge;
                            $details['discount']       = $discountAmt;
                            $details['discount_type']  = $row1['discount_type'];
                            $details['discount_limit'] = $discountLimit;
                            $details['category']       = $row1['discount_category'];
                            $details['expiry']         = $discountExp;
                            $detailsAll[]              = $details;
                        }
                    }
                } else {
                    $details['expiry'] = "discount expired";
                    $detailsAll[]      = $details;
                }
            }
        }
        //  die();
        $resp = array(
            "status" => 200,
            "data" => $detailsAll
        );
        return $resp;
    }
    /*
    User Approval Status
    1=Confirm 
    2=Reschedule
    2 task in this method
    1.Doctor Appointment Status Change
    2.Notification trigger
    
    
    1 = booked by user / awaiting confirmation from doctor
    2 = doctor confirm ( payment pending from user side)
    3 = doctor cancel (doctor cancel or user canceled)
    4 = rescheduled by doctor (awaiting confirmation from user)
    5 = user confirm (after payment done meeting is schedule for perticular date ) 
    6 = awaiting feedback 
    7 = completed (all process done completed all meetings)
    */
    public function user_payment_approval($doctor_id, $status, $booking_id, $user_id)
    {
        //echo $doctor_id . ',' . $status . ',' . $booking_id . ',' . $user_id;
        //die();
        date_default_timezone_set('Asia/Kolkata');
        $date         = date('Y-m-d H:i:s');
        //$status = strtolower($status);
        $status       = $status; // 2 - if doctor confirm timing ,4 doctor cancelled timing ,6 reschedule
        //echo "SELECT user_id,booking_id,listing_id FROM doctor_booking_master WHERE booking_id='$booking_id'";
        $table_record = $this->db->query("SELECT user_id,booking_id,listing_id FROM doctor_booking_master WHERE booking_id='$booking_id'");
        $count_user   = $table_record->num_rows();
        if ($count_user > 0) {
            $booking_array = array(
                'status' => $status,
                'created_date' => $date
            );
            $updateStatus  = $this->db->where('booking_id', $booking_id)->update('doctor_booking_master', $booking_array);
            if (!$updateStatus) {
                return array(
                    'status' => 204,
                    'message' => 'Update failed'
                );
            }
            if ($status == '5') //user confirm, payment pending
                {
                $row       = $table_record->row();
                $user_id   = $row->user_id;
                $doctor_id = $row->listing_id;
                $this->confirm_status($user_id, $booking_id, $doctor_id);
            }
            else if ($status == '8')
            {
                 $row       = $table_record->row();
                $user_id   = $row->user_id;
                $doctor_id = $row->listing_id;
                $this->confirm_cash_on_delivery_status($user_id, $booking_id, $doctor_id);
            }
            else if ($status == '3') //cancel appointment 
                {
                $row       = $table_record->row();
                $user_id   = $row->user_id;
                $doctor_id = $row->listing_id;
                $this->cancel_status($user_id, $booking_id, $doctor_id);
            }
        } else {
            return array(
                'status' => 208,
                'message' => 'Booking data not found'
            );
        }
        return array(
            'status' => 200,
            'message' => 'success'
        );
    }
    /*
    Confirm Status is used to confirm the 
    status of the appointment.
    Doubt in query call doctor name can be called  from parent method using join
    which is better way.
    */
    public function confirm_status($user_id, $booking_id, $listing_id)
    {
        $appointment_status = '5';
        //$table_record       = $this->db->query("SELECT doctor_name FROM doctor_list WHERE user_id='$listing_id' ");
        $table_record       = $this->db->query("SELECT name as patient_name FROM users WHERE id='$user_id'");
        $count_user         = $table_record->num_rows();
        
          $bookingRecords =  $this->db->query("SELECT `booking_date`,`from_time`,`to_time`,`consultation_type` FROM `doctor_booking_master` WHERE `booking_id`='$booking_id'");
        $count_record  = $bookingRecords->num_rows();
        if($count_record > 0){
            $bookingRecord = $bookingRecords->row();
            
            $booking_date = $bookingRecord->booking_date;
            $from_time = $bookingRecord->from_time;
            $to_time = $bookingRecord->to_time;
            $booking_time = $from_time.'-'.$to_time;
            $consultation_type = $bookingRecord->consultation_type;
        }
        
        if ($count_user > 0) {
            $row         = $table_record->row();
            $patient_name = $row->patient_name;
            $title       = $patient_name . ' has Confirmed an Payment';
            $msg         = $patient_name . '  has Confirmed an Payment.';
           // $this->notifyDoctorMethod($listing_id, $appointment_status, $booking_id, $patient_name, $title, $msg);
            $this->notifyDoctorMethod($listing_id, $user_id,$title,$msg, $booking_date, $booking_time, $booking_id, $consultation_type, $patient_name);
            
        }
    }
    /*
    Cancel Status 
    User has canceled the appointment.
    */
    public function cancel_status($user_id, $booking_id, $listing_id)
    {
        $appointment_status = '3';
        $table_record       = $this->db->query("SELECT name as patient_name FROM users WHERE id='$user_id'");
        $count_user         = $table_record->num_rows();
        
          $bookingRecords =  $this->db->query("SELECT `booking_date`,`from_time`,`to_time`,`consultation_type` FROM `doctor_booking_master` WHERE `booking_id`='$booking_id'");
        $count_record  = $bookingRecords->num_rows();
        if($count_record > 0){
            $bookingRecord = $bookingRecords->row();
            
            $booking_date = $bookingRecord->booking_date;
            $from_time = $bookingRecord->from_time;
            $to_time = $bookingRecord->to_time;
            $booking_time = $from_time.'-'.$to_time;
            $consultation_type = $bookingRecord->consultation_type;
        }
        
        
        if ($count_user > 0) {
            $row         = $table_record->row();
            $patient_name = $row->patient_name;
            $title       = $patient_name . ' has Cancel an Payment';
            $msg         = $patient_name . '  has Cancel an Payment.';
            //$this->notifyDoctorMethod($listing_id, $appointment_status, $booking_id, $patient_name, $title, $msg);
             $this->notifyDoctorMethod($listing_id, $user_id,$title,$msg, $booking_date, $booking_time, $booking_id, $consultation_type, $patient_name);
        }
    }
    
   public function confirm_cash_on_delivery_status($user_id, $booking_id, $listing_id)
    {
        $appointment_status = '8';
        $table_record   = $this->db->query("SELECT name as patient_name FROM users WHERE id='$user_id'");
        
        $bookingRecords =  $this->db->query("SELECT `booking_date`,`from_time`,`to_time`,`consultation_type` FROM `doctor_booking_master` WHERE `booking_id`='$booking_id'");
        $count_record  = $bookingRecords->num_rows();
        if($count_record > 0){
            $bookingRecord = $bookingRecords->row();
            
            $booking_date = $bookingRecord->booking_date;
            $from_time = $bookingRecord->from_time;
            $to_time = $bookingRecord->to_time;
            $booking_time = $from_time.'-'.$to_time;
            $consultation_type = $bookingRecord->consultation_type;
        }
        
        $count_user         = $table_record->num_rows();
        if ($count_user > 0) {
            $row         = $table_record->row();
            $patient_name = $row->patient_name;
            $title       = $patient_name . ' has Confirmed an Payment on Cash on Delivery.' ;
             $msg         = $patient_name . '  has Confirmed an Payment on Cash on Delivery.';
           
            
            //$this->notifyDoctorMethod($listing_id, $appointment_status, $booking_id, $patient_name, $title, $msg);
            $this->notifyDoctorMethod($listing_id, $user_id,$title,$msg, $booking_date, $booking_time, $booking_id, $consultation_type, $patient_name);
        }
    }

    /*
    This method is used for notification.
    Left doctor service.
    */
    // public function notifyDoctorMethod($user_id, $appointment_status, $booking_id, $doctor_name,$title,$msg)
    // {

    //       $customer_token = $this->db->query("SELECT name,token,agent,token_status FROM users WHERE id='$user_id'");
    //       $customer_token_count = $customer_token->num_rows();
    //         if ($customer_token_count > 0) {
    //             $token_status = $customer_token->row_array();
    //             // $getusr = $user_plike->row_array();

    //             $usr_name = $token_status['name'];
    //             $agent = $token_status['agent'];
    //             $reg_id = $token_status['token'];
    //             $img_url = 'https://medicalwale.com/img/medical_logo.png';
    //             $tag = 'text';
    //             $key_count = '1';
    //             $title = $title;
    //             $msg = $msg;
    //             $this->send_gcm_notify_user($title, $reg_id, $msg, $img_url, $tag, $agent, $booking_id);
    //         }
    // }


    //     //send notification through firebase
    //     /* notification to send in the doctor app for appointment confirmation*/
    // public function send_gcm_notify_user($title, $reg_id, $msg, $img_url, $tag, $agent, $booking_id) {
     
    //     date_default_timezone_set('Asia/Kolkata');
    //     $date = date('j M Y h:i A');
        
    //     if (!defined("GOOGLE_GCM_URL"))
    //         define("GOOGLE_GCM_URL", "https://fcm.googleapis.com/fcm/send");
    //     $fields = array(
    //         'to' => $reg_id,
    //         'priority' => "high",
    //         $agent === 'android' ? 'data' : 'notification' => array(
    //             "title" => $title,
    //             "message" => $msg,
    //             "notification_image" => $img_url,
    //             "tag" => $tag, 
    //             'sound' => 'default',
    //             "notification_type" => 'appointment_notifications',
    //             "notification_date" => $date,
    //             "booking_id" => $booking_id
    //          //   app date app time  app it 
    //         )
    //     );
       
    //     $headers = array(
    //             GOOGLE_GCM_URL,
    //             'Content-Type: application/json',
    //             $agent === 'android' ? 'Authorization: key=AAAAMCq6aPA:APA91bFjtuwLeq5RK6_DFrXntyJdXCFSPI0JdJcvoXXi0xIGm7qgzQJmUl7aEq3HjUTV3pvlFr5iv5pOWtCoN3JIpMSVhU8ZFzusaibehi5MPwThRmx1pCnm3Tm-x6wI8tGwhc0eUj2U' : 'Authorization: key=AIzaSyAPAKcKLABcHyRhiaf9LO_i2xcosgw3Y3E'
    //         );
    //     $ch = curl_init();
    //     curl_setopt($ch, CURLOPT_URL, GOOGLE_GCM_URL);
    //     curl_setopt($ch, CURLOPT_POST, true);
    //     curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    //     curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    //     curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    //     curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
    //     $result = curl_exec($ch);
    //     if ($result === FALSE) {
    //          die('Problem occurred: ' . curl_error($ch));
    //     }
        
    //     curl_close($ch);
    // }
    
    
    
    public function notifyDoctorMethod($listing_id, $user_id,$title,$msg, $booking_date, $booking_time, $booking_id, $consultation_type, $patient_name)
    {

          $customer_token = $this->db->query("SELECT name,token,agent,token_status FROM users WHERE id='$listing_id'");
          $customer_token_count = $customer_token->num_rows();
            if ($customer_token_count > 0) {
                $token_status = $customer_token->row_array();
                // $getusr = $user_plike->row_array();

                $usr_name = $token_status['name'];
                $agent = $token_status['agent'];
                $reg_id = $token_status['token'];
                $img_url = 'https://medicalwale.com/img/medical_logo.png';
                $tag = 'text';
                $key_count = '1';
                $title = $title;
                $msg = $msg;
                $this->send_gcm_notify_user($title, $reg_id, $msg, $img_url, $tag, $agent,$booking_date,$booking_time,$booking_id,$consultation_type);
            }
    }


        //send notification through firebase
        /* notification to send in the doctor app for appointment confirmation*/
    public function send_gcm_notify_user($title, $reg_id, $msg, $img_url, $tag, $agent,$booking_date,$booking_time,$booking_id,$consultation_type) {
     
        date_default_timezone_set('Asia/Kolkata');
        $date = date('j M Y h:i A');
        
        if (!defined("GOOGLE_GCM_URL"))
            define("GOOGLE_GCM_URL", "https://fcm.googleapis.com/fcm/send");
        $fields = array(
            'to' => $reg_id,
            'priority' => "high",
            $agent === 'android' ? 'data' : 'notification' => array(
                "title" => $title,
                "message" => $msg,
                "notification_image" => $img_url,
                "tag" => $tag, 
                'sound' => 'default',
                "notification_type" => 'appointment_notifications',
                "notification_date" => $date,
                "appointment_id" => $booking_id,
                "appointment_date" => $booking_date,
                "appointment_time" =>$booking_time,
                "type_of_connect" => $consultation_type
             //   app date app time  app it 
            )
        );
       
        $headers = array(
                GOOGLE_GCM_URL,
                'Content-Type: application/json',
                $agent === 'android' ? 'Authorization: key=AAAAMCq6aPA:APA91bFjtuwLeq5RK6_DFrXntyJdXCFSPI0JdJcvoXXi0xIGm7qgzQJmUl7aEq3HjUTV3pvlFr5iv5pOWtCoN3JIpMSVhU8ZFzusaibehi5MPwThRmx1pCnm3Tm-x6wI8tGwhc0eUj2U' : 'Authorization: key=AIzaSyAPAKcKLABcHyRhiaf9LO_i2xcosgw3Y3E'
            );
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, GOOGLE_GCM_URL);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
        $result = curl_exec($ch);
        if ($result === FALSE) {
             die('Problem occurred: ' . curl_error($ch));
        }
        
        curl_close($ch);
    }
    
    
    // get_doctor_consultation
    
    public function get_doctor_consultation($doctor_id) {
        $clinic_id = 0;
        $results = array();
        $available_call = "0";
        $available_video = "0";
        $available_chat = "0";
        $results_call = array();
        $results_video = array();
        $results_chat = array();
        $q = $this->db->query("SELECT * FROM `doctor_consultation` WHERE `doctor_user_id` = '$doctor_id' ");
        
        $qRows = $q->result_array();
        
        foreach($qRows as $qRow){
            if($qRow['consultation_name'] == 'chat' && $qRow['is_active'] == 1){
                $available_call = $qRow['is_active'];
                $duration = $qRow['duration'];
                $charges = $qRow['charges'];
                
                $results_call['consultation_type'] = 'call';
                $results_call['info'] = array(
                        'duration' => $duration,
                        'charges' => $charges
                    );    
            }
            
            if($qRow['consultation_name'] == 'video' && $qRow['is_active'] == 1){
                $available_video = $qRow['is_active'];
                $duration = $qRow['duration'];
                $charges = $qRow['charges'];
                
                $results_video['consultation_type'] = 'video';
                $results_video['info'] = array(
                        'duration' => $duration,
                        'charges' => $charges
                    );    
            }
            
             if($qRow['consultation_name'] == 'chat' && $qRow['is_active'] == 1){
                $available_chat = $qRow['is_active'];
                $duration = $qRow['duration'];
                $charges = $qRow['charges'];
                
                $results_chat['consultation_type'] = 'chat';
                $results_chat['info'] = array(
                        'duration' => $duration,
                        'charges' => $charges
                    );    
            }
            
        }
      
      if($results_call){$results[] = $results_call;}
      if($results_video){$results[] = $results_video;}
      if($results_chat){$results[] = $results_chat;}

     
        $data = array ('doctor_id' => $doctor_id, 'available_call' => $available_call, 'available_video' => $available_video, 'available_chat' => $available_chat, 'info' => $results);
        return $data;
    }
    
    // edit_bookings
    public function edit_bookings($booking_id, $newdata) {
        // $data['booking_id'] = $booking_id;
        
        $updateStatus  = $this->db->where('booking_id', $booking_id)->update('doctor_booking_master', $newdata);
        $data = $newdata;
        return $data;
    }
    
    public function get_cart_details_list($user_id)
    {
          $query = $this->db->query("SELECT * FROM `cart` WHERE `user_id` = '$user_id' ");
        $num_count = $query->num_rows();
        $qRows = $query->result_array();
       // print_r ($num_count);
      //  print_r ($qRows);
      //  die();
        if($num_count>0)
        {
        foreach($qRows as $qRow)
        {
            $id = $qRow['id'];
            $user_id = $qRow['user_id'];
            $listing_id =$qRow['listing_id'];
            $product_id =$qRow['product_id'];
            $sub_category = $qRow['sub_category'];
            $quantity = $qRow['quantity'];
            $product_type = $qRow['product_type'];
            $status = $qRow['status'];
            //  echo "SELECT * FROM `product` WHERE `id` = '$id' and `sub_category` = '$sub_category' ";
              $product_query = $this->db->query("SELECT * FROM `product` WHERE `id` = '$product_id' and `sub_category` = '$sub_category' ");
               $nume_count = $product_query->num_rows();
              $product_Rows = $product_query->result_array();
            //  print_r ($nume_count);
            //  print_r ($product_Rows);
            //  die();
            if($nume_count>0)
            {
                foreach($product_Rows as $product_Row)
                {
                    $product_name = $product_Row['product_name'];
                   $product_price = $product_Row['product_price'];
                   $product_description = $product_Row['product_description'];
                   $product_image = 'https://d2c8oti4is0ms3.cloudfront.net/images/product_images/'. $product_Row['image'];
                   $in_stock = $product_Row['in_stock'];
                   $product_weight = $product_Row['pack'];
                }
            }
            else
            {
                $product_name = "";
                   $product_price = "";
                   $product_description = "";
                   $product_image = "";
                   $in_stock = "";
                   $product_weight = "";
            }
            
             $results_cart[] = array(
                        'id' => $id,
                        'user_id' => $user_id,
                        'listing_id' =>$listing_id,
                        'product_id' =>$product_id,
                        'sub_category' =>$sub_category,
                        'quantity' =>$quantity,
                        'product_type'=>$product_type,
                        'status'=>$status,
                        'product_name' => $product_name,
                        'product_price' => $product_price,
                        'product_image' => $product_image,
                        'product_description' => $product_description,
                        'in_stock' => $in_stock,
                        'product_weight' => $product_weight
                    ); 
        }
            $data = $results_cart;
            return $data;
        }
        else
        {
           return array(
                'status' => 200,
                'data' => array(),
                'message' => 'data not found'
            ); 
        }
    }
    
    public function recent_doctor_list($user_id){
        
        //echo "SELECT * FROM doctor_booking_master WHERE user_id='$user_id' GROUP BY listing_id";
        $booking_master = $this->db->query("SELECT * FROM doctor_booking_master WHERE user_id='$user_id' GROUP BY listing_id");
        $booking_count = $booking_master->num_rows();
        $qRows = $booking_master->result_array();
        if($booking_count>0)
        {
            foreach($qRows as $qRow)
            {
                $listing_id = $qRow['listing_id'];
                //echo "SELECT * FROM doctor_list WHERE user_id='$listing_id'";
                $doctor_list = $this->db->query("SELECT * FROM doctor_list WHERE user_id='$listing_id'");
                $doctor_list_count = $doctor_list->num_rows();
                $qRows2 = $doctor_list->row();
                if($doctor_list_count>0)
                {
                    $doctor_name         = $qRows2->doctor_name;
                        $email               = $qRows2->email;
                        $gender              = $qRows2->gender;
                        $doctor_phone        = $qRows2->telephone;
                        $dob                 = $qRows2->dob;
                        $category            = $qRows2->category;
                        $speciality          = $qRows2->speciality;
                        $service             = $qRows2->service;
                        $degree              = $qRows2->qualification;
                        $experience          = $qRows2->experience;
                        $reg_council         = $qRows2->reg_council;
                        $reg_number          = $qRows2->reg_number;
                        $doctor_user_id      = $qRows2->user_id;
                        $address             = $qRows2->address;
                        
                        $query_rating = $this->db->query("SELECT  ROUND(AVG(rating),1) AS total_rating FROM doctors_review WHERE doctor_id='$doctor_user_id'");
                        $row_rating   = $query_rating->row_array();
                        $total_rating = $row_rating['total_rating'];
                        if ($total_rating === NULL || $total_rating === '') {
                            $total_rating = '0';
                        }
                        
                        if ($qRows2->image != '') {
                            $profile_pic = $qRows2->image;
                            $profile_pic = str_replace(' ', '%20', $profile_pic);
                            $profile_pic = 'https://d2c8oti4is0ms3.cloudfront.net/images/healthwall_avatar/' . $profile_pic;
                        }else{
                            $profile_pic = 'https://d2c8oti4is0ms3.cloudfront.net/images/img/default_profile_pic_user.png';
                        }
                        
                       $resultpost[] = array(
                            'doctor_user_id' => $doctor_user_id,
                            'doctor_name' => $doctor_name,
                            'email' => $email,
                            'gender' => $gender,
                            'doctor_phone' => $doctor_phone,
                            'dob' => $dob,
                            'experience' => $experience,
                            'reg_council' => $reg_council,
                            'reg_number' => $reg_number,
                            'profile_pic' => $profile_pic,
                            'address' => $address,
                            'rating' => $total_rating
                        );
                }
            }
            return $resultpost;
        }
        else{
            return $resultpost = array();
        }
        
        
    }
    
        public function doctor_notification_confirm($booking_id){
       $data="SELECT doctor_booking_master.*,users.name,users.email,users.phone,doctor_clinic.clinic_name,doctor_list.telephone,doctor_list.doctor_name FROM doctor_booking_master LEFT JOIN users ON (doctor_booking_master.user_id=users.id) LEFT JOIN doctor_clinic ON (doctor_booking_master.clinic_id=doctor_clinic.id) 
          LEFT JOIN doctor_list ON (doctor_booking_master.listing_id=doctor_list.user_id)WHERE doctor_booking_master.booking_id='".$booking_id."'";
         
         $result = $this->db->query($data)->row();
            return $result;
}
    
}