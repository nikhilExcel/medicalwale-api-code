<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class CartModel extends CI_Model
{

    var $client_service = "frontend-client";
    var $auth_key = "medicalwalerestapi";

    public function check_auth_client() {
        $client_service = $this->input->get_request_header('Client-Service', TRUE);
        $auth_key = $this->input->get_request_header('Auth-Key', TRUE);
        if ($client_service == $this->client_service && $auth_key == $this->auth_key) {
            return true;
        } else {
            return json_output(401, array(
                'status' => 401,
                'message' => 'Unauthorized.'
            ));
        }
    }

    public function auth() {
        date_default_timezone_set('Asia/Kolkata');
        $users_id = $this->input->get_request_header('User-ID', TRUE);
        $token = $this->input->get_request_header('Authorizations', TRUE);
        $q = $this->db->select('expired_at')->from('api_users_authentication')->where('users_id', $users_id)->where('token', $token)->get()->row();
        if ($q == "") {
            return json_output(401, array(
                'status' => 401,
                'message' => 'Unauthorized.'
            ));
        } else {
            if ($q->expired_at < date('Y-m-d H:i:s')) {
                return json_output(401, array(
                    'status' => 401,
                    'message' => 'Your session has been expired.'
                ));
            } else {
                $updated_at = date('Y-m-d H:i:s');
                $expired_at = '2030-11-12 08:57:58';
                $this->db->where('users_id', $users_id)->where('token', $token)->update('api_users_authentication', array(
                    'expired_at' => $expired_at,
                    'updated_at' => $updated_at
                ));
                return array(
                    'status' => 200,
                    'message' => 'Authorized.'
                );
            }
        }
    }

    public function encrypt($str) {
        $this->key = hash('MD5', '8655328655mdwale', true);
        $this->iv = hash('MD5', 'mdwale8655328655', true);
        $module = mcrypt_module_open(MCRYPT_RIJNDAEL_128, '', MCRYPT_MODE_CBC, '');
        mcrypt_generic_init($module, $this->key, $this->iv);
        $block = mcrypt_get_block_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC);
        $pad = $block - (strlen($str) % $block);
        $str .= str_repeat(chr($pad), $pad);
        $encrypted = mcrypt_generic($module, $str);
        mcrypt_generic_deinit($module);
        mcrypt_module_close($module);
        return base64_encode($encrypted);
    }

    public function decrypt($str) {
        $this->key = hash('MD5', '8655328655mdwale', true);
        $this->iv = hash('MD5', 'mdwale8655328655', true);
        $module = mcrypt_module_open(MCRYPT_RIJNDAEL_128, '', MCRYPT_MODE_CBC, '');
        mcrypt_generic_init($module, $this->key, $this->iv);
        $str = mdecrypt_generic($module, base64_decode($str));
        mcrypt_generic_deinit($module);
        mcrypt_module_close($module);
        $slast = ord(substr($str, -1));
        $str = substr($str, 0, strlen($str) - $slast);
        return $str;
    }

    public function cart_add($user_id,$listing_id,$product_id,$ipaddress,$product_name,$product_image,$product_price,$product_type,$quantity,$medicalname,$product_unit)
    {
        date_default_timezone_set('Asia/Kolkata');
        $date = date('Y-m-d H:i:s');
        $query = $this->db->query("SELECT product_id,ipaddress FROM `cart_session` WHERE ipaddress='$ipaddress' AND product_id='$product_id'");
        if($query->num_rows() ==0)
        {
            $cart_add_array = array(
                'user_id' =>$user_id ,
                'listing_id' => $listing_id,
                'product_id' => $product_id,
                'quantity' => $quantity,
                'product_name' => $product_name,
                'product_image' => $product_image,
                'product_price' => $product_price,
                'product_type' => $product_type,
                'listing_name' => $medicalname,
                'product_unit' => $product_unit,
                'created_at' => $date,
                'updated_at' => $date,
                'ipaddress' => $ipaddress
            );

            $this->db->insert('cart_session', $cart_add_array);
             $cart_view = $this->db->select('id')->from('cart_session')->where('ipaddress', $ipaddress)->get()->num_rows();

            return array(
                'status' => 200,
                'message' => 'success',
                'cart_view' => $cart_view
            );
        }
        else
        {
             return array(
                'status' => 400,
                'message' => 'Failed'
            );
        }
    }

    public function cart_details($ipaddress) {
        $resultpost =array();
        $query = $this->db->query("SELECT * FROM `cart_session` WHERE ipaddress='$ipaddress'");
        foreach ($query->result_array() as $row) {

            $resultpost[] = array
                (
                   "id" => $row['id'],
                   "user_id" => $row['user_id'],
                   "listing_id" => $row['listing_id'],
                   "product_id" => $row['product_id'],
                   "quantity" => $row['quantity'],
                   "product_name" => $row['product_name'],
                   "product_image" => $row['product_image'],
                   "product_price" => $row['product_price'],
                   "product_type" => $row['product_type'],
                   "listing_name" => $row['listing_name'],
                   "product_unit" => $row['product_unit'],

                );
        }
        return $resultpost;
    }

    public function remove_cart($ipaddress,$product_id,$user_id) {
        $resultpost =array();
        $query = $this->db->query("SELECT * FROM `cart_session` WHERE ipaddress='$ipaddress' AND product_id='$product_id'");
        if($query->num_rows()>0)
        {
            $this->db->where('ipaddress',$ipaddress);
            $this->db->where('product_id',$product_id);
            if(!empty($user_id)){
                $this->db->where('user_id',$user_id);
            }
            $this->db->delete('cart_session');
            $resultpost = array
                (
                    'status' => 200,
                    'message' => 'success',
                );
        }
        else
        {
            $resultpost = array
                (
                    'status' => 400,
                    'message' => 'Failed',
                );
        }
        return $resultpost;
    }
    public function update_quantity($ipaddress,$product_id,$quantity,$user_id) {
        $resultpost =array();
        $update= array('quantity' => $quantity);
        $query = $this->db->query("SELECT * FROM `cart_session` WHERE ipaddress='$ipaddress' AND product_id='$product_id'");
        if($query->num_rows()>0)
        {
            $this->db->where('ipaddress',$ipaddress);
            $this->db->where('product_id',$product_id);
            if(!empty($user_id)){
                $this->db->where('user_id',$user_id);
            }
            $this->db->update('cart_session',$update);
            $resultpost = array
                (
                    'status' => 200,
                    'message' => 'success',
                );
        }
        else
        {
            $resultpost = array
                (
                    'status' => 400,
                    'message' => 'Failed',
                );
        }
        return $resultpost;
    }


    public function remove_cart_alls($ipaddress,$user_id) {
        $resultpost =array();
        $query = $this->db->query("SELECT * FROM `cart_session` WHERE ipaddress='$ipaddress' AND user_id='$user_id'");
        if($query->num_rows()>0)
        {
            $this->db->where('ipaddress',$ipaddress);
            $this->db->where('user_id',$user_id);

            $this->db->delete('cart_session');
            $resultpost = array
                (
                    'status' => 200,
                    'message' => 'success',
                );
        }
        else
        {
            $resultpost = array
                (
                    'status' => 400,
                    'message' => 'Failed',
                );
        }
        return $resultpost;
    }
    
    
    public function order_add_cart($user_id,$cart_details)
    {
        date_default_timezone_set('Asia/Kolkata');
        $date = date('Y-m-d H:i:s');
        
        $cart = json_decode($cart_details,TRUE);
        $count = count($cart['list']);
      //echo $count;
        
             $actual_image_path = '';
             if(!empty($_FILES["image"]["name"]))
            {
                
                 if (!empty($_FILES["image"]["name"])) {
                        $image = count($_FILES['image']['name']);
                        $img_format = array("jpg", "png", "gif", "bmp", "jpeg", "PNG", "JPG", "JPEG", "GIF", "BMP");
                        include('s3_config.php');
                        date_default_timezone_set('Asia/Calcutta');
                       // $invoice_no = date("YmdHis");
                      //  $order_status = 'Awaiting Confirmation';
                    }
                    if ($image > 0) {
                        foreach ($_FILES['image']['tmp_name'] as $key => $tmp_name) {
                            $img_name = $key . $_FILES['image']['name'][$key];
                            $img_size = $_FILES['image']['size'][$key];
                            $img_tmp = $_FILES['image']['tmp_name'][$key];
                            $ext = getExtension($img_name);
                            if (strlen($img_name) > 0) {
                                if ($img_size < (50000 * 50000)) {
                                    if (in_array($ext, $img_format)) {
                                        $actual_image_name = uniqid() . date("YmdHis") . "." . $ext;
                                        $actual_image_path = 'images/prescription_images/' . $actual_image_name;
                                        if ($s3->putObjectFile($img_tmp, $bucket, $actual_image_path, S3::ACL_PUBLIC_READ)) {
                                         //  $p = 'pre';
                                           $p = md5(uniqid(rand(), true));
                                            //$this->db->query("INSERT INTO `prescription_order_details`(`order_id`, `prescription_image`,`order_status`, `uni_id`) VALUES ('$order_id', '$actual_image_name','$order_status', '$invoice_no')");
                                         $p_results = $this->db->query("INSERT INTO `user_card_order` (`user_id`, `listing_id`, `listing_type`,`product_id`,`offline_prescription`,`date`,`is_prescription`) VALUES ('$user_id', '0', '13','$p','$actual_image_path','$date','YES')");
                                        }
                                    }
                                }
                            }
                        }
                    }
                
            }
        
        if($count > 0)
        {
        for($i = 0; $i < $count; $i++) {
          // echo 'enter in loop'.$i;
            $product_id = $cart['list'][$i]['product_id'];
            $product_qty = $cart['list'][$i]['quantity'];
             
       
            $prescrition_type = $cart['list'][$i]['prescrition_type'];
            if($prescrition_type == 'E-pre')
            {
               $product_id =  md5(uniqid(rand(), true));
               $is_prescription = 'YES';
            }
            else
            {
                $is_prescription = 'NO';
            }
            
            $listing_type = $cart['list'][$i]['listing_type'];
            
            if(!empty($cart['list'][$i]['prescription_id'])){
                $prescription_id = $cart['list'][$i]['prescription_id'];   
            } else {
                $prescription_id = 0;
            }
            $prescription_url = $cart['list'][$i]['prescription_url'];
             if(!empty($cart['list'][$i]['prescription_url'])){
                $prescription_url = $cart['list'][$i]['prescription_url'];   
            } else {
                $prescription_url = '';
            }
            if(!empty($cart['list'][$i]['total_product_price'])){
                $total_product_price = $cart['list'][$i]['total_product_price'];   
            } else {
                $total_product_price = 0;
            }
            $checkAvailable = $this->db->query("SELECT * FROM `user_card_order` WHERE `user_id` = '$user_id' AND `product_id` = '$product_id'");
        $count1 = $checkAvailable->num_rows();
        if($count1 != 0){
            $this->db->query("DELETE FROM `user_card_order` WHERE `product_id` = '$product_id' AND `user_id` = '$user_id'");
            $results = $this->db->query("INSERT INTO `user_card_order` (`user_id`, `listing_id`, `listing_type`, `product_id`,  `quantity`, `prescription_id`, `prescription_url`,`total_product_price`,`date`,`is_prescription`) VALUES ('$user_id', '0', '$listing_type', '$product_id',  '$product_qty', '$prescription_id','$prescription_url','$total_product_price','$date','$is_prescription')");
    	    $insert_id = $this->db->insert_id();
    	    if($insert_id){
    	           $checkAvailablec = $this->db->query("SELECT 'user_id' FROM `user_card_order` WHERE `user_id` = '$user_id'");
                  $stack_count = $checkAvailablec->num_rows();
    	        
    	        return array(
                    "status" => 200,
                    "message" => "success",
                    "stack_count" => $stack_count
                );
    	    } else {
    	        return array(
                    "status" => 400,
                    "message" => "fail"
                );
                
    	    }
            
        } 
        else
        {
             $results = $this->db->query("INSERT INTO `user_card_order` (`user_id`, `listing_id`, `listing_type`, `product_id`,  `quantity`, `prescription_id`, `prescription_url`,`total_product_price`,`date`,`is_prescription`) VALUES ('$user_id', '0', '$listing_type', '$product_id',  '$product_qty', '$prescription_id','$prescription_url',$total_product_price,'$date','$is_prescription')");
    	    $insert_id = $this->db->insert_id();
    	    if($insert_id){
    	        
    	         $checkAvailablec = $this->db->query("SELECT 'user_id' FROM `user_card_order` WHERE `user_id` = '$user_id'");
                  $stack_count = $checkAvailablec->num_rows();
    	        
    	        return array(
                    "status" => 200,
                    "message" => "success",
                    "description" => "Successfully added to Stack",
                    "stack_count" => $stack_count
                );
    	    }
    	    else
    	    {
    	        return array(
                    "status" => 400,
                    "message" => "fail",
                    "description" => "Something went wrong, please try again",
                );
             
    	    }
        }
            
            
    }
    
        }
        else
        {
            if($actual_image_path !== '')
            {
                
                
                   $checkAvailablec = $this->db->query("SELECT 'user_id' FROM `user_card_order` WHERE `user_id` = '$user_id'");
                  $stack_count = $checkAvailablec->num_rows();
                  return array(
                    "status" => 200,
                    "message" => "success",
                    "description" => "Successfully added to Stack",
                    "stack_count" => $stack_count
                );
            }
            else
            {
                 return array(
                   "status" => 400,
                    "message" => "fail",
                    "description" => "Something went wrong, please try again",
                );
            }
        }
    
    
    }

    public function remove_user_cart($user_id,$product_id,$listing_type)
    {
         $checkAvailable = $this->db->query("SELECT `user_id` FROM `user_card_order` WHERE `user_id` = '$user_id' AND `product_id` = '$product_id' AND `listing_type` = '$listing_type'");
       //  echo "SELECT `user_id` FROM `user_card_order` WHERE `user_id` = '$user_id' AND `product_id` = '$product_id' AND `listing_type` = '$listing_type'";
        $count = $checkAvailable->num_rows();
        if($count != 0){
            $this->db->query("DELETE FROM `user_card_order` WHERE `product_id` = '$product_id' AND `user_id` = '$user_id' AND `listing_type` = '$listing_type'");
              return array(
                    "status" => 200,
                    "message" => "success",
                    "description" => "Successfully Deleted from Stack"
                );
        }
        else
        {
            return array(
                   "status" => 400,
                    "message" => "fail",
                    "description" => "No cart available to delete",
                );
        }
    }
    
    
    public function all_user_cart_list($user_id)
    {
         $checkAvailable = $this->db->query("SELECT * FROM `user_card_order` WHERE `user_id` = '$user_id' AND is_prescription = 'YES'");
        $count = $checkAvailable->num_rows();
        if($count > 0){
           
          foreach ($checkAvailable->result_array() as $row) {
              
              if($row['prescription_url'] == '')
              {
                  $prescription_type = 'O-pre';
              }
              else
              {
                  $prescription_type = 'E-pre';
              }

            $prescription_array[] = array
                (
                   "id" => $row['id'],
                   "user_id" => $row['user_id'],
                   "listing_id" => $row['listing_id'],
                   "listing_type" => $row['listing_type'],
                   "product_id" => $row['product_id'],
                   "prescription_url" => $row['prescription_url'],
                   "prescription_id" => $row['prescription_id'],
                   "offline_prescription" => 'https://d2c8oti4is0ms3.cloudfront.net/'.$row['offline_prescription'],
                   "product_quantity" => $row['quantity'],
                   "product_name" => "",
                 //$row['product_image']
                 "product_image" => 'https://d2c8oti4is0ms3.cloudfront.net/images/product_images/',
                   "product_price" => $row['total_product_price'],
                   "date"         => $row['date'],
                   "prescription_type"  => $prescription_type
                );
        }
           
        }
        else
        {
             $prescription_array = array();
        }
        
       
        $checkAvailable1 = $this->db->query("SELECT * FROM `user_card_order` WHERE `user_id` = '$user_id' AND is_prescription = 'NO'");
        $count1 = $checkAvailable1->num_rows();
        if($count1 > 0){
           
          foreach ($checkAvailable1->result_array() as $row) {
               $pro_id = $row['product_id'];
                $query = $this->db->query("SELECT product_name,product_price,image FROM `product` WHERE id='$pro_id'");
               foreach ($query->result_array() as $mrow) {
                         
                       
                           $product_price = $mrow['product_price'];
                           $product_name = $mrow['product_name'];
                          // echo 'name is ='.$mrow['product_name'];
                           $product_img = $mrow['image'];
        
               }

            $Medicine_array[] = array
                (
                   "id" => $row['id'],
                   "user_id" => $row['user_id'],
                   "listing_id" => $row['listing_id'],
                   "listing_type" => $row['listing_type'],
                   "product_id" => $row['product_id'],
                   "prescription_url" => 'https://d2c8oti4is0ms3.cloudfront.net/'.$row['prescription_url'],
                   "prescription_id" => $row['prescription_id'],
                   "offline_prescription" => 'https://d2c8oti4is0ms3.cloudfront.net/'.$row['offline_prescription'],
                   "product_quantity" => $row['quantity'],
                   "product_name" => $product_name,
                  "product_image" => 'https://d2c8oti4is0ms3.cloudfront.net/images/product_images/'.$product_img,
                   "product_price" => $row['total_product_price'],
                   "date"         => $row['date'],
                   "prescription_type"  => ""
                );
        }
           
        }
        else
        {
             $Medicine_array = array();
        }
        
        
        return array(
                    'prescrption_data' => $prescription_array,
                    'medicine_product_data' => $Medicine_array
            );
    }

}
?>
