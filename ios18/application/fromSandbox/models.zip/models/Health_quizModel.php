<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Health_quizModel extends CI_Model {

    var $client_service = "frontend-client";
    var $auth_key = "medicalwalerestapi";

    public function check_auth_client() {
        $client_service = $this->input->get_request_header('Client-Service', TRUE);
        $auth_key = $this->input->get_request_header('Auth-Key', TRUE);
        if ($client_service == $this->client_service && $auth_key == $this->auth_key) {
            return true;
        } else {
            return json_output(401, array(
                'status' => 401,
                'message' => 'Unauthorized.'
            ));
        }
    }

    public function auth() {
        date_default_timezone_set('Asia/Kolkata');
        $users_id = $this->input->get_request_header('User-ID', TRUE);
        $token = $this->input->get_request_header('Authorizations', TRUE);
        $q = $this->db->select('expired_at')->from('api_users_authentication')->where('users_id', $users_id)->where('token', $token)->get()->row();
        if ($q == "") {
            return json_output(401, array(
                'status' => 401,
                'message' => 'Unauthorized.'
            ));
        } else {
            if ($q->expired_at < date('Y-m-d H:i:s')) {
                return json_output(401, array(
                    'status' => 401,
                    'message' => 'Your session has been expired.'
                ));
            } else {
                 if ($q->expired_at < date("Y-m-d H:i:s", strtotime("-1 days"))) {
                return json_output(401, array(
                    'status' => 401,
                    'message' => 'Your session has been expired.'
                ));
            } else {
                $updated_at = date('Y-m-d H:i:s');
                $expired_at = date("Y-m-d H:i:s", strtotime("+1 days"));//'2020-12-12 08:57:58';
                $this->db->where('users_id', $users_id)->where('token', $token)->update('api_users_authentication', array(
                    'expired_at' => $expired_at,
                    'updated_at' => $updated_at
                ));
               // echo $this->db->last_query();
                return array(
                    'status' => 200,
                    'message' => 'Authorized.'
                );
            }
                
            }
        }
    }

    public function encrypt($str) {
        //echo $str;
        $this->key = hash('MD5', '8655328655mdwale', true);
        $this->iv = hash('MD5', 'mdwale8655328655', true);
        $module = mcrypt_module_open(MCRYPT_RIJNDAEL_128, '', MCRYPT_MODE_CBC, '');
        mcrypt_generic_init($module, $this->key, $this->iv);
        $block = mcrypt_get_block_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC);
        $pad = $block - (strlen($str) % $block);
        $str .= str_repeat(chr($pad), $pad);
        $encrypted = mcrypt_generic($module, $str);
        mcrypt_generic_deinit($module);
        mcrypt_module_close($module);
        return base64_encode($encrypted);
    }

    public function decrypt($str) {
        $this->key = hash('MD5', '8655328655mdwale', true);
        $this->iv = hash('MD5', 'mdwale8655328655', true);
        $module = mcrypt_module_open(MCRYPT_RIJNDAEL_128, '', MCRYPT_MODE_CBC, '');
        mcrypt_generic_init($module, $this->key, $this->iv);
        $str = mdecrypt_generic($module, base64_decode($str));
        mcrypt_generic_deinit($module);
        mcrypt_module_close($module);
        $slast = ord(substr($str, -1));
        $str = substr($str, 0, strlen($str) - $slast);
        return $str;
    }
    
    
    public function Get_all_quizdata($user_id,$test_no)
    {
         date_default_timezone_set('Asia/Kolkata');
        $system_date = date('Y-m-d H:i:s');
        $page = rand('00','99');
         $limit = 10;
        $start = 0;
        if ($page > 0 || $page > 00) {
            if (!is_numeric($page)) {
                $page = 1;
            }
        }
        $start = ($page - 1) * $limit;
        
        $sql = $this->db->query("select id,Question,Option1,Option2,Option3,Option4,Answer from health_quiz limit 10");
        $count = $sql->num_rows();
        
        if($count>0)
        {
            foreach($sql->result_array() as $row)
            {
                $id = $row['id'];
                $question = $row['Question'];
                $options1 = $row['Option1'];
                $options2 = $row['Option2'];
                $options3 = $row['Option3'];
                $options4 = $row['Option4'];
                $answer =   $row['Answer'];
                $point  = '5';
                $time   =  '10';
                
                
                
                $result_array[] = array(
                           'id' => $id,
                           'question' => $question,
                            'options' => array($options1,$options2,$options3,$options4),
                              'answer' => $answer,
                              'point'  => $point,
                              'time'   => $time,
                              'type'   => 'text',
                    );
                
            }
            
            return array('status' => '200',
                         'message' => "success",
                         'data' => $result_array
                        );
        }
        else
        {
            return array('status' => '200',
                         'message' => "success",
                         'data' => array()
                        );
        }
        
    }
    
    public function Get_result_data($user_id,$is_winner,$total_score,$total_question,$total_point,$opponent_id)
    {
         $system_date = date('Y-m-d');
           $health_quiz_result = array(
                'user_id' => $user_id,
                'opponent_id' => $opponent_id,
                'total_score' => $total_score,
                'total_question' => $total_question,
                'total_point'  => $total_point,
                'is_winner' => $is_winner,
                'date' => $system_date
            );
            $this->db->insert('health_quiz_result', $health_quiz_result);
            
             return array('status' => '200',
                         'message' => "success",
                         'data' => array()
                        );
    }
    
    public function Get_all_history($user_id)
	{
        date_default_timezone_set('Asia/Kolkata');
        $system_date = date('Y-m-d H:i:s');
        
        
        $sql = $this->db->query("select id,user_id,opponent_id,total_score,total_question,total_point,is_winner,date from health_quiz_result where user_id = '$user_id' order by id desc");
     
        $count = $sql->num_rows();
        
        if($count > 0)
        {
             foreach($sql->result_array() as $row)
            {
                $test_id = $row['id'];
                $user_id = $row['opponent_id'];
                $opponent_id = $row['opponent_id'];
                $total_score = $row['total_score'];
                $total_question = $row['total_question'];
                $total_point = $row['total_point'];
                $is_winner = $row['is_winner'];
                $date = $row['date'];
                
                
                 $result_array[] = array( 
                     'test_id' => $test_id,
                     'user_id' => $user_id,
                     'opponent_id' => $opponent_id,
                     'total_score'  => $total_score,
                     'total_question' => $total_question,
                     'total_point'  => $total_point,
                     'is_winner'   => $is_winner,
                     'date'     => $date
                     );
            }
            
            return array('status' => '200',
                         'message' => "success",
                         'data' => $result_array
                        );
        }
        else
        {
            return array('status' => '200',
                         'message' => "success",
                         'data' => array()
                        );
        }
	}
    
    
}