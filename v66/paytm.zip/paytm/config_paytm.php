<?php
//Change the value of PAYTM_MERCHANT_KEY constant with details received from Paytm.
define('PAYTM_ENVIRONMENT', 'TEST'); // PROD
define('PAYTM_MERCHANT_KEY', '2eYq1XbYo@69%WYn'); //Change this constant's value with Merchant key received from Paytm.
define('PAYTM_MERCHANT_MID', 'AEGISH99513189108451'); //Change this constant's value with MID (Merchant ID) received from Paytm.
define('PAYTM_MERCHANT_WEBSITE', 'APPSTAGING'); //Change this constant's value with Website name received from Paytm.

?>
