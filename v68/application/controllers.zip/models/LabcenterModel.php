<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class LabcenterModel extends CI_Model
{
    var $client_service = "frontend-client";
    var $auth_key = "medicalwalerestapi";
    public function check_auth_client()
    {
        $client_service = $this->input->get_request_header('Client-Service', TRUE);
        $auth_key       = $this->input->get_request_header('Auth-Key', TRUE);
        if ($client_service == $this->client_service && $auth_key == $this->auth_key) {
            return true;
        } else {
            return json_output(401, array(
                'status' => 401,
                'message' => 'Unauthorized.'
            ));
        }
    } 
    public function auth()
    {
        date_default_timezone_set('Asia/Kolkata');
        $users_id = $this->input->get_request_header('User-ID', TRUE);
        $token    = $this->input->get_request_header('Authorizations', TRUE);
        $q        = $this->db->select('expired_at')->from('api_users_authentication')->where('users_id', $users_id)->where('token', $token)->get()->row();
        if ($q == "") {
            return json_output(401, array(
                'status' => 401,
                'message' => 'Unauthorized.'
            ));
        } else {
             if ($q->expired_at < date("Y-m-d H:i:s", strtotime("-1 days"))) {
                return json_output(401, array(
                    'status' => 401,
                    'message' => 'Your session has been expired.'
                ));
            } else {
                $updated_at = date('Y-m-d H:i:s');
                $expired_at = '2030-11-12 08:57:58';
                $this->db->where('users_id', $users_id)->where('token', $token)->update('api_users_authentication', array(
                    'expired_at' => $expired_at,
                    'updated_at' => $updated_at
                ));
               // echo $this->db->last_query();
                return array(
                    'status' => 200,
                    'message' => 'Authorized.'
                );
            }
        }
    }
    public function encrypt($str)
    {
        $this->key = hash('MD5', '8655328655mdwale', true);
        $this->iv  = hash('MD5', 'mdwale8655328655', true);
        $module    = mcrypt_module_open(MCRYPT_RIJNDAEL_128, '', MCRYPT_MODE_CBC, '');
        mcrypt_generic_init($module, $this->key, $this->iv);
        $block = mcrypt_get_block_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC);
        $pad   = $block - (strlen($str) % $block);
        $str .= str_repeat(chr($pad), $pad);
        $encrypted = mcrypt_generic($module, $str);
        mcrypt_generic_deinit($module);
        mcrypt_module_close($module);
        return base64_encode($encrypted);
    }
    public function decrypt($str)
    {
        $this->key = hash('MD5', '8655328655mdwale', true);
        $this->iv  = hash('MD5', 'mdwale8655328655', true);
        $module    = mcrypt_module_open(MCRYPT_RIJNDAEL_128, '', MCRYPT_MODE_CBC, '');
        mcrypt_generic_init($module, $this->key, $this->iv);
        $str = mdecrypt_generic($module, base64_decode($str));
        mcrypt_generic_deinit($module);
        mcrypt_module_close($module);
        $slast = ord(substr($str, -1));
        $str   = substr($str, 0, strlen($str) - $slast);
        return $str;
    } 
    
    public function vendor_details($vendor_id,$user_id)
    {
        $sql = sprintf("SELECT id,user_id,profile_pic,lab_name,features FROM lab_center where user_id='$vendor_id'");
        $query = $this->db->query($sql);
                $count = $query->num_rows();
                if ($count > 0) {
                    $row=$query->row_array();
                        $id = $row['id'];
                        $labcenter_user_id = $row['user_id'];
                        $lab_name = $row['lab_name'];
                        $features = $row['features'];
                        $rating = '4.0';
                        $profile_views = '1548';
                        $reviews = '1000';
                        $image = $row['profile_pic'];
                        $image = 'https://d2c8oti4is0ms3.cloudfront.net/images/labcenter_images/' . $image;

                        $testInfo = $this->db->query("SELECT GROUP_CONCAT(feature) as feature FROM `lab_features` INNER JOIN lab_center on FIND_IN_SET(lab_features.id, lab_center.features) where lab_center.user_id='$vendor_id'")->row_array();
                        $certification=$testInfo['feature'];

                        $followers = $this->db->select('id')->from('follow_user')->where('parent_id', $vendor_id)->get()->num_rows();
                        $following = $this->db->select('id')->from('follow_user')->where('user_id', $vendor_id)->get()->num_rows();
                        $is_follow = $this->db->select('id')->from('follow_user')->where('user_id', $user_id)->where('parent_id', $vendor_id)->get()->num_rows();
                       
                        if ($is_follow > 0) {
                            $is_follow = 'Yes';
                        } else {
                            $is_follow = 'No';
                        }

                $package_list = array();
                $package_query = $this->db->query("SELECT lm.id,lm.code,lm.name,lm.home_collection_charges,lm.price,lm.discounted_price,count(pd.id) as test_count FROM lab_package_master lm INNER JOIN lab_package_test_master pd on pd.package_id=lm.id  WHERE lm.user_id='$vendor_id' GROUP BY pd.package_id");
                $package_count = $package_query->num_rows();
                if ($package_count > 0) {
                    foreach ($package_query->result_array() as $package_row) {
                        $package_id = $package_row['id'];
                        $code = $package_row['code'];
                        $name = $package_row['name'];
                        $home_collection_charges = $package_row['home_collection_charges'];
                        $price = $package_row['price'];
                        $discounted_price = $package_row['discounted_price'];
                        $test_count = $package_row['test_count'];
                        $package_list[] = array(
                            'id' => $package_id,
                            'code' => $code,
                            'name' => $name,
                            'home_collection_charges' => $home_collection_charges,
                            'price' => $price,
                            'discounted_price' => $discounted_price,
                            'test_count' => $test_count
                        );
                    }
                } else {
                    $package_list = array();
                }
                

                $test_list = array();
                $test_query       = $this->db->query("SELECT lt.name,ld.code,ld.report_availability,ld.home_collection_charges,ld.price,ld.discounted_price,ld.discount,ld.medicalwale_discount from lab_test_master_details ld INNER JOIN lab_test_master lt on lt.id=ld.test_id where ld.user_id='4684'");
                $test_count       = $test_query->num_rows();
                if ($test_count > 0) {
                    foreach ($test_query->result_array() as $test_row) {
                        $name        = $test_row['name'];
                        $code           = $test_row['code'];
                        $report_availability        = $test_row['report_availability'];
                        $home_collection_charges          = $test_row['home_collection_charges'];
                        $price          = $test_row['price'];
                        $discounted_price = $test_row['discounted_price'];
                        $discount  = $test_row['discount'];
                        $medicalwale_discount  = $test_row['medicalwale_discount'];
                        $test_list[] = array(
                            'name' => $name,
                            'code' => $code,
                            'report_availability' => $report_availability,
                            'home_collection_charges' => $home_collection_charges,
                            'price' => $price,
                            'discounted_price' => $discounted_price,
                            'discount' => $discount,
                            'medicalwale_discount' => $medicalwale_discount
                        );
                    }
                } else {
                    $test_list  = array();
                }
                
                $resultpost[] = array(
                    "id" => $vendor_id,
                    "name" => $lab_name,
                    "certification" => $certification,
                    "rating" => $rating,
                    "followers" => $followers,
                    "following" => $following,
                    "profile_views" => $profile_views,
                    "reviews" => $reviews,
                    "is_follow" => $is_follow,
                    "image" => $image,
                    "package_list"=> $package_list,
                    "test_list"=>$test_list
                );
        
                } else {
                    $resultpost = array();
                }
            return $resultpost;
    }
    
    public function booking_summary($booking_id)
    {
        $query = $this->db->query("SELECT lt.listing_id as vendor_id,lt.id,lab_booking_details.address_id,lab_booking_details.created_at,lt.patient_id as member_id,lt.user_id as parent_id,lt.booking_time,ud.address2,ud.address_type,ud.city,ud.address1,ud.full_address,ud.landmark,ud.lat,ud.lng,ud.mobile,ud.name,ud.pincode,ud.relation_ship as relation,ud.state,pm.payment_method,pm.icon,pm.id as payment_id,lab_booking_details.test_id,lab_booking_details.total_cost,lab_booking_details.total_discount,lab_booking_details.amount from booking_master lt LEFT JOIN lab_booking_details on lab_booking_details.booking_id=lt.booking_id LEFT JOIN user_address ud on ud.address_id=lab_booking_details.address_id LEFT JOIN payment_method pm on pm.id=lt.payment_mode where lt.booking_id='$booking_id' limit 1");
		$num_count  = $query->num_rows();
        if ($num_count > 0) {
        $list = $query->row_array();
        $test_array=array();
        $package_array=array();
        $test_query = $this->db->query("SELECT ld.code,ld.report_availability,ld.home_collection_charges,ld.price,ld.discounted_price,ld.discount,ld.medicalwale_discount,lab_test_master.name,lab_test_master.id from lab_test_master_details ld INNER JOIN lab_test_master on lab_test_master.id=ld.test_id INNER JOIN lab_booking_details on FIND_IN_SET(lab_booking_details.test_id, lab_test_master.id) where lab_booking_details.booking_id='$booking_id'");
        $test_count  = $test_query->num_rows();
                if ($test_count > 0) {
                    $test_row = $test_query->result();
                    foreach ($test_row as $test_list) {
                        $testid  = $test_list->id;
                        $test_name  = $test_list->name;
                        $code  = $test_list->code;
                        $report_availability  = $test_list->report_availability;
                        $home_collection_charges  = $test_list->home_collection_charges;
                        $price  = $test_list->price;
                        $discounted_price  = $test_list->discounted_price;
                        $discount  = $test_list->discount;
                        $medicalwale_discount  = $test_list->medicalwale_discount;
                        $test_array[] = array(
                            'test_id' => $testid,
                            'test_name' => $test_name,
                            'code' => $code,
                            'report_availability' => 'E-reports with in 24 hours post sample collection',
                            'home_collection_charges' => $home_collection_charges,
                            'price' => $price,
                            'discounted_price' => $discounted_price,
                            'discount' => $discount,
                            'medicalwale_discount' => $medicalwale_discount,
                            'home_delivery' => "0"
                        );
                    }
                }
        
        $vendor_id=$list['vendor_id'];
        $feature = $this->db->query("SELECT GROUP_CONCAT(feature) as feature,lab_center.lab_name FROM `lab_features` INNER JOIN lab_center on FIND_IN_SET(lab_features.id, lab_center.features) where lab_center.user_id='$vendor_id'")->row_array();
        $certification = $feature['feature'];
        $vendor_name   = $feature['lab_name'];
        
        $details[] = array(
            'address1' => $list['address1'],
            'address2' => $list['address2'],
            'address_id' => $list['address_id'],
            'address_type' => $list['address_type'],
            'city' => $list['city'],
            'date' => $list['created_at'],
            'full_address' => $list['full_address'],
            'landmark' => $list['landmark'],
            'lat' => $list['lat'],
            'lng' => $list['lng'],
            'member_id' => $list['member_id'],
            'mobile' => $list['mobile'],
            'name' => $list['name'],
            'parent_id' => $list['parent_id'],
            'icon' => $list['icon'],
            'payment_id' => $list['payment_id'],
            'payment_method' => $list['payment_method'],
            'pincode' => $list['pincode'],
            'relation' => $list['relation'],
            'state' => $list['state'],
            'time' => $list['booking_time'],
            'vendor_id' => $vendor_id,
            'vendor_name' => $vendor_name,
            'certification' => $certification,
            'rating' => 0,
            'test_list' => $test_array,
            'package_list' => $package_array
        );
		return array(
            'status' => 200,
            'message' => 'success',
            'data' => $details
        );
		}
		else{
			$details=array();
			return array(
				'status' => 200,
				'message' => 'success',
				'data' => $details
			);
		}
    }
        
    public function update_payment_method($booking_id,$ledger_id,$payment_type)
    {
        $test_query = $this->db->query("SELECT * from user_vendor_ledger where ledger_id='$ledger_id' and invoice_no='$booking_id'");
        $num_count  = $test_query->num_rows();
        if($num_count>0){
            $list = $test_query->row_array();
            $user_id = $list['user_id'];
            $invoice_no = $list['invoice_no'];
            $ledger_owner_type = $list['ledger_owner_type'];
            $transaction_id = '';
            $listing_id = $list['listing_id'];
            $listing_id_type = $list['listing_id_type'];
            $credit = $list['credit'];
            $debit = $list['debit'];
            $balance = $list['balance'];
            $payment_method = $list['payment_method'];
            $transaction_of = $list['transaction_of'];
            $trans_status = "";
            $order_type = $list['order_type'];
            $user_comments = $list['user_comments'];
            $mw_comments = $list['mw_comments'];
            $vendor_comments = $list['vendor_comments'];
            $ledger_type='user';
            $payment_status='3';
            $update_data = array(
                'payment_mode' => $payment_type
            );
            $this->db->where('booking_id', $booking_id);
            $rst = $this->db->update('booking_master', $update_data);
            $res = $this->LedgerModel->update_ledger($user_id,$ledger_id,$booking_id,$transaction_id,$payment_status,$ledger_type);
            $res = $this->LedgerModel->create_ledger($user_id,$invoice_no,$ledger_owner_type, $listing_id, $listing_id_type, $credit, $debit, $payment_type, $user_comments, $mw_comments,$vendor_comments,$order_type,$transaction_of,$transaction_id,$trans_status);
			$ledger_id   = $res['ledger_id'];
			$ledger_type = $res['type'];
			
        }
			
        $response[] = array(
            'booking_id' => $invoice_no,
            'ledger_id' => $ledger_id,
            'ledger_type' => $ledger_type
        );
        return array(
            'status' => 200,
            'message' => 'success',
            'data' => $response
        );
    }
    
    public function update_order($booking_id,$ledger_id,$transaction_id,$payment_status,$ledger_type)
    {
        $update_data = array(
            'payment_mode' => $payment_status
        );
        $this->db->where('booking_id', $booking_id);
        $rst = $this->db->update('booking_master', $update_data);
        $user = $this->db->query("SELECT user_id from booking_master where booking_id='$booking_id' limit 1")->row_array();
        $user_id = $user['user_id'];
        $this->db->query("DELETE FROM `lab_vendor_cart` WHERE user_id='$user_id'");
        $this->db->query("DELETE FROM `lab_test_cart` WHERE user_id='$user_id'");
        $res = $this->LedgerModel->update_ledger($user_id,$ledger_id,$booking_id,$transaction_id,$payment_status,$ledger_type);
        return array(
            'status' => 200,
            'message' => 'success'
        );
    }

    
    public function add_order($user_id,$vendor_id,$address_id,$vendor_type,$booking_date,$booking_time,$package_id,$test_id,$member_id,$payment_type)
    {
	    
	    $ledger_id=0;
		$ledger_type=0;
        date_default_timezone_set('Asia/Kolkata');
        $invoice_no = date("YmdHis");
        if(count($test_id>0)){
            if($member_id>0){
                $user = $this->db->query("SELECT name,email,phone,gender from users where id='$member_id' limit 1")->row_array();
            }else{
                $user = $this->db->query("SELECT name,email,phone,gender from users where id='$user_id' limit 1")->row_array();
            }
            
            $lab_test_order = array(
                'booking_id' => $invoice_no,
                'user_id' => $user_id,
                'listing_id' => $vendor_id,
                'vendor_id' => $vendor_type,
                'booking_date' => $booking_date,
                'booking_time' => $booking_time,
                'patient_id' => $member_id,
                'payment_mode' => $payment_type,
                'user_name' => $user['name'],
                'user_mobile' => $user['email'],
                'user_email' => $user['phone'],
                'user_gender' => $user['gender'],
                'status' => 'Pending'
            );
            $this->db->insert('booking_master', $lab_test_order);
            
            $test_id = rtrim($test_id, ',');
            $test_list = explode(',',$test_id);
			$debit=0;
			$total_discount=0;
			$total_cost=0;
			$test_list_array='';
            foreach ($test_list as $tid) {
                if($tid>0){
                    $test_query = $this->db->query("SELECT home_collection_charges,price,discounted_price,discount,medicalwale_discount from lab_test_master_details where test_id='$tid' and user_id='$vendor_id' limit 1");
                    $test_list = $test_query->row_array();
					$debit+=$test_list['home_collection_charges']+$test_list['discounted_price'];
					$total_discount+=$total_discount+($test_list['price']-$test_list['discounted_price']);
			        $total_cost+=$test_list['home_collection_charges']+$test_list['price'];
                }
            }
            $adress_list = $this->db->query("SELECT address1,address2,mobile,email,city,state,pincode from user_address where user_id='$user_id' limit 1")->row_array();
            $lab_test_order_details = array(
                'booking_id' => $invoice_no,
                'user_id' => $user_id,
                'listing_id' => $vendor_id,
                'vendor_type' => $vendor_type,
                'test_id' => $test_id,
                'amount' => $debit,
                'total_cost' => $total_cost,
                'total_discount' => $total_discount,
                'booking_date' => $booking_date,
                'booking_time' => $booking_time,
                'address_id' => $address_id,
                'address_line1' => $adress_list['address1'],
                'address_line2' => $adress_list['address2'],
                'city' => $adress_list['city'],
                'state' => $adress_list['state'],
                'pincode' => $adress_list['pincode'],
                'mobile_no' => $adress_list['mobile'],
                'email_id' => $adress_list['email']
            );
            $this->db->insert('lab_booking_details', $lab_test_order_details);
            if($invoice_no>0){
				$ledger_owner_type='0';
				$listing_id_type='31';
				$credit='';
				$user_comments='';
				$mw_comments='';
				$vendor_comments='';
				$order_type='2';
				$transaction_of='3';
				$transaction_id='';
				$trans_status='';
                $res=$this->LedgerModel->create_ledger($user_id, $invoice_no, $ledger_owner_type, $vendor_id, $listing_id_type, $credit, $debit, $payment_type, $user_comments, $mw_comments,$vendor_comments,$order_type,$transaction_of,$transaction_id,$trans_status);
				$ledger_id=$res['ledger_id'];
				$ledger_type=$res['type'];
            }
			
            $response[] = array(
                'booking_id' => $invoice_no,
                'ledger_id' => $ledger_id,
                'ledger_type' => $ledger_type
            );
            return array(
                'status' => 200,
                'message' => 'success',
                'data' => $response
            );
        }
        if(count($package_id>0)){
            
        }
       
    }
    
    public function addtocart($user_id,$test_id,$vendor_id)
    {
        if($test_id==0){
            $this->db->query("DELETE FROM `lab_vendor_cart` WHERE user_id='$user_id'");
            $this->db->query("DELETE FROM `lab_test_cart` WHERE user_id='$user_id'");
        }
        //$this->db->query("DELETE FROM `lab_test_cart` WHERE user_id='$user_id'");
        $this->db->query("DELETE FROM `lab_vendor_cart` WHERE user_id='$user_id'");
        $test_id = rtrim($test_id, ',');
        $test_list = explode(',',$test_id);
        foreach ($test_list as $tid) {
            $cart_query = $this->db->query("SELECT id from lab_vendor_cart where test_id='$tid' and user_id='$user_id' and vendor_id='$vendor_id'");
            $count  = $cart_query->num_rows();
            if($tid>0 && $count==0){
                $test_cart = array(
                    'user_id' => $user_id,
                    'vendor_id' => $vendor_id,
                    'test_id' => $tid
                );
                $this->db->insert('lab_vendor_cart', $test_cart);
            }
        }
        return array(
            'status' => 200,
            'message' => 'success'
        );
    }
    
    public function add_package($user_id,$package_id,$vendor_id)
    {
        if($package_id==0){
            $this->db->query("DELETE FROM `lab_package_cart` WHERE user_id='$user_id'");
        }
        //$this->db->query("DELETE FROM `lab_test_cart` WHERE user_id='$user_id'");
        $this->db->query("DELETE FROM `lab_package_cart` WHERE user_id='$user_id'");
        $package_id = rtrim($package_id, ',');
        $package_list = explode(',',$package_id);
        foreach ($package_list as $pid) {
            $cart_query = $this->db->query("SELECT id from lab_package_cart where package_id='$pid' and user_id='$user_id' and vendor_id='$vendor_id'");
            $count  = $cart_query->num_rows();
            if($pid>0 && $count==0){
                $package_cart = array(
                    'user_id' => $user_id,
                    'vendor_id' => $vendor_id,
                    'package_id' => $pid
                );
                $this->db->insert('lab_package_cart', $package_cart);
            }
        }
        return array(
            'status' => 200,
            'message' => 'success'
        );
    }
    
    public function addtestcart($user_id,$test_id,$vendor_id,$clear_all)
    {
        $test_id = rtrim($test_id, ',');
        $test_list = explode(',',$test_id);
        if($clear_all=='1'){
            $this->db->query("DELETE FROM `lab_vendor_cart` WHERE user_id='$user_id'");
            $this->db->query("DELETE FROM `lab_test_cart` WHERE user_id='$user_id'");
            return array(
                    'status' => 200,
                    'message' => 'success'
                );
        }
        else{
            if($vendor_id>0){
                $flag=0;
                foreach ($test_list as $tid) {
                    $cart_query = $this->db->query("SELECT id from lab_test_master_details where test_id='$tid' and user_id='$vendor_id'");
                    $count  = $cart_query->num_rows();
                    if ($count==0) {
                        $flag=1;
                        break;
                    }
                }
                if($flag>0){
                    return array(
                        'status' => 200,
                        'message' => 'success',
                        'is_vendor'=> 0
                    );
                }
                else{
                    foreach ($test_list as $tid) {
                        if($tid>0){
                            $test_cart = array(
                                'user_id' => $user_id,
                                'test_id' => $tid
                            );
                            $this->db->insert('lab_test_cart', $test_cart);
                        }
                    }
                    return array(
                        'status' => 200,
                        'message' => 'success',
                        'is_vendor'=> 1
                    );
                }
            }
            else{
                $this->db->query("DELETE FROM `lab_test_cart` WHERE user_id='$user_id'");
                foreach ($test_list as $tid) {
                    $test_cart = array(
                        'user_id' => $user_id,
                        'test_id' => $tid
                    );
                    $this->db->insert('lab_test_cart', $test_cart);
                }
                return array(
                    'status' => 200,
                    'message' => 'success'
                );
            }
        }
    }
    
    public function showtestcart($user_id){
        $test_cart=array();
        $vendor_cart=array();
        $cart_array=array();
        $test_query = $this->db->query("SELECT lab_test_cart.test_id,lab_test_master.name from lab_test_cart INNER JOIN lab_test_master on lab_test_master.id=lab_test_cart.test_id where lab_test_cart.user_id='$user_id'");
        $num_count  = $test_query->num_rows();
        if ($num_count > 0) {
            $rows_list  = $test_query->result();
            foreach ($rows_list as $vrow) {
                $test_id  = $vrow->test_id;
                $test_name  = $vrow->name;
                $test_cart[] = array(
                    'test_id' => $test_id,
                    'test_name' => $test_name
                );
            }
        }
        
        $query = $this->db->query("SELECT lab_vendor_cart.test_id,lab_vendor_cart.vendor_id,users.name from lab_vendor_cart INNER JOIN users on users.id=lab_vendor_cart.vendor_id where lab_vendor_cart.user_id='$user_id'");
        $num_count  = $query->num_rows();
        if ($num_count > 0) {
            $row_list  = $query->result();
            foreach ($row_list as $row) {
                $test_id  = $row->test_id;
                $vendor_id = $row->vendor_id;
                $vendor_name = $row->name;
                $cart_query = $this->db->query("SELECT ld.code,ld.report_availability,ld.home_collection_charges,ld.price,ld.discounted_price,ld.discount,ld.medicalwale_discount,lab_test_master.name,lab_test_master.id from lab_test_master_details ld INNER JOIN lab_test_master on lab_test_master.id=ld.test_id where ld.test_id='$test_id' and ld.user_id='$vendor_id' group by ld.user_id");
                $cart_count  = $cart_query->num_rows();
                if ($cart_count > 0) {
                    $test_row = $cart_query->result();
                    foreach ($test_row as $test_list) {
                        $testid  = $test_list->id;
                        $test_name  = $test_list->name;
                        $code  = $test_list->code;
                        $report_availability  = $test_list->report_availability;
                        $home_collection_charges  = $test_list->home_collection_charges;
                        $price  = $test_list->price;
                        $discounted_price  = $test_list->discounted_price;
                        $discount  = $test_list->discount;
                        $medicalwale_discount  = $test_list->medicalwale_discount;
                        $cart_array[] = array(
                            'test_id' => $testid,
                            'test_name' => $test_name,
                            'code' => $code,
                            'report_availability' => $report_availability,
                            'home_collection_charges' => $home_collection_charges,
                            'price' => $price,
                            'discounted_price' => $discounted_price,
                            'discount' => $discount,
                            'medicalwale_discount' => $medicalwale_discount,
                            'home_delivery' => "0"
                        );
                    }
                }
            }
            $vendor_cart[] =array(
                'vendor_id' => $vendor_id,
                'vendor_name' => $vendor_name,
                'test_list' => $cart_array
            );
            $test_cart=array();
        }
        $cart_list= array(
            'test_cart' => $test_cart,
            'vendor_cart' => $vendor_cart
        );
        return array(
            'status' => 200,
            'message' => 'success',
            'data' => $cart_list
        );
    }
    
    public function all_lab_package($page,$category,$most_common_risk,$sort_type,$home_delivery,$vendor_id){
        $limit = 10;
        $start = 0;
        if ($page > 0) {
            if (!is_numeric($page)) {
                $page = 1;
            }
        }
        $start      = ($page - 1) * $limit;

        $filter_sort='';
        $test_list = array();
        $package_list = array();

        if(!empty($sort_type))
        {
            if ($sort_type == '1'){
                $filter_sort = " order by lab_package_master.name asc";
            }
            elseif ($sort_type == '2'){
                $filter_sort = " order by lab_package_master.name desc";
            }
            elseif ($sort_type == '3'){
                $filter_sort = " order by lab_package_master.price asc";
            }
            elseif ($sort_type == '4'){
                $filter_sort = " order by lab_package_master.price desc";
            }
            else{
                $filter_sort ='';
            }
        }
        
        $query      = $this->db->query("SELECT lab_package_master.*,users.name as vendor_name from lab_package_master INNER JOIN users on users.id=lab_package_master.user_id $filter_sort limit $start,$limit");
        $package_count = $query->num_rows();
        if ($package_count > 0) {
            $packagelist = $query->result();
            foreach ($packagelist as $package) {
                $package_id = $package->id;
                $code = $package->code;
                $vendor_id = $package->user_id;
                $feature = $this->db->query("SELECT GROUP_CONCAT(feature) as feature FROM `lab_features` INNER JOIN lab_center on FIND_IN_SET(lab_features.id, lab_center.features) where lab_center.user_id='$vendor_id'")->row_array();
                $certification = $feature['feature'];
                $vendor_name = $package->vendor_name;
                
                $rating = '4.5';
                $report_availability = '1';
                $home_collection_charges = $package->home_collection_charges;
                $price = $package->price;
                $discounted_price = $package->discounted_price;
                $discount = $package->discount;
                $medicalwale_discount = $package->medicalwale_discount;
                $home_delivery = '1';
                $package_name = $package->name;
                
                $test_query = $this->db->query("SELECT id as test_id,code,group_name,name as test_name,type FROM `lab_package_test_master` where package_id='$package_id'");
                $num_count  = $test_query->num_rows();
                if ($num_count > 0) {
                    $rows_list  = $test_query->result();
                    foreach ($rows_list as $row) {
                        $test_id    = $row->test_id;
                        $test_code  = $row->code;
                        $group_name = $row->group_name;
                        $test_name  = $row->test_name;
                        $type       = $row->type;
                        $test_list[] = array(
                            'test_id' => $test_id,
                            'code' => $test_code,
                            'name' => $test_name,
                            'group_name' => $group_name,
                            'aliasname' => '',
                            'description' => '',
                            'instructions' => '',
                            'components' => '',
                            'fasting' => '',
                            'type' => $type
                        );
                    }
                }
                $package_list[] = array(
                    'package_id' => $package_id,
                    'code' => $code,
                    'vendor_id' => $vendor_id,
                    'vendor_name' => $vendor_name,
                    'certification' => $certification,
                    'rating' => $rating,
                    'report_availability' => $report_availability,
                    'home_collection_charges' => $home_collection_charges,
                    'price' => $price,
                    'discounted_price' => $discounted_price,
                    'discount' => $discount,
                    'medicalwale_discount' => $medicalwale_discount,
                    'home_delivery' => $home_delivery,
                    'package_name' => $package_name,
                    'test' => $test_list
                );
            }
            return array(
                'status' => 200,
                'message' => 'success',
                'data_count' => $package_count,
                'data' => $package_list
            );
        } else {
            return array(
                'status' => 201,
                'message' => 'No data found!'
            );
        }
    }
    
    public function all_lab_test($page,$category,$most_common_risk,$sort_type,$home_delivery,$vendor_id){
        $limit = 10;
        $start = 0;
        if ($page > 0) {
            if (!is_numeric($page)) {
                $page = 1;
            }
        }
        $test_list = array();
        $start      = ($page - 1) * $limit;
        $category_filter='';
        $most_common_risk_filter='';
        $home_delivery_filter='';
        $vendor_id_filter='';
        $filter_sort='';
        
        if(!empty($category)){
            $category_filter = ' and FIND_IN_SET(lab_test_master.test_category, '.$category.')';
        }
        elseif(!empty($most_common_risk))
        {
            $most_common_risk_filter = ' and FIND_IN_SET(lab_test_master.most_common_factor, '.$most_common_risk.')';
        }
        elseif(!empty($home_delivery))
        {
            $home_delivery_filter = ' and lab_test_master_details.home_delivery='.$home_delivery;
        }
        elseif(!empty($vendor_id))
        {
            $vendor_id_filter = ' and lab_test_master_details.user_id='.$vendor_id;
        }

        if(!empty($sort_type))
        {
            if ($sort_type == '1'){
                $filter_sort = " order by lab_test_master.name asc";
            }
            elseif ($sort_type == '2'){
                $filter_sort = " order by lab_test_master.name desc";
            }
            elseif ($sort_type == '3'){
                $filter_sort = " order by lab_test_master_details.price asc";
            }
            elseif ($sort_type == '4'){
                $filter_sort = " order by lab_test_master_details.price desc";
            }
            else{
                $filter_sort ='';
            }
        }
        
        $query      = $this->db->query("SELECT lab_test_master.id as test_id,lab_test_master.name,lab_test_master.aliasname,lab_test_master.description,lab_test_master.instructions,lab_test_master.components,lab_test_master.fasting FROM `lab_test_master` INNER JOIN lab_test_master_details on lab_test_master_details.test_id=lab_test_master.id where lab_test_master.name<>'' $category_filter $most_common_risk_filter $home_delivery_filter $vendor_id_filter group by lab_test_master_details.test_id");
        $vendor_list='';
        $total_test = $query->num_rows();
        if ($total_test > 0) {
            $test_query = $this->db->query("SELECT lab_test_master.id as test_id,lab_test_master.name,lab_test_master.aliasname,lab_test_master.description,lab_test_master.instructions,lab_test_master.components,lab_test_master.fasting,lab_test_master_details.type FROM `lab_test_master` INNER JOIN lab_test_master_details on lab_test_master_details.test_id=lab_test_master.id where lab_test_master.name<>'' $category_filter $most_common_risk_filter $home_delivery_filter $vendor_id_filter group by lab_test_master_details.test_id $filter_sort limit $start,$limit");
            $num_count  = $test_query->num_rows();
            if ($num_count > 0) {
                $rows_list  = $test_query->result();
                foreach ($rows_list as $row) {
                    $test_id        = $row->test_id;
                    $name           = $row->name;
                    $aliasname          = $row->aliasname;
                    $description = $row->description;
                    $instructions  = $row->instructions;
                    $components  = $row->components;
                    $fasting  = $row->fasting;
                    $type  = $row->type;
                    $test_list[] = array(
                        'test_id' => $test_id,
                        'name' => $name,
                        'aliasname' => $aliasname,
                        'description' => $description,
                        'instructions' => $instructions,
                        'components' => $components,
                        'fasting' => $fasting,
                        'type' => $type
                   );
                }
            }
            return array(
                'status' => 200,
                'message' => 'success',
                'data_count' => $num_count,
                'data' => $test_list
            );
        } else {
            return array(
                'status' => 201,
                'message' => 'No data found!'
            );
        }
    }
    
    public function test_list_by_vendor($user_id)
    {
        $filter='';
        $pre='';
        $test_query = $this->db->query("SELECT test_id from lab_test_cart where user_id='$user_id'");
        $num_count  = $test_query->num_rows();
        if ($num_count > 0) {
            $rows_list  = $test_query->result();
            foreach ($rows_list as $vrow) {
                $test_id  = $vrow->test_id;
                $filter.=$pre." ld.test_id='$test_id'";
                $pre='or';
            }
        }

        $certification='';
        $test_query = $this->db->query("SELECT ld.code,ld.report_availability,ld.home_collection_charges,sum(ld.price) as price,sum(ld.discounted_price) as discounted_price,ld.discount,ld.medicalwale_discount,users.id as vendor_id,users.name as vendor_name from lab_test_master_details ld INNER JOIN users on users.id=ld.user_id where $filter group by ld.user_id");
        $num_count  = $test_query->num_rows();
            if ($num_count > 0) {
                $rows_list  = $test_query->result();
                foreach ($rows_list as $vrow) {
                        $code  = $vrow->code;
                        $report_availability  = $vrow->report_availability;
                        $home_collection_charges  = $vrow->home_collection_charges;
                        $price  = $vrow->price;
                        $discounted_price  = $vrow->discounted_price;
                        $discount  = $vrow->discount;
                        $medicalwale_discount  = $vrow->medicalwale_discount;
                        $vendor_name  = $vrow->vendor_name;
                        $vendor_id  = $vrow->vendor_id;
                        $testInfo = $this->db->query("SELECT GROUP_CONCAT(feature) as feature FROM `lab_features` INNER JOIN lab_center on FIND_IN_SET(lab_features.id, lab_center.features) where lab_center.user_id='$vendor_id'")->row_array();
                        $certification=$testInfo['feature'];
                        $vendor_list[] = array(
                            'vendor_id' => $vendor_id,
                            'vendor_name' => $vendor_name,
                            'certification' => $certification,
                            'rating' => '4.5',
                            'code' => $code,
                            'report_availability' => $report_availability,
                            'home_collection_charges' => $home_collection_charges,
                            'price' => $price,
                            'discounted_price' => $discounted_price,
                            'discount' => $discount,
                            'medicalwale_discount' => $medicalwale_discount,
                            'home_delivery' => "0"
                        );
                    }
            }
            return array(
                'status' => 200,
                'message' => 'success',
                'data' => $vendor_list
            );
    }
    
    public function vendor_cart_list($user_id)
    {
        $query = $this->db->query("SELECT lab_vendor_cart.test_id,lab_vendor_cart.vendor_id,users.name from lab_vendor_cart INNER JOIN users on users.id=lab_vendor_cart.vendor_id where lab_vendor_cart.user_id='$user_id'");
        $num_count  = $query->num_rows();
        if ($num_count > 0) {
            $row_list  = $query->result();
            foreach ($row_list as $row) {
                $test_id  = $row->test_id;
                $vendor_id = $row->vendor_id;
                $vendor_name = $row->name;
                
                $test_query = $this->db->query("SELECT ld.code,ld.report_availability,ld.home_collection_charges,ld.price,ld.discounted_price,ld.discount,ld.medicalwale_discount,lab_test_master.name,lab_test_master.id from lab_test_master_details ld INNER JOIN lab_test_master on lab_test_master.id=ld.test_id where ld.test_id='$test_id' and ld.user_id='$vendor_id'");
                $test_count  = $test_query->num_rows();
                if ($test_count > 0) {
                    $test_row = $test_query->result();
                    foreach ($test_row as $test_list) {
                        $testid  = $test_list->id;
                        $test_name  = $test_list->name;
                        $code  = $test_list->code;
                        $report_availability  = $test_list->report_availability;
                        $home_collection_charges  = $test_list->home_collection_charges;
                        $price  = $test_list->price;
                        $discounted_price  = $test_list->discounted_price;
                        $discount  = $test_list->discount;
                        $medicalwale_discount  = $test_list->medicalwale_discount;
                        $test_array[] = array(
                            'test_id' => $testid,
                            'test_name' => $test_name,
                            'code' => $code,
                            'report_availability' => $report_availability,
                            'home_collection_charges' => $home_collection_charges,
                            'price' => $price,
                            'discounted_price' => $discounted_price,
                            'discount' => $discount,
                            'medicalwale_discount' => $medicalwale_discount,
                            'home_delivery' => "0"
                        );
                    }
                }
            }
            $vendor_list[] =array(
                'vendor_id' => $vendor_id,
                'vendor_name' => $vendor_name,
                'test_list' => $test_array
            );
            return array(
                'status' => 200,
                'message' => 'success',
                'data' => $vendor_list
            );
        }
        else{
            $vendor_list=array();
            return array(
                'status' => 200,
                'message' => 'success',
                'data' => $vendor_list
            );
        }

    }
    
    public function lab_home(){
        $query        = $this->db->query("SELECT id,name FROM `lab_test_category` where is_active='1' order by sort asc");
                    $rows_list     = $query->result();
                    foreach ($rows_list as $row) {
                        $id  = $row->id;
                        $name  = $row->name;
                        
                        $category_list[] = array(
                            'id' => $id,
                            'name' => $name,
                            'image' => ''
                        );
                    }
                    
                    $query        = $this->db->query("SELECT id,name FROM `lab_test_most_common_factor` where is_active='1' order by sort asc");
                    $rows_list     = $query->result();
                    foreach ($rows_list as $row) {
                        $id  = $row->id;
                        $name  = $row->name;
                        
                        $common_factor[] = array(
                            'id' => $id,
                            'name' => $name,
                            'image' => ''
                        );
                    }
                    
                    $array_list[] = array(
                        'category_list' => $category_list,
                        'common_factor'=>$common_factor
                    );
                    return array(
                'status' => 200,
                'message' => 'success',
                'data' => $array_list
            );
    }
    
    public function labcenter_list($lat, $lng, $user_id, $category_id, $hospital_type)
    {
        if($hospital_type == ''){
            $radius = '5';
            $sql    = sprintf("SELECT `id`,`user_id`,`cat_id`,`profile_pic`, `lab_name`,`address1`,`address2`, `pincode`, `city`, `state`, `contact_no`,`whatsapp_no`, `email`, `opening_hours`, `latitude`, `longitude`, `reg_date`,`features`,`home_delivery`,`user_discount`, IFNULL(delivery_charges,'') AS delivery_charges, ( 6371 * acos( cos( radians('%s') ) * cos( radians( latitude) ) * cos( radians( longitude) - radians('%s') ) + sin( radians('%s') ) * sin( radians( latitude) ) ) ) AS distance FROM lab_center  WHERE `is_active` = 1 AND FIND_IN_SET($category_id, cat_id) HAVING distance < '%s' ORDER BY distance LIMIT 0 , 20", ($lat), ($lng), ($lat), ($radius));
            $query  = $this->db->query($sql);
            $count  = $query->num_rows();
        }else{
            $radius = '5000';
            $sql    = sprintf("SELECT `id`,`user_id`,`cat_id`,`profile_pic`, `lab_name`,`address1`,`address2`, `pincode`, `city`, `state`, `contact_no`,`whatsapp_no`, `email`, `opening_hours`, `latitude`, `longitude`, `reg_date`,`features`,`home_delivery`,`user_discount`, IFNULL(delivery_charges,'') AS delivery_charges, ( 6371 * acos( cos( radians('%s') ) * cos( radians( latitude) ) * cos( radians( longitude) - radians('%s') ) + sin( radians('%s') ) * sin( radians( latitude) ) ) ) AS distance FROM lab_center  WHERE `is_active` = 1 AND is_vendor = $hospital_type HAVING distance < '%s' ORDER BY distance LIMIT 0 , 20", ($lat), ($lng), ($lat), ($radius));
            $query  = $this->db->query($sql);
            $count  = $query->num_rows(); 
        }
       
        
        
        if ($count > 0) {
            foreach ($query->result_array() as $row) {
                $id                = $row['id'];
                $labcenter_user_id = $row['user_id'];
                $lab_name          = $row['lab_name'];
                $features          = $row['features'];
                $home_delivery     = $row['home_delivery'];
                $delivery_charges  = $row['delivery_charges'];
                $address1          = $row['address1'];
                $address2          = $row['address2'];
                $pincode           = $row['pincode'];
                $city              = $row['city'];
                $state             = $row['state'];
                $contact_no        = $row['contact_no'];
                $whatsapp_no       = $row['whatsapp_no'];
                $email             = $row['email'];
                $opening_hours     = $row['opening_hours'];
                $lat               = $row['latitude'];
                $lng               = $row['longitude'];
                $listing_type      = '10';
                //$rating            = '4.0';
                $profile_views     = '';
                $reviews           = '1000';
                $user_discount     = $row['user_discount'];
                $image             = $row['profile_pic'];
               // $image             = 'https://d2c8oti4is0ms3.cloudfront.net/images/labcenter_images/' . $image;
               $image1             = 'https://d2c8oti4is0ms3.cloudfront.net/images/healthwall_avatar/' . $image;
                $features_array    = array();
                $feature_query     = $this->db->query("SELECT feature FROM `lab_features` WHERE FIND_IN_SET(id,'" . $features . "')");
                foreach ($feature_query->result_array() as $get_list) {
                    $feature          = $get_list['feature'];
                    $features_array[] = array(
                        "name" => $feature
                    );
                }
                $final_Day      = array();
                $day_array_list = explode('|', $opening_hours);
                if (count($day_array_list) > 1) {
                    for ($i = 0; $i < count($day_array_list); $i++) {
                        $day_list = explode('>', $day_array_list[$i]);
                        for ($j = 0; $j < count($day_list); $j++) {
                            $day_time_list = explode('-', $day_list[$j]);
                            for ($k = 1; $k < count($day_time_list); $k++) {
                                $time_list1 = explode(',', $day_time_list[0]);
                                $time_list2 = explode(',', $day_time_list[1]);
                                $time       = array();
                                $open_close = array();
                                for ($l = 0; $l < count($time_list1); $l++) {
                                    $time_check        = $time_list1[$l] . '-' . $time_list2[$l];
                                    $time[]            = str_replace('close-close', 'close', $time_check);
                                    $system_start_time = date("H.i", strtotime($time_list1[$l]));
                                    $system_end_time   = date("H.i", strtotime($time_list2[$l]));
                                    $current_time      = date('H.i');
                                    if ($current_time > $system_start_time && $current_time < $system_end_time) {
                                        $open_close[] = 'open';
                                    } else {
                                        $open_close[] = 'close';
                                    }
                                }
                            }
                        }
                        $final_Day[] = array(
                            'day' => $day_list[0],
                            'time' => $time,
                            'status' => $open_close
                        );
                    }
                } else {
                    $final_Day[] = array(
                        'day' => 'close',
                        'time' => array(),
                        'status' => array()
                    );
                }
                $current_day = "";
                $followers   = $this->db->select('id')->from('follow_user')->where('parent_id', $labcenter_user_id)->get()->num_rows();
                $following   = $this->db->select('id')->from('follow_user')->where('user_id', $labcenter_user_id)->get()->num_rows();
                $is_follow   = $this->db->select('id')->from('follow_user')->where('user_id', $user_id)->where('parent_id', $labcenter_user_id)->get()->num_rows();
               
                if ($is_follow > 0) {
                    $is_follow = 'Yes';
                } else {
                    $is_follow = 'No';
                }
                $package_list  = array();
                $package_query = $this->db->query("SELECT * FROM `lab_packages` WHERE user_id='$labcenter_user_id' and branch_id ='' order by id asc");
                //echo "SELECT * FROM `lab_packages` WHERE user_id='$labcenter_user_id' order by id asc";
                $package_count = $package_query->num_rows();
                if ($package_count > 0) {
                    foreach ($package_query->result_array() as $package_row) {
                        $package_id      = $package_row['id'];
                        $package_name    = $package_row['lab_name'];
                        $package_details = $package_row['lab_details'];
                        $price           = $package_row['Price'];
                        $image           = $package_row['image'];
                        $home_delivery   = $package_row['home_delivery'];
                        //$image = 'https://d2c8oti4is0ms3.cloudfront.net/images/fitness_center/' . $image;
                        $package_list[]  = array(
                            'package_id' => $package_id,
                            'package_name' => $package_name,
                            'package_details' => $package_details,
                            'price' => $price,
                            'home_delivery' => $home_delivery
                        );
                    }
                } else {
                    $package_list = array();
                }
                $branch_list  = array();
                $branch_query = $this->db->query("SELECT * FROM `lab_center_branch` WHERE user_id='$labcenter_user_id' order by id asc");
                //echo "SELECT * FROM `lab_packages` WHERE user_id='$labcenter_user_id' order by id asc";
                $branch_count = $branch_query->num_rows();
                if ($branch_count > 0) {
                    foreach ($branch_query->result_array() as $branch_row) {
                        $branch_id                              = $branch_row['id'];
                        $branch_listing_id                      = $branch_row['user_id'];
                        $branch_path_pick_up                    = $branch_row['path_pick_up'];
                        $branch_path_sample_pickup_price_option = $branch_row['path_sample_pickup_price_option'];
                        $branch_path_sample_pickup_price        = $branch_row['path_sample_pickup_price'];
                        $branch_path_delivery_charge            = $branch_row['path_delivery_charge'];
                        $branch_path_delivery_price_options     = $branch_row['path_delivery_price_option'];
                        $branch_path_sample_delivery_price      = $branch_row['path_sample_delivery_price'];
                        $branch_diag_delivery_charge            = $branch_row['diag_delivery_charge'];
                        $branch_diag_delivery_price_option      = $branch_row['diag_delivery_price_option'];
                        $branch_diag_sample_delivery_price      = $branch_row['diag_sample_delivery_price'];
                        $branch_details                         = $branch_row['fnac_pick_up'];
                        /* $branch_details = $branch_row['fnac_sample_pickup_price_option '];
                        $branch_details = $branch_row['fnac_sample_pickup_price '];
                        $branch_details = $branch_row['fnac_delivery_charge'];
                        $branch_details = $branch_row['fnac_sample_delivery_price_option'];
                        $branch_details = $branch_row['fnac_sample_delivery_price '];*/
                        $branch_reg_date                        = $branch_row['reg_date'];
                        $branch_lab_branch_name                 = $branch_row['lab_branch_name'];
                        /*$branch_packages = $branch_row['packages'];*/
                        $branch_store_manager                   = $branch_row['store_manager'];
                        $branch_latitude                        = $branch_row['latitude'];
                        $branch_map_location                    = $branch_row['map_location'];
                        $branch_longitude                       = $branch_row['longitude'];
                        $branch_address1                        = $branch_row['address1'];
                        $branch_address2                        = $branch_row['address2'];
                        $branch_pincode                         = $branch_row['pincode'];
                        $branch_features                        = $branch_row['features'];
                        $branch_city                            = $branch_row['city'];
                        $branch_state                           = $branch_row['state'];
                        $branch_contact_no                      = $branch_row['contact_no'];
                        $branch_whatsapp_no                     = $branch_row['whatsapp_no'];
                        $branch_email                           = $branch_row['email'];
                        $branch_profile_pic                     = $branch_row['profile_pic'];
                        $branch_about_us                        = $branch_row['about_us'];
                        $branch_reach_area                      = $branch_row['reach_area'];
                        $branch_distance                        = $branch_row['distance'];
                        $branch_store_since                     = $branch_row['store_since'];
                        $branch_opening_hours                   = $branch_row['opening_hours'];
                        $branch_home_deliverys                  = $branch_row['home_delivery'];
                        $branch_branch_profile                  = $branch_row['branch_profile'];
                        $branch_delivery_charges                = $branch_row['delivery_charges'];
                        $branch_payment_type                    = $branch_row['payment_type'];
                        $branch_discount                        = $branch_row['discount'];
                        $branch_services                        = $branch_row['services'];
                        $branch_home_visit                      = $branch_row['home_visit'];
                        $branch_features_array                  = array();
                        $feature_query                          = $this->db->query("SELECT feature FROM `lab_features` WHERE FIND_IN_SET(id,'" . $branch_features . "')");
                        foreach ($feature_query->result_array() as $get_list) {
                            $feature                 = $get_list['feature'];
                            $branch_features_array[] = array(
                                "name" => $feature
                            );
                        }
                        $branch_final_Day      = array();
                        $day_array_list_branch = explode('|', $branch_opening_hours);
                        if (count($day_array_list_branch) > 1) {
                            for ($i = 0; $i < count($day_array_list_branch); $i++) {
                                $day_list = explode('>', $day_array_list_branch[$i]);
                                for ($j = 0; $j < count($day_list); $j++) {
                                    $day_time_list = explode('-', $day_list[$j]);
                                    for ($k = 1; $k < count($day_time_list); $k++) {
                                        $time_list1 = explode(',', $day_time_list[0]);
                                        $time_list2 = explode(',', $day_time_list[1]);
                                        $time       = array();
                                        $open_close = array();
                                        for ($l = 0; $l < count($time_list1); $l++) {
                                            $time_check        = $time_list1[$l] . '-' . $time_list2[$l];
                                            $time[]            = str_replace('close-close', 'close', $time_check);
                                            $system_start_time = date("H.i", strtotime($time_list1[$l]));
                                            $system_end_time   = date("H.i", strtotime($time_list2[$l]));
                                            $current_time      = date('H.i');
                                            if ($current_time > $system_start_time && $current_time < $system_end_time) {
                                                $open_close[] = 'open';
                                            } else {
                                                $open_close[] = 'close';
                                            }
                                        }
                                    }
                                }
                                $branch_final_Day[] = array(
                                    'day' => $day_list[0],
                                    'time' => $time,
                                    'status' => $open_close
                                );
                            }
                        } else {
                            $branch_final_Day[] = array(
                                'day' => 'close',
                                'time' => array(),
                                'status' => array()
                            );
                        }
                        $current_day         = "";
                        $package_branch_list = array();
                        $package_query       = $this->db->query("SELECT * FROM `lab_packages` WHERE user_id='$labcenter_user_id' and branch_id='$branch_id' order by id asc");
                        //echo "SELECT * FROM `lab_packages` WHERE user_id='$labcenter_user_id' order by id asc";
                        $package_count       = $package_query->num_rows();
                        if ($package_count > 0) {
                            foreach ($package_query->result_array() as $package_row) {
                                $package_id            = $package_row['id'];
                                $package_name          = $package_row['lab_name'];
                                $package_details       = $package_row['lab_details'];
                                $price                 = $package_row['Price'];
                                $image                 = $package_row['image'];
                                $home_delivery         = $package_row['home_delivery'];
                                //$image = 'https://d2c8oti4is0ms3.cloudfront.net/images/fitness_center/' . $image;
                                $package_branch_list[] = array(
                                    'package_id' => $package_id,
                                    'package_name' => $package_name,
                                    'package_details' => $package_details,
                                    'price' => $price,
                                    'home_delivery' => $home_delivery
                                );
                            }
                        } else {
                            $package_branch_list = array();
                        }
                        //$image = 'https://d2c8oti4is0ms3.cloudfront.net/images/fitness_center/' . $image;
                        $branch_list[] = array(
                            'branch_id' => $branch_id,
                            'branch_path_pick_up' => $branch_path_pick_up,
                            'branch_path_sample_pickup_price_option' => $branch_path_sample_pickup_price_option,
                            'branch_path_sample_pickup_price' => $branch_path_sample_pickup_price,
                            'branch_path_delivery_charge' => $branch_path_delivery_charge,
                            'branch_path_delivery_price_options' => $branch_path_delivery_price_options,
                            'branch_path_sample_delivery_price' => $branch_path_sample_delivery_price,
                            'branch_diag_delivery_charge' => $branch_diag_delivery_charge,
                            'branch_diag_delivery_price_option' => $branch_diag_delivery_price_option,
                            'branch_diag_sample_delivery_price' => $branch_diag_sample_delivery_price,
                            'branch_details' => $branch_details,
                            'branch_reg_date' => $branch_reg_date,
                            'branch_lab_branch_name' => $branch_lab_branch_name,
                            'branch_store_manager' => $branch_store_manager,
                            'branch_latitude' => $branch_latitude,
                            'branch_map_location' => $branch_map_location,
                            'branch_longitude' => $branch_longitude,
                            'branch_address1' => $branch_address1,
                            'branch_address2' => $branch_address2,
                            'branch_pincode' => $branch_pincode,
                            'branch_features' => $branch_features_array,
                            'branch_city' => $branch_city,
                            'branch_state' => $branch_state,
                            'branch_contact_no' => $branch_contact_no,
                            'branch_whatsapp_no' => $branch_whatsapp_no,
                            'branch_email' => $branch_email,
                            'branch_opening_day' => $branch_final_Day,
                            'branch_profile_pic' => $branch_profile_pic,
                            'branch_about_us' => $branch_about_us,
                            'branch_reach_area' => $branch_reach_area,
                            'branch_distance' => $branch_distance,
                            'branch_store_since' => $branch_store_since,
                            'branch_package' => $package_branch_list
                        );
                    }
                } else {
                    $branch_list = array();
                }
                $test_in_lab_list = array();
                $test_in_home_list = array();
                $test_query       = $this->db->query("SELECT * FROM `lab_test_details` WHERE user_id='$labcenter_user_id' order by id asc");
                $test_count       = $test_query->num_rows();
                if ($test_count > 0) {
                    foreach ($test_query->result_array() as $test_row) {
                        $user_id        = $test_row['user_id'];
                        $test           = $test_row['test'];
                        $test_id        = $test_row['test_id'];
                        $price          = $test_row['price'];
                        $offer          = $test_row['offer'];
                        $executive_rate = $test_row['executive_rate'];
                        $home_delivery  = $test_row['home_delivery'];
                        if ($home_delivery == "0") {
                            $test_in_lab_list[] = array(
                                'user_id' => $user_id,
                                'test_id' => $test,
                                'test' => $test_id,
                                'price' => $price,
                                'offer' => $offer,
                                'executive_rate' => $executive_rate,
                                'home_delivery' => "0"
                            );
                        } else {
                            $test_in_home_list[] = array(
                                'user_id' => $user_id,
                                'test_id' => $test_id,
                                'test' => $test,
                                'price' => $price,
                                'offer' => $offer,
                                'executive_rate' => $executive_rate,
                                'home_delivery' => "1"
                            );
                        }
                    }
                } else {
                    $test_in_lab_list  = array();
                    $test_in_home_list = array();
                }
                
                 $query_count = $this->db->query("SELECT count(user_id) as total_view FROM profile_views_master WHERE listing_id='$labcenter_user_id' ");
                    $TTL_View = $query_count->row()->total_view;
        
        
                //Review Count
                //echo "SELECT * FROM `labcenter_review` WHERE labcenter_id='$id'";
                //$Review_query = $this->db->query("SELECT * FROM `labcenter_review` WHERE labcenter_id='$id'");
                $Review_query = $this->db->query("SELECT labcenter_review.id FROM `labcenter_review` INNER JOIN `users` ON labcenter_review.user_id=users.id WHERE labcenter_review.labcenter_id='$id'");
                $Review_count = $Review_query->num_rows();
                
                $rating_query = $this->db->query("SELECT sum(labcenter_review.rating) as rating, count(labcenter_review.rating) as total_view FROM `labcenter_review` INNER JOIN `users` ON labcenter_review.user_id=users.id WHERE labcenter_review.labcenter_id='$id'");
                $rating_coun = $rating_query->num_rows();
                if($rating_coun > 0)
                {
                $rating_counting = $rating_query->row()->total_view;
                $rating_view = $rating_query->row()->rating;
                $rating_count=$rating_view/$rating_counting;
                }
                else
                {
                   $rating_count=0; 
                }
                $resultpost[] = array(
                    "id" => $id,
                    "lab_user_id" => $labcenter_user_id,
                    "name" => $lab_name,
                    "listing_type" => '10',
                    "features" => $features_array,
                    "home_delivery" => $home_delivery,
                    "delivery_charges" => $delivery_charges,
                    "address1" => $address1,
                    "address2" => $address2,
                    "pincode" => $pincode,
                    "city" => $city,
                    "exotel_no" => '02233721563',
                    "state" => $state,
                    "contact_no" => $contact_no,
                    "whatsapp_no" => $whatsapp_no,
                    "email" => $email,
                    "rating" => $rating_count,
                    "followers" => $followers,
                    "following" => $following,
                    "profile_views" => $TTL_View,
                    "reviews" => $Review_count,
                    "is_follow" => $is_follow,
                    "lat" => $lat,
                    "lng" => $lng,
                    'opening_day' => $final_Day,
                    "image" => $image1,
                    "user_discount" => $user_discount,
                    "package_list" => $package_list,
                    "branch_list" => $branch_list,
                    "home_test_done" => $test_in_home_list,
                    "lab_test_done" => $test_in_lab_list
                );
            }
        } else {
            $resultpost = array();
        }
        return $resultpost;
    }
    
    //added by zak for lab details 
    public function labcenter_details($user_id, $listing_id)
    {
        
                // Labs
               $sql = sprintf("SELECT `id`,`user_id`,`cat_id`,`profile_pic`, `discount`,`lab_name`,`address1`,`address2`, `pincode`, `city`, `user_discount`,`state`, `contact_no`,`whatsapp_no`, `email`, `opening_hours`, `latitude`, `longitude`, `reg_date`,`features`,`home_delivery`, IFNULL(delivery_charges,'') AS delivery_charges FROM lab_center where `is_active` = 1 AND user_id='$listing_id'");
               // $sql = sprintf("SELECT `id`,`user_id`,`cat_id`,`profile_pic`, `lab_branch_name`,`address1`,`address2`, `pincode`, `city`, `discount`,`state`, `contact_no`,`whatsapp_no`, `email`, `opening_hours`, `latitude`, `longitude`, `reg_date`,`features`,`home_delivery`, IFNULL(delivery_charges,'') AS delivery_charges FROM lab_center_branch where user_id='$listing_id'");
                //echo "SELECT `id`,`user_id`,`cat_id`,`profile_pic`, `lab_branch_name`,`address1`,`address2`, `pincode`, `city`, `discount`,`state`, `contact_no`,`whatsapp_no`, `email`, `opening_hours`, `latitude`, `longitude`, `reg_date`,`features`,`home_delivery`, IFNULL(delivery_charges,'') AS delivery_charges FROM lab_center_branch where user_id='$listing_id'";
                
                $query = $this->db->query($sql);
                $count = $query->num_rows();
          
                if ($count > 0) {
                    foreach ($query->result_array() as $row) {
                        $id = $row['id'];
                        $labcenter_user_id = $row['user_id'];
                        $lab_name = $row['lab_name'];
                        $features = $row['features'];
                        $home_delivery = $row['home_delivery'];
                        $delivery_charges = $row['delivery_charges'];
                        $address1 = $row['address1'];
                        $address2 = $row['address2'];
                        $pincode = $row['pincode'];
                        $city = $row['city'];
                        $state = $row['state'];
                        $contact_no = $row['contact_no'];
                        $whatsapp_no = $row['whatsapp_no'];
                        $email = $row['email'];
                        $opening_hours = $row['opening_hours'];
                        $lat = $row['latitude'];
                        $lng = $row['longitude'];
                        $rating = '4.0';
                        $profile_views = '1548';
                        $reviews = '1000';
                        $user_discount = $row['discount'];
                        $image = $row['profile_pic'];
                        $image = 'https://d2c8oti4is0ms3.cloudfront.net/images/labcenter_images/' . $image;

                        $features_array = array();
                        if($features != ''){
                            $feature_query = $this->db->query("SELECT feature FROM `lab_features` WHERE FIND_IN_SET(id,'" . $features . "')");
                            foreach ($feature_query->result_array() as $get_list) {
    
                                $feature = $get_list['feature'];
                                $features_array[] = array(
                                    "name" => $feature
                                );
                            }
                        }

                        $final_Day = array();
                        $day_array_list = explode('|', $opening_hours);
                        if (count($day_array_list) > 1) {
                            for ($i = 0; $i < count($day_array_list); $i++) {
                                $day_list = explode('>', $day_array_list[$i]);
                                for ($j = 0; $j < count($day_list); $j++) {
                                    $day_time_list = explode('-', $day_list[$j]);
                                    for ($k = 1; $k < count($day_time_list); $k++) {
                                        $time_list1 = explode(',', $day_time_list[0]);
                                        $time_list2 = explode(',', $day_time_list[1]);
                                        $time = array();
                                        $open_close = array();
                                        for ($l = 0; $l < count($time_list1); $l++) {
                                            $time_check = $time_list1[$l] . '-' . $time_list2[$l];
                                            $time[] = str_replace('close-close', 'close', $time_check);
                                            $system_start_time = date("H.i", strtotime($time_list1[$l]));
                                            $system_end_time = date("H.i", strtotime($time_list2[$l]));
                                            $current_time = date('H.i');
                                            if ($current_time > $system_start_time && $current_time < $system_end_time) {
                                                $open_close[] = 'open';
                                            } else {
                                                $open_close[] = 'close';
                                            }
                                        }
                                    }
                                }
                                $final_Day[] = array(
                                    'day' => $day_list[0],
                                    'time' => $time,
                                    'status' => $open_close
                                );
                            }
                        } else {
                            $final_Day[] = array(
                                'day' => 'close',
                                'time' => array(),
                                'status' => array()
                            );
                        }
                        $current_day = "";



                        $followers = $this->db->select('id')->from('follow_user')->where('parent_id', $labcenter_user_id)->get()->num_rows();
                        $following = $this->db->select('id')->from('follow_user')->where('user_id', $labcenter_user_id)->get()->num_rows();
                        $is_follow = $this->db->select('id')->from('follow_user')->where('user_id', $user_id)->where('parent_id', $labcenter_user_id)->get()->num_rows();
                       
                        if ($is_follow > 0) {
                            $is_follow = 'Yes';
                        } else {
                            $is_follow = 'No';
                        }

 //********************************************added by jakir on 3 aug 2018 for lab changes*************************************************** 
                  $package_list = array();
                $package_query = $this->db->query("SELECT * FROM `lab_packages` WHERE user_id='$labcenter_user_id' and branch_id ='' order by id asc");
                //echo "SELECT * FROM `lab_packages` WHERE user_id='$labcenter_user_id' order by id asc";
                $package_count = $package_query->num_rows();
                if ($package_count > 0) {
                    foreach ($package_query->result_array() as $package_row) {
                        $package_id = $package_row['id'];
                        $package_name = $package_row['lab_name'];
                        $package_details = $package_row['lab_details'];
                        $price = $package_row['Price'];
                        $image = $package_row['image'];
                        //$image = 'https://d2c8oti4is0ms3.cloudfront.net/images/fitness_center/' . $image;
                        $package_list[] = array(
                            'package_id' => $package_id,
                            'package_name' => $package_name,
                            'package_details' => $package_details,
                            'price' => $price
                        );
                    }
                } else {
                    $package_list = array();
                }
                
                $branch_list = array();
                $branch_id ="";
                $branch_query = $this->db->query("SELECT * FROM `lab_center_branch` WHERE user_id='$labcenter_user_id' order by id asc");
                //echo "SELECT * FROM `lab_packages` WHERE user_id='$labcenter_user_id' order by id asc";
                $branch_count = $branch_query->num_rows();
                if ($branch_count > 0) {
                    foreach ($branch_query->result_array() as $branch_row) {
                        $branch_id                              = $branch_row['id'];
                        $branch_listing_id                      = $branch_row['user_id'];
                        $branch_path_pick_up                    = $branch_row['path_pick_up'];
                        $branch_path_sample_pickup_price_option = $branch_row['path_sample_pickup_price_option'];
                        $branch_path_sample_pickup_price        = $branch_row['path_sample_pickup_price'];
                        $branch_path_delivery_charge            = $branch_row['path_delivery_charge'];
                        $branch_path_delivery_price_options     = $branch_row['path_delivery_price_option'];
                        $branch_path_sample_delivery_price      = $branch_row['path_sample_delivery_price'];
                        
                        $branch_diag_delivery_charge            = $branch_row['diag_delivery_charge'];
                        $branch_diag_delivery_price_option      = $branch_row['diag_delivery_price_option'];
                        $branch_diag_sample_delivery_price      = $branch_row['diag_sample_delivery_price'];
                        
                        $branch_details                         = $branch_row['fnac_pick_up'];
                       /* $branch_details = $branch_row['fnac_sample_pickup_price_option '];
                        $branch_details = $branch_row['fnac_sample_pickup_price '];
                        $branch_details = $branch_row['fnac_delivery_charge'];
                        $branch_details = $branch_row['fnac_sample_delivery_price_option'];
                        $branch_details = $branch_row['fnac_sample_delivery_price '];*/
                        
                        $branch_reg_date                = $branch_row['reg_date'];
                        $branch_lab_branch_name         = $branch_row['lab_branch_name'];
                        /*$branch_packages = $branch_row['packages'];*/
                        $branch_store_manager           = $branch_row['store_manager'];
                        $branch_latitude                = $branch_row['latitude'];
                        $branch_map_location            = $branch_row['map_location'];
                        $branch_longitude               = $branch_row['longitude'];
                        $branch_address1                = $branch_row['address1'];
                        $branch_address2                = $branch_row['address2'];
                        $branch_pincode                 = $branch_row['pincode'];
                        $branch_features                = $branch_row['features'];
                        $branch_city                    = $branch_row['city'];
                        $branch_state                   = $branch_row['state'];
                        $branch_contact_no              = $branch_row['contact_no'];
                        $branch_whatsapp_no             = $branch_row['whatsapp_no'];
                        $branch_email                   = $branch_row['email'];
                        $branch_profile_pic             = $branch_row['profile_pic'];
                        $branch_about_us                = $branch_row['about_us'];
                        $branch_reach_area              = $branch_row['reach_area'];
                        $branch_distance                = $branch_row['distance'];
                        $branch_store_since             = $branch_row['store_since'];
                        $branch_opening_hours           = $branch_row['opening_hours'];
                        $branch_home_deliverys          = $branch_row['home_delivery'];
                        $branch_branch_profile          = $branch_row['branch_profile'];
                        $branch_delivery_charges        = $branch_row['delivery_charges'];
                        $branch_payment_type            = $branch_row['payment_type'];
                        $branch_discount                = $branch_row['discount'];
                        $branch_services                = $branch_row['services'];
                        $branch_home_visit              = $branch_row['home_visit'];
                        
                        
                        $branch_features_array = array();

                        $feature_query = $this->db->query("SELECT feature FROM `lab_features` WHERE FIND_IN_SET(id,'" . $branch_features . "')");
                        foreach ($feature_query->result_array() as $get_list) {
        
                            $feature = $get_list['feature'];
                            $branch_features_array[] = array(
                                "name" => $feature
                            );
                        }
        
                        $branch_final_Day = array();
                        $day_array_list_branch = explode('|', $branch_opening_hours);
                        if (count($day_array_list_branch) > 1) {
                            for ($i = 0; $i < count($day_array_list_branch); $i++) {
                                $day_list = explode('>', $day_array_list_branch[$i]);
                                for ($j = 0; $j < count($day_list); $j++) {
                                    $day_time_list = explode('-', $day_list[$j]);
                                    for ($k = 1; $k < count($day_time_list); $k++) {
                                        $time_list1 = explode(',', $day_time_list[0]);
                                        $time_list2 = explode(',', $day_time_list[1]);
                                        $time = array();
                                        $open_close = array();
                                        for ($l = 0; $l < count($time_list1); $l++) {
                                            $time_check = $time_list1[$l] . '-' . $time_list2[$l];
                                            $time[] = str_replace('close-close', 'close', $time_check);
                                            $system_start_time = date("H.i", strtotime($time_list1[$l]));
                                            $system_end_time = date("H.i", strtotime($time_list2[$l]));
                                            $current_time = date('H.i');
                                            if ($current_time > $system_start_time && $current_time < $system_end_time) {
                                                $open_close[] = 'open';
                                            } else {
                                                $open_close[] = 'close';
                                            }
                                        }
                                    }
                                }
                                $branch_final_Day[] = array(
                                    'day' => $day_list[0],
                                    'time' => $time,
                                    'status' => $open_close
                                );
                            }
                        } else {
                            $branch_final_Day[] = array(
                                'day' => 'close',
                                'time' => array(),
                                'status' => array()
                            );
                        }
                        $current_day = "";
                        
                        
                        
                        $package_branch_list = array();
                        $package_query = $this->db->query("SELECT * FROM `lab_packages` WHERE user_id='$labcenter_user_id' and branch_id='$branch_id' order by id asc");
                        //echo "SELECT * FROM `lab_packages` WHERE user_id='$labcenter_user_id' order by id asc";
                        $package_count = $package_query->num_rows();
                        if ($package_count > 0) {
                            foreach ($package_query->result_array() as $package_row) {
                                $package_id = $package_row['id'];
                                $package_name = $package_row['lab_name'];
                                $package_details = $package_row['lab_details'];
                                $price = $package_row['Price'];
                                $image = $package_row['image'];
                                //$image = 'https://d2c8oti4is0ms3.cloudfront.net/images/fitness_center/' . $image;
                                $package_branch_list[] = array(
                                    'package_id' => $package_id,
                                    'package_name' => $package_name,
                                    'package_details' => $package_details,
                                    'price' => $price
                                );
                            }
                        } else {
                            $package_branch_list = array();
                        }
                        
                        
                        
                        //$image = 'https://d2c8oti4is0ms3.cloudfront.net/images/fitness_center/' . $image;
                        $branch_list[] = array(
                            'branch_id' => $branch_id,
                            'branch_path_pick_up' => $branch_path_pick_up,
                            'branch_path_sample_pickup_price_option' => $branch_path_sample_pickup_price_option,
                            'branch_path_sample_pickup_price' => $branch_path_sample_pickup_price,
                            'branch_path_delivery_charge' => $branch_path_delivery_charge,
                            'branch_path_delivery_price_options' => $branch_path_delivery_price_options,
                            'branch_path_sample_delivery_price' => $branch_path_sample_delivery_price,
                            'branch_diag_delivery_charge' => $branch_diag_delivery_charge,
                            'branch_diag_delivery_price_option' => $branch_diag_delivery_price_option,
                            'branch_diag_sample_delivery_price' => $branch_diag_sample_delivery_price,
                            'branch_details' => $branch_details,
                            'branch_reg_date' => $branch_reg_date,
                            'branch_lab_branch_name' => $branch_lab_branch_name,
                            'branch_store_manager' =>$branch_store_manager, 
                            'branch_latitude'=>$branch_latitude,
                            'branch_map_location'=>$branch_map_location,
                            'branch_longitude'=>$branch_longitude,
                            'branch_address1'=>$branch_address1,
                            'branch_address2'=>$branch_address2,
                            'branch_pincode'=>$branch_pincode,
                            'branch_features'=>$branch_features_array,
                            'branch_city'=>$branch_city,
                            'branch_state'=>$branch_state,
                            'branch_contact_no'=>$branch_contact_no,
                            'branch_whatsapp_no'=>$branch_whatsapp_no,
                            'branch_email'=>$branch_email,
                            'branch_opening_day' => $branch_final_Day,
                            'branch_profile_pic'=>$branch_profile_pic,
                            'branch_about_us'=>$branch_about_us,
                            'branch_reach_area'=>$branch_reach_area,
                            'branch_distance'=>$branch_distance,
                            'branch_store_since'=>$branch_store_since,
                            'branch_package'=>$package_branch_list
                        );
                    }
                } else {
                    $branch_list = array();
                }
                
                
                ///Lab test added by ghanshyam parihar starts
                
                // $test_branch_list = array();
                // $test_query = $this->db->query("SELECT * FROM `lab_test_details` WHERE user_id='$labcenter_user_id' or branch_id='$branch_id' order by id asc");
                // //echo "SELECT * FROM `lab_packages` WHERE user_id='$labcenter_user_id' order by id asc";
                // $test_count = $test_query->num_rows();
                // if ($test_count > 0) {
                //     foreach ($test_query->result_array() as $test_row) {
                //         $test_id = $test_row['id'];
                //         $test_name = $test_row['test'];
                //         $price = $test_row['price'];
                //         $discount = $test_row['discount'];
                //         $offer = $test_row['offer'];
                //         $executive_rate = $test_row['executive_rate'];
                //         //$image = 'https://d2c8oti4is0ms3.cloudfront.net/images/fitness_center/' . $image;
                //         $test_branch_list[] = array(
                //             'test_id' => $test_id,
                //             'test_name' => $test_name,
                //             'price' => $price,
                //             'offer' => $offer,
                //             'executive_rate' => $executive_rate,
                //             'discount' => $discount
                //         );
                //     }
                // } else {
                //     $test_branch_list = array();
                // }
                
                $test_in_lab_list = array();
                 $test_in_home_list = array();
                $test_query       = $this->db->query("SELECT * FROM `lab_test_details` WHERE user_id='$labcenter_user_id' order by id asc");
                $test_count       = $test_query->num_rows();
                if ($test_count > 0) {
                    foreach ($test_query->result_array() as $test_row) {
                        $user_id        = $test_row['user_id'];
                        $test           = $test_row['test'];
                        $test_id        = $test_row['test_id'];
                        $price          = $test_row['price'];
                        $offer          = $test_row['offer'];
                        $executive_rate = $test_row['executive_rate'];
                        $home_delivery  = $test_row['home_delivery'];
                        if ($home_delivery == "0") {
                            $test_in_lab_list[] = array(
                                'user_id' => $user_id,
                                'test_id' => $test,
                                'test' => $test_id,
                                'price' => $price,
                                'offer' => $offer,
                                'executive_rate' => $executive_rate,
                                'home_delivery' => "0"
                            );
                        } else {
                            $test_in_home_list[] = array(
                                'user_id' => $user_id,
                                'test_id' => $test_id,
                                'test' => $test,
                                'price' => $price,
                                'offer' => $offer,
                                'executive_rate' => $executive_rate,
                                'home_delivery' => "1"
                            );
                        }
                    }
                } else {
                    $test_in_lab_list  = array();
                    $test_in_home_list = array();
                }
                
                ///Lab test added by ghanshyam parihar ends

//********************************************************************************End by Jakir *******************************************
                        $resultpost[] = array(
                            "id" => $id,
                            "lab_user_id" => $labcenter_user_id,
                            "name" => $lab_name,
                            "features" => $features_array,
                            "home_delivery" => $home_delivery,
                            "delivery_charges" => $delivery_charges,
                            "address1" => $address1,
                            "address2" => $address2,
                            "pincode" => $pincode,
                            "city" => $city,
                            "state" => $state,
                            "contact_no" => $contact_no,
                            "whatsapp_no" => $whatsapp_no,
                            "exotel_no" => '02233721563',
                            "email" => $email,
                            "rating" => $rating,
                            "followers" => $followers,
                            "following" => $following,
                            "profile_views" => $profile_views,
                            "reviews" => $reviews,
                            "is_follow" => $is_follow,
                            "lat" => $lat,
                            "lng" => $lng,
                            'opening_day' => $final_Day,
                            "image" => $image,
                     "user_discount" => $user_discount,
                    "package_list"=> $package_list,
                    "branch_list"=>$branch_list,
                   // "test_list"=>$test_branch_list
                    "home_test_done" => $test_in_home_list,
                    "lab_test_done" => $test_in_lab_list
                        );
                    }
                } else {
                    $resultpost = array();
                }
            return $resultpost;
    }
    
    
    //added by zak for lab branch center 
    public function labcenter_branches_details($user_id, $listing_id,$branch_id)
    {
           $branch_list = array();
                $branch_query = $this->db->query("SELECT * FROM `lab_center_branch` WHERE user_id='$listing_id' AND id='$branch_id' order by id asc");
             //   echo "SELECT * FROM `lab_center_branch` WHERE user_id='$listing_id' AND id='$branch_id' order by id asc";
                $branch_count = $branch_query->num_rows();
            //    echo $branch_count;
                if ($branch_count > 0) {
                    foreach ($branch_query->result_array() as $branch_row) {
                        $branch_id                              = $branch_row['id'];
                        $branch_listing_id                      = $branch_row['user_id'];
                        $branch_path_pick_up                    = $branch_row['path_pick_up'];
                        $branch_path_sample_pickup_price_option = $branch_row['path_sample_pickup_price_option'];
                        $branch_path_sample_pickup_price        = $branch_row['path_sample_pickup_price'];
                        $branch_path_delivery_charge            = $branch_row['path_delivery_charge'];
                        $branch_path_delivery_price_options     = $branch_row['path_delivery_price_option'];
                        $branch_path_sample_delivery_price      = $branch_row['path_sample_delivery_price'];
                        
                        $branch_diag_delivery_charge            = $branch_row['diag_delivery_charge'];
                        $branch_diag_delivery_price_option      = $branch_row['diag_delivery_price_option'];
                        $branch_diag_sample_delivery_price      = $branch_row['diag_sample_delivery_price'];
                        
                        $branch_details                         = $branch_row['fnac_pick_up'];
                       /* $branch_details = $branch_row['fnac_sample_pickup_price_option '];
                        $branch_details = $branch_row['fnac_sample_pickup_price '];
                        $branch_details = $branch_row['fnac_delivery_charge'];
                        $branch_details = $branch_row['fnac_sample_delivery_price_option'];
                        $branch_details = $branch_row['fnac_sample_delivery_price '];*/
                        
                        $branch_reg_date                = $branch_row['reg_date'];
                        $branch_lab_branch_name         = $branch_row['lab_branch_name'];
                        /*$branch_packages = $branch_row['packages'];*/
                        $branch_store_manager           = $branch_row['store_manager'];
                        $branch_latitude                = $branch_row['latitude'];
                        $branch_map_location            = $branch_row['map_location'];
                        $branch_longitude               = $branch_row['longitude'];
                        $branch_address1                = $branch_row['address1'];
                        $branch_address2                = $branch_row['address2'];
                        $branch_pincode                 = $branch_row['pincode'];
                        $branch_features                = $branch_row['features'];
                        $branch_city                    = $branch_row['city'];
                        $branch_state                   = $branch_row['state'];
                        $branch_contact_no              = $branch_row['contact_no'];
                        $branch_whatsapp_no             = $branch_row['whatsapp_no'];
                        $branch_email                   = $branch_row['email'];
                        $branch_profile_pic             = $branch_row['profile_pic'];
                        $branch_about_us                = $branch_row['about_us'];
                        $branch_reach_area              = $branch_row['reach_area'];
                        $branch_distance                = $branch_row['distance'];
                        $branch_store_since             = $branch_row['store_since'];
                        $branch_opening_hours           = $branch_row['opening_hours'];
                        $branch_home_deliverys          = $branch_row['home_delivery'];
                        $branch_branch_profile          = $branch_row['branch_profile'];
                        $branch_delivery_charges        = $branch_row['delivery_charges'];
                        $branch_payment_type            = $branch_row['payment_type'];
                        $branch_discount                = $branch_row['discount'];
                        $branch_services                = $branch_row['services'];
                        $branch_home_visit              = $branch_row['home_visit'];
                        
                        
                        $branch_features_array = array();

                        $feature_query = $this->db->query("SELECT feature FROM `lab_features` WHERE FIND_IN_SET(id,'" . $branch_features . "')");
                        foreach ($feature_query->result_array() as $get_list) {
        
                            $feature = $get_list['feature'];
                            $branch_features_array[] = array(
                                "name" => $feature
                            );
                        }
        
                        $branch_final_Day = array();
                        $day_array_list_branch = explode('|', $branch_opening_hours);
                        if (count($day_array_list_branch) > 1) {
                            for ($i = 0; $i < count($day_array_list_branch); $i++) {
                                $day_list = explode('>', $day_array_list_branch[$i]);
                                for ($j = 0; $j < count($day_list); $j++) {
                                    $day_time_list = explode('-', $day_list[$j]);
                                    for ($k = 1; $k < count($day_time_list); $k++) {
                                        $time_list1 = explode(',', $day_time_list[0]);
                                        $time_list2 = explode(',', $day_time_list[1]);
                                        $time = array();
                                        $open_close = array();
                                        for ($l = 0; $l < count($time_list1); $l++) {
                                            $time_check = $time_list1[$l] . '-' . $time_list2[$l];
                                            $time[] = str_replace('close-close', 'close', $time_check);
                                            $system_start_time = date("H.i", strtotime($time_list1[$l]));
                                            $system_end_time = date("H.i", strtotime($time_list2[$l]));
                                            $current_time = date('H.i');
                                            if ($current_time > $system_start_time && $current_time < $system_end_time) {
                                                $open_close[] = 'open';
                                            } else {
                                                $open_close[] = 'close';
                                            }
                                        }
                                    }
                                }
                                $branch_final_Day[] = array(
                                    'day' => $day_list[0],
                                    'time' => $time,
                                    'status' => $open_close
                                );
                            }
                        } else {
                            $branch_final_Day[] = array(
                                'day' => 'close',
                                'time' => array(),
                                'status' => array()
                            );
                        }
                        $current_day = "";
                        
                        
                        
                        $package_branch_list = array();
                        $package_query = $this->db->query("SELECT * FROM `lab_packages` WHERE user_id='$listing_id' and branch_id='$branch_id' order by id asc");
                        //echo "SELECT * FROM `lab_packages` WHERE user_id='$labcenter_user_id' order by id asc";
                        $package_count = $package_query->num_rows();
                        if ($package_count > 0) {
                            foreach ($package_query->result_array() as $package_row) {
                                $package_id = $package_row['id'];
                                $package_name = $package_row['lab_name'];
                                $package_details = $package_row['lab_details'];
                                $price = $package_row['Price'];
                                $image = $package_row['image'];
                                //$image = 'https://d2c8oti4is0ms3.cloudfront.net/images/fitness_center/' . $image;
                                $package_branch_list[] = array(
                                    'package_id' => $package_id,
                                    'package_name' => $package_name,
                                    'package_details' => $package_details,
                                    'price' => $price
                                );
                            }
                        } else {
                            $package_branch_list = array();
                        }
                        
                        
                        
                        //$image = 'https://d2c8oti4is0ms3.cloudfront.net/images/fitness_center/' . $image;
                        $branch_list[] = array(
                            'branch_id' => $branch_id,
                            'branch_path_pick_up' => $branch_path_pick_up,
                            'branch_path_sample_pickup_price_option' => $branch_path_sample_pickup_price_option,
                            'branch_path_sample_pickup_price' => $branch_path_sample_pickup_price,
                            'branch_path_delivery_charge' => $branch_path_delivery_charge,
                            'branch_path_delivery_price_options' => $branch_path_delivery_price_options,
                            'branch_path_sample_delivery_price' => $branch_path_sample_delivery_price,
                            'branch_diag_delivery_charge' => $branch_diag_delivery_charge,
                            'branch_diag_delivery_price_option' => $branch_diag_delivery_price_option,
                            'branch_diag_sample_delivery_price' => $branch_diag_sample_delivery_price,
                            'branch_details' => $branch_details,
                            'branch_reg_date' => $branch_reg_date,
                            'branch_lab_branch_name' => $branch_lab_branch_name,
                            'branch_store_manager' =>$branch_store_manager, 
                            'branch_latitude'=>$branch_latitude,
                            'branch_map_location'=>$branch_map_location,
                            'branch_longitude'=>$branch_longitude,
                            'branch_address1'=>$branch_address1,
                            'branch_address2'=>$branch_address2,
                            'branch_pincode'=>$branch_pincode,
                            'branch_features'=>$branch_features_array,
                            'branch_city'=>$branch_city,
                            'branch_state'=>$branch_state,
                            'branch_contact_no'=>$branch_contact_no,
                            'branch_whatsapp_no'=>$branch_whatsapp_no,
                            'branch_email'=>$branch_email,
                            'branch_opening_day' => $branch_final_Day,
                            'branch_profile_pic'=>$branch_profile_pic,
                            'branch_about_us'=>$branch_about_us,
                            'branch_reach_area'=>$branch_reach_area,
                            'branch_distance'=>$branch_distance,
                            'branch_store_since'=>$branch_store_since,
                            'branch_package'=>$package_branch_list
                        );
                    }
                } else {
                    $branch_list = array();
                }
                return $branch_list;
    }
    //end 
    
    public function labcenter_packages($labcenter_id)
    {
        $query = $this->db->query("SELECT id,packages,user_id FROM `lab_center` WHERE `is_active` = 1 AND id='$labcenter_id'");
        $count = $query->num_rows();
        //print_r($query->result_array());
        if ($count > 0) {
            foreach ($query->result_array() as $row) {
                $packages           = $row['user_id'];
                //$labcenter_packages = $this->db->query("SELECT * FROM `lab_packages` WHERE FIND_IN_SET(lab_pack_name,'" . $packages . "')");
                $labcenter_packages = $this->db->query("SELECT * FROM `lab_packages` WHERE user_id='" . $packages . "'");
                foreach ($labcenter_packages->result_array() as $get_list) {
                    $package_id      = $get_list['id'];
                    $package_name    = $get_list['lab_pack_name'];
                    $package_details = $get_list['lab_pack_details'];
                    $price           = $get_list['price'];
                    $image           = $get_list['image'];
                    $image           = 'https://d2c8oti4is0ms3.cloudfront.net/images/labcenter_images/' . $image;
                    $resultpost[]    = array(
                        "package_id" => $package_id,
                        "package_name" => $package_name,
                        "package_details" => $package_details,
                        'price' => $price,
                        'image' => $image
                    );
                }
            }
        } else {
            $resultpost = array();
        }
        return $resultpost;
    }
    public function lab_test_search($keyword, $category_id, $lab_user_id)
    {
        $resultpost = array();
        $query      = $this->db->query("SELECT id,user_id,cat_id,test,price FROM lab_test_details WHERE test LIKE '%$keyword%' AND cat_id='$category_id' AND user_id='$lab_user_id' limit 15");
        $count      = $query->num_rows();
        if ($count > 0) {
            foreach ($query->result_array() as $row) {
                $test_id       = $row['id'];
                $lab_id        = $row['user_id'];
                $test_name     = $row['test'];
                $product_price = $row['price'];
                $resultpost[]  = array(
                    "lab_test_id" => $test_id,
                    "test_name" => $test_name,
                    "test_price" => $product_price
                );
            }
        } else {
            $resultpost = array();
        }
        return $resultpost;
    }
    public function add_review($user_id, $listing_id, $rating, $review, $service)
    {
        date_default_timezone_set('Asia/Kolkata');
        $date         = date('Y-m-d H:i:s');
        $review_array = array(
            'user_id' => $user_id,
            'labcenter_id' => $listing_id,
            'rating' => $rating,
            'review' => $review,
            'service' => $service,
            'date' => $date
        );
        $this->db->insert('labcenter_review', $review_array);
        return array(
            'status' => 201,
            'message' => 'success'
        );
    }
    
      public function edit_review($review_id,$user_id, $listing_id, $rating, $review, $service) {
        date_default_timezone_set('Asia/Kolkata');
        $date = date('Y-m-d H:i:s');
        $review_array = array(
            'rating' => $rating,
            'review' => $review,
            'service' => $service,
        );
           $this->db->where('id',$review_id);
           $this->db->where('user_id',$user_id);
           $this->db->update('labcenter_review',$review_array);
        //$this->db->insert('fitness_center_review', $review_array);
        return array(
            'status' => 201,
            'message' => 'success'
        );
    }
    public function review_list($user_id, $listing_id)
    {
        function get_time_difference_php($created_time)
        {
            date_default_timezone_set('Asia/Calcutta');
            $str            = strtotime($created_time);
            $today          = strtotime(date('Y-m-d H:i:s'));
            $time_differnce = $today - $str;
            $years          = 60 * 60 * 24 * 365;
            $months         = 60 * 60 * 24 * 30;
            $days           = 60 * 60 * 24;
            $hours          = 60 * 60;
            $minutes        = 60;
            if (intval($time_differnce / $years) > 1) {
                return intval($time_differnce / $years) . " yrs ago";
            } else if (intval($time_differnce / $years) > 0) {
                return intval($time_differnce / $years) . " yr ago";
            } else if (intval($time_differnce / $months) > 1) {
                return intval($time_differnce / $months) . " months ago";
            } else if (intval(($time_differnce / $months)) > 0) {
                return intval(($time_differnce / $months)) . " month ago";
            } else if (intval(($time_differnce / $days)) > 1) {
                return intval(($time_differnce / $days)) . " days ago";
            } else if (intval(($time_differnce / $days)) > 0) {
                return intval(($time_differnce / $days)) . " day ago";
            } else if (intval(($time_differnce / $hours)) > 1) {
                return intval(($time_differnce / $hours)) . " hrs ago";
            } else if (intval(($time_differnce / $hours)) > 0) {
                return intval(($time_differnce / $hours)) . " hr ago";
            } else if (intval(($time_differnce / $minutes)) > 1) {
                return intval(($time_differnce / $minutes)) . " min ago";
            } else if (intval(($time_differnce / $minutes)) > 0) {
                return intval(($time_differnce / $minutes)) . " min ago";
            } else if (intval(($time_differnce)) > 1) {
                return intval(($time_differnce)) . " sec ago";
            } else {
                return "few seconds ago";
            }
        }
        $review_count = $this->db->select('id')->from('labcenter_review')->where('labcenter_id', $listing_id)->get()->num_rows();
        if ($review_count > 0) {
            $query = $this->db->query("SELECT labcenter_review.id,labcenter_review.user_id,labcenter_review.labcenter_id,labcenter_review.rating,labcenter_review.review, labcenter_review.service,labcenter_review.date as review_date,users.id as user_id,users.name as firstname FROM `labcenter_review` INNER JOIN `users` ON labcenter_review.user_id=users.id WHERE labcenter_review.labcenter_id='$listing_id' order by labcenter_review.id desc");
            foreach ($query->result_array() as $row) {
                $id       = $row['id'];
                $user_id       = $row['user_id'];
                $username = $row['firstname'];
                $rating   = $row['rating'];
                $review   = $row['review'];
                $review   = preg_replace('~[\r\n]+~', '', $review);
                if ($id > '9') {
                    $decrypt = $this->decrypt($review);
                    $encrypt = $this->encrypt($decrypt);
                    if ($encrypt == $review) {
                        $review = $decrypt;
                    }
                } else {
                    if (base64_encode(base64_decode($review)) === $review) {
                        $review = base64_decode($review);
                    }
                }
                $service      = $row['service'];
                $review_date  = $row['review_date'];
                $review_date  = get_time_difference_php($review_date);
                $like_count   = $this->db->select('id')->from('labcenter_review_likes')->where('post_id', $id)->get()->num_rows();
                $post_count   = $this->db->select('id')->from('labcenter_review_comment')->where('post_id', $id)->get()->num_rows();
                $like_yes_no  = $this->db->select('id')->from('labcenter_review_likes')->where('user_id', $user_id)->where('post_id', $id)->get()->num_rows();
                $resultpost[] = array(
                    'id' => $id,
                    'user_id'=>$user_id,
                    'username' => $username,
                    'rating' => $rating,
                    'review' => $review,
                    'service' => $service,
                    'review_date' => $review_date,
                    'like_count' => $like_count,
                    'like_yes_no' => $like_yes_no,
                    'comment_count' => $post_count
                );
            }
        } else {
            $resultpost = array();
        }
        return $resultpost;
    }
    
     public function review_with_comment($user_id, $listing_id)
    {
        function get_time_difference_php($created_time)
        {
            date_default_timezone_set('Asia/Calcutta');
            $str            = strtotime($created_time);
            $today          = strtotime(date('Y-m-d H:i:s'));
            $time_differnce = $today - $str;
            $years          = 60 * 60 * 24 * 365;
            $months         = 60 * 60 * 24 * 30;
            $days           = 60 * 60 * 24;
            $hours          = 60 * 60;
            $minutes        = 60;
            if (intval($time_differnce / $years) > 1) {
                return intval($time_differnce / $years) . " yrs ago";
            } else if (intval($time_differnce / $years) > 0) {
                return intval($time_differnce / $years) . " yr ago";
            } else if (intval($time_differnce / $months) > 1) {
                return intval($time_differnce / $months) . " months ago";
            } else if (intval(($time_differnce / $months)) > 0) {
                return intval(($time_differnce / $months)) . " month ago";
            } else if (intval(($time_differnce / $days)) > 1) {
                return intval(($time_differnce / $days)) . " days ago";
            } else if (intval(($time_differnce / $days)) > 0) {
                return intval(($time_differnce / $days)) . " day ago";
            } else if (intval(($time_differnce / $hours)) > 1) {
                return intval(($time_differnce / $hours)) . " hrs ago";
            } else if (intval(($time_differnce / $hours)) > 0) {
                return intval(($time_differnce / $hours)) . " hr ago";
            } else if (intval(($time_differnce / $minutes)) > 1) {
                return intval(($time_differnce / $minutes)) . " min ago";
            } else if (intval(($time_differnce / $minutes)) > 0) {
                return intval(($time_differnce / $minutes)) . " min ago";
            } else if (intval(($time_differnce)) > 1) {
                return intval(($time_differnce)) . " sec ago";
            } else {
                return "few seconds ago";
            }
        }
        $review_count = $this->db->select('id')->from('labcenter_review')->where('labcenter_id', $listing_id)->get()->num_rows();
        if ($review_count > 0) {
            $query = $this->db->query("SELECT labcenter_review.id,labcenter_review.user_id,labcenter_review.labcenter_id,labcenter_review.rating,labcenter_review.review, labcenter_review.service,labcenter_review.date as review_date,users.id as user_id,users.name as firstname FROM `labcenter_review` INNER JOIN `users` ON labcenter_review.user_id=users.id WHERE labcenter_review.labcenter_id='$listing_id' order by labcenter_review.id desc");
            foreach ($query->result_array() as $row) {
                $id       = $row['id'];
                $username = $row['firstname'];
                $rating   = $row['rating'];
                $review   = $row['review'];
                $review   = preg_replace('~[\r\n]+~', '', $review);
                if ($id > '9') {
                    $decrypt = $this->decrypt($review);
                    $encrypt = $this->encrypt($decrypt);
                    if ($encrypt == $review) {
                        $review = $decrypt;
                    }
                } else {
                    if (base64_encode(base64_decode($review)) === $review) {
                        $review = base64_decode($review);
                    }
                }
                $service      = $row['service'];
                $review_date  = $row['review_date'];
                $review_date  = get_time_difference_php($review_date);
                $like_count   = $this->db->select('id')->from('labcenter_review_likes')->where('post_id', $id)->get()->num_rows();
                $post_count   = $this->db->select('id')->from('labcenter_review_comment')->where('post_id', $id)->get()->num_rows();
                $like_yes_no  = $this->db->select('id')->from('labcenter_review_likes')->where('user_id', $user_id)->where('post_id', $id)->get()->num_rows();
                        $review_list_count = $this->db->select('id')->from('labcenter_review_comment')->where('post_id', $id)->get()->num_rows();
                         if ($review_list_count) {
                              $resultcomment = array();
                        $querycomment = $this->db->query("SELECT labcenter_review_comment.id,labcenter_review_comment.post_id,labcenter_review_comment.comment as comment,labcenter_review_comment.date,users.name,labcenter_review_comment.user_id as post_user_id FROM labcenter_review_comment INNER JOIN users on users.id=labcenter_review_comment.user_id WHERE labcenter_review_comment.post_id='$id' order by labcenter_review_comment.id asc");
                        
                        foreach ($querycomment->result_array() as $rowc) {
                            $comment_id      = $rowc['id'];
                            $post_id = $rowc['post_id'];
                            $comment = $rowc['comment'];
                            $comment = preg_replace('~[\r\n]+~', '', $comment);
                           
                                $usernamec     = $rowc['name'];
                                $date         = $rowc['date'];
                                $post_user_id = $rowc['post_user_id'];
                                $like_countc   = $this->db->select('id')->from('labcenter_review_comment_like')->where('comment_id', $comment_id)->get()->num_rows();
                                $like_yes_noc  = $this->db->select('id')->from('labcenter_review_comment_like')->where('comment_id', $comment_id)->where('user_id', $user_id)->get()->num_rows();
                                $comment_date = get_time_difference_php($date);
                                $img_count    = $this->db->select('media.source')->from('media')->join('users', 'users.avatar_id=media.id')->where('users.id', $post_user_id)->get()->num_rows();
                                if ($img_count > 0) {
                                    $profile_query = $this->db->select('media.source')->from('media')->join('users', 'users.avatar_id=media.id')->where('users.id', $post_user_id)->get()->row();
                                    $img_file      = $profile_query->source;
                                    $userimagec     = 'https://d2c8oti4is0ms3.cloudfront.net/images/healthwall_avatar/' . $img_file;
                                } else {
                                    $userimagec = 'https://d2c8oti4is0ms3.cloudfront.net/images/img/default_user.jpg';
                                }
                                $date         = get_time_difference_php($date);
                                $resultcomment[] = array(
                                    'id' => $comment_id,
                                    'username' => $usernamec,
                                    'userimage' => $userimagec,
                                    'like_count' => $like_countc,
                                    'like_yes_no' => $like_yes_noc,
                                    'post_id' => $post_id,
                                    'comment' => $comment,
                                    'comment_date' => $comment_date
                                );
                            }
                        } else {
                            $resultcomment = array();
                        }
                
                $resultpost[] = array(
                    'id' => $id,
                    'username' => $username,
                    'rating' => $rating,
                    'review' => $review,
                    'service' => $service,
                    'review_date' => $review_date,
                    'like_count' => $like_count,
                    'like_yes_no' => $like_yes_no,
                    'comment_count' => $post_count,
                       'comments'=>$resultcomment
                );
            }
        } else {
            $resultpost = array();
        }
        return $resultpost;
    }
    
    
    public function review_like($user_id, $post_id)
    {
        date_default_timezone_set('Asia/Kolkata');
        $created_at  = date('Y-m-d H:i:s');
        $count_query = $this->db->query("SELECT id from labcenter_review_likes where post_id='$post_id' and user_id='$user_id'");
        $count       = $count_query->num_rows();
        if ($count > 0) {
            $this->db->query("DELETE FROM `labcenter_review_likes` WHERE user_id='$user_id' and post_id='$post_id'");
            $like_query = $this->db->query("SELECT id from labcenter_review_likes WHERE post_id='$post_id'");
            $total_like = $like_query->num_rows();
            return array(
                'status' => 201,
                'message' => 'deleted',
                'like' => '0',
                'total_like' => $total_like
            );
        } else {
            $labcenter_review_likes = array(
                'user_id' => $user_id,
                'post_id' => $post_id
            );
            $this->db->insert('labcenter_review_likes', $labcenter_review_likes);
            $like_query = $this->db->query("SELECT id from labcenter_review_likes WHERE post_id='$post_id'");
            $total_like = $like_query->num_rows();
            return array(
                'status' => 201,
                'message' => 'success',
                'like' => '1',
                'total_like' => $total_like
            );
        }
    }
    public function review_comment($user_id, $post_id, $comment)
    {
        date_default_timezone_set('Asia/Kolkata');
        $created_at               = date('Y-m-d H:i:s');
        $labcenter_review_comment = array(
            'user_id' => $user_id,
            'post_id' => $post_id,
            'comment' => $comment,
            'date' => $created_at
        );
        $this->db->insert('labcenter_review_comment', $labcenter_review_comment);
        $labcenter_review_comment_query = $this->db->query("SELECT id from labcenter_review_comment WHERE post_id='$post_id'");
        $total_comment                  = $labcenter_review_comment_query->num_rows();
        return array(
            'status' => 201,
            'message' => 'success',
            'comment' => '1',
            'total_comment' => $total_comment
        );
    }
    public function review_comment_like($user_id, $comment_id)
    {
        date_default_timezone_set('Asia/Kolkata');
        $created_at  = date('Y-m-d H:i:s');
        $count_query = $this->db->query("SELECT id from labcenter_review_comment_like WHERE comment_id='$comment_id' and user_id='$user_id'");
        $count       = $count_query->num_rows();
        if ($count > 0) {
            $this->db->query("DELETE FROM `labcenter_review_comment_like` WHERE user_id='$user_id' and comment_id='$comment_id'");
            $comment_query = $this->db->query("SELECT id from labcenter_review_comment_like where comment_id='$comment_id'");
            $total_comment = $comment_query->num_rows();
            return array(
                'status' => 201,
                'message' => 'deleted',
                'comment_like' => '0',
                'total_comment' => $total_comment
            );
        } else {
            $labcenter_review_comment_like = array(
                'user_id' => $user_id,
                'comment_id' => $comment_id
            );
            $this->db->insert('labcenter_review_comment_like', $labcenter_review_comment_like);
            $comment_query      = $this->db->query("SELECT id from labcenter_review_comment_like where comment_id='$comment_id'");
            $total_comment_like = $comment_query->num_rows();
            return array(
                'status' => 201,
                'message' => 'success',
                'comment_like' => '1',
                'total_comment_like' => $total_comment_like
            );
        }
    }
    public function review_comment_list($user_id, $post_id)
    {
        function get_time_difference_php($created_time)
        {
            date_default_timezone_set('Asia/Calcutta');
            $str            = strtotime($created_time);
            $today          = strtotime(date('Y-m-d H:i:s'));
            $time_differnce = $today - $str;
            $years          = 60 * 60 * 24 * 365;
            $months         = 60 * 60 * 24 * 30;
            $days           = 60 * 60 * 24;
            $hours          = 60 * 60;
            $minutes        = 60;
            if (intval($time_differnce / $years) > 1) {
                return intval($time_differnce / $years) . ' yrs ago';
            } elseif (intval($time_differnce / $years) > 0) {
                return intval($time_differnce / $years) . ' yr ago';
            } elseif (intval($time_differnce / $months) > 1) {
                return intval($time_differnce / $months) . ' months ago';
            } elseif (intval(($time_differnce / $months)) > 0) {
                return intval(($time_differnce / $months)) . ' month ago';
            } elseif (intval(($time_differnce / $days)) > 1) {
                return intval(($time_differnce / $days)) . ' days ago';
            } elseif (intval(($time_differnce / $days)) > 0) {
                return intval(($time_differnce / $days)) . ' day ago';
            } elseif (intval(($time_differnce / $hours)) > 1) {
                return intval(($time_differnce / $hours)) . ' hrs ago';
            } elseif (intval(($time_differnce / $hours)) > 0) {
                return intval(($time_differnce / $hours)) . ' hr ago';
            } elseif (intval(($time_differnce / $minutes)) > 1) {
                return intval(($time_differnce / $minutes)) . ' min ago';
            } elseif (intval(($time_differnce / $minutes)) > 0) {
                return intval(($time_differnce / $minutes)) . ' min ago';
            } elseif (intval(($time_differnce)) > 1) {
                return intval(($time_differnce)) . ' sec ago';
            } else {
                return 'few seconds ago';
            }
        }
        $review_list_count = $this->db->select('id')->from('labcenter_review_comment')->where('post_id', $post_id)->get()->num_rows();
        if ($review_list_count) {
            $query = $this->db->query("SELECT labcenter_review_comment.id,labcenter_review_comment.post_id,labcenter_review_comment.comment as comment,labcenter_review_comment.date,users.name,labcenter_review_comment.user_id as post_user_id FROM labcenter_review_comment INNER JOIN users on users.id=labcenter_review_comment.user_id WHERE labcenter_review_comment.post_id='$post_id' order by labcenter_review_comment.id asc");
            foreach ($query->result_array() as $row) {
                $id      = $row['id'];
                $post_id = $row['post_id'];
                $comment = $row['comment'];
                $comment = preg_replace('~[\r\n]+~', '', $comment);
                if ($id > '3') {
                    $comment_decrypt = $this->decrypt($comment);
                    $comment_encrypt = $this->encrypt($comment_decrypt);
                    if ($comment_encrypt == $comment) {
                        $comment = $comment_decrypt;
                    }
                } else {
                    if (base64_encode(base64_decode($comment)) === $comment) {
                        $comment = base64_decode($comment);
                    }
                }
                $username     = $row['name'];
                $date         = $row['date'];
                $post_user_id = $row['post_user_id'];
                $like_count   = $this->db->select('id')->from('labcenter_review_comment_like')->where('comment_id', $id)->get()->num_rows();
                $like_yes_no  = $this->db->select('id')->from('labcenter_review_comment_like')->where('comment_id', $id)->where('user_id', $user_id)->get()->num_rows();
                $comment_date = get_time_difference_php($date);
                $img_count    = $this->db->select('media.source')->from('media')->join('users', 'users.avatar_id=media.id')->where('users.id', $post_user_id)->get()->num_rows();
                if ($img_count > 0) {
                    $profile_query = $this->db->select('media.source')->from('media')->join('users', 'users.avatar_id=media.id')->where('users.id', $post_user_id)->get()->row();
                    $img_file      = $profile_query->source;
                    $userimage     = 'https://d2c8oti4is0ms3.cloudfront.net/images/healthwall_avatar/' . $img_file;
                } else {
                    $userimage = 'https://d2c8oti4is0ms3.cloudfront.net/images/img/default_user.jpg';
                }
                $date         = get_time_difference_php($date);
                $resultpost[] = array(
                    'id' => $id,
                    'username' => $username,
                    'userimage' => $userimage,
                    'like_count' => $like_count,
                    'like_yes_no' => $like_yes_no,
                    'post_id' => $post_id,
                    'comment' => $comment,
                    'comment_date' => $comment_date
                );
            }
        } else {
            $resultpost = array();
        }
        return $resultpost;
    }
    public function lab_booking($user_id, $listing_id, $address_line1, $address_line2, $package_id, $user_name, $mobile, $email, $gender, $branch_id, $branch_name, $vendor_id, $status, $payment_mode, $trail_booking_date, $trail_booking_time, $joining_date, $booking_location, $booking_address, $booking_mobile,$test_ids, $patient_id, $at_home, $city, $state, $pincode, $address_id,$booking_id){
        date_default_timezone_set('Asia/Kolkata');
        $created_at   = date('Y-m-d H:i:s');
        //$joining_date = date('Y-m-d');
        $query        = $this->db->query("SELECT * FROM booking_master WHERE booking_id = '$booking_id'");
        $count        = $query->num_rows();
        if ($count > 0) {
            $lab_booking = array(
                'user_id' => $user_id,
                'patient_id' => $patient_id,
                'booking_id' => $booking_id,
                'package_id' => $package_id,
                'listing_id' => $listing_id,
                'user_name' => $user_name,
                'user_email' => $email,
                'user_mobile' => $mobile,
                'user_gender' => $gender,
                'branch_id' => $branch_id,
                'vendor_id' => $vendor_id,
                'booking_date' => $created_at,
                'status' => $status,
                'trail_booking_date' => $joining_date,//$trail_booking_date,
                'trail_booking_time' => $trail_booking_time,
                'payment_mode' => $payment_mode,
                'joining_date' => $joining_date,
                'booking_location' => $booking_location,
                'booking_address' => $booking_address,
                'booking_mobile' => $booking_mobile
            );
            $this->db->where('booking_id', $booking_id);
            $rst = $this->db->update('booking_master', $lab_booking);
           
            if($package_id == ''){
         
                if ($test_ids != '') {
                    $Testids = explode(',', $test_ids);
                    foreach ($Testids as $tid) {
                        $test_data = array(
                            'booking_id' => $booking_id,
                            'test_id' => $tid
                        );
                        $this->db->where('booking_id', $booking_id);
                        $this->db->where('test_id', $tid);
                        $rst       = $this->db->update('booking_test', $test_data);
                    }
                }
            }
            
            
            $insertTolabBookingDetails = array(
                'user_id'=> $user_id,
                'patient_id'=> $patient_id,
                'listing_id'=> $listing_id,
                'vendor_type'=> $vendor_id,
                'branch_id'=> $branch_id,
                'branch_name'=> $branch_name,
                'at_home'=> $at_home,
                'address_line1'=> $address_line1,
                'address_line2'=> $address_line2,
                'city'=> $city,
                'state'=> $state,
                'pincode'=> $pincode,
                'mobile_no'=>$mobile ,
                'email_id'=> $email,
                'address_id'=> $address_id,
                'test_id'=> $test_ids,
                'package_id'=> $package_id,
                'booking_date'=> $joining_date,
                'booking_time'=> $trail_booking_time,
                'booking_id'=> $booking_id 
                );
            
            $this->db->where('booking_id', $booking_id);
            $rst_comp         = $this->db->update('lab_booking_details', $insertTolabBookingDetails);    
            
            //////// notification for gcm ***********************************************************************
            //added by jakir on 01-june-2018 for notification on activation 
            $user_plike = $this->db->query("SELECT name FROM users WHERE id='$user_id'");
            $img_count  = $this->db->select('media.source')->from('media')->join('users', 'users.avatar_id=media.id')->where('users.id', $user_id)->get()->num_rows();
            if ($img_count > 0) {
                $profile_query = $this->db->select('media.source')->from('media')->join('users', 'users.avatar_id=media.id')->where('users.id', $user_id)->get()->row();
                $img_file      = $profile_query->source;
                $userimage     = 'https://d2c8oti4is0ms3.cloudfront.net/images/healthwall_avatar/' . $img_file;
            } else {
                $userimage = 'https://d2c8oti4is0ms3.cloudfront.net/images/img/default_user.jpg';
            }
            $getusr               = $user_plike->row_array();
            $usr_name             = $getusr['name'];
            $msg                  = $user_name . ',your package has been booked successfully and Booking Id :' . $booking_id . ' for future reference.';
            $customer_token       = $this->db->query("SELECT token,agent, token_status FROM users WHERE id = '$user_id'");
            $title                = $user_name . ',your package has been booked successfully and Booking Id :' . $booking_id . ' for future reference.';
            $customer_token_count = $customer_token->num_rows();
            if ($customer_token_count > 0) {
                $token_status = $customer_token->row_array();
                $agent        = $token_status['agent'];
                $reg_id       = $token_status['token'];
                $img_url      = $userimage;
                $tag          = 'text';
                $key_count    = '1';
                $this->send_gcm_notify($title, $reg_id, $msg, $img_url, $tag, $agent);
            }
            //end
            ////////////////////***********************************excotel text message user****************************************** 
            $user_info    = $this->db->select('phone,name,token,token_status,agent')->from('users')->where('id', $user_id)->get()->row();
            $token_status = $user_info->token_status;
            $user_phone   = $user_info->phone;
            $user_name    = $user_info->name;
            $message      = $user_name . ', Your package has been booked successfully and Booking Id :' . $booking_id . ' for future reference.';
            $post_data    = array(
                'From' => '02233721563',
                'To' => $user_phone,
                'Body' => $message
            );
            $exotel_sid   = "aegishealthsolutions";
            $exotel_token = "a642d2084294a21f0eed3498414496229958edc5";
            $url          = "https://" . $exotel_sid . ":" . $exotel_token . "@twilix.exotel.in/v1/Accounts/" . $exotel_sid . "/Sms/send";
            $ch           = curl_init();
            curl_setopt($ch, CURLOPT_VERBOSE, 1);
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_FAILONERROR, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_data));
            $http_result = curl_exec($ch);
            curl_close($ch);
            /////////*******************************************excotel text message vendor ***************************************************
            $vendor_info  = $this->db->select('phone,name,token,token_status,agent,web_token')->from('users')->where('id', $listing_id)->get()->row();
            $token_status = $vendor_info->token_status;
            $vendor_phone = $vendor_info->phone;
            $vendor_name  = $vendor_info->name;
            $message      = $vendor_name . ', Your lab package has been booked by patient ' . $user_name .' successfully and Booking Id is ' . $booking_id . ' for future reference.';
            $post_data    = array(
                'From' => '02233721563',
                'To' => $vendor_phone,
                'Body' => $message
            );
            $exotel_sid   = "aegishealthsolutions";
            $exotel_token = "a642d2084294a21f0eed3498414496229958edc5";
            $url          = "https://" . $exotel_sid . ":" . $exotel_token . "@twilix.exotel.in/v1/Accounts/" . $exotel_sid . "/Sms/send";
            $ch           = curl_init();
            curl_setopt($ch, CURLOPT_VERBOSE, 1);
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_FAILONERROR, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_data));
            $http_result = curl_exec($ch);
            curl_close($ch);
            
            // For lab center vendor website firebase push notification by ghanshyam parihar starts :: Added date: 05 Feb 2019
                $web_token      = $vendor_info->web_token;
                $title_web      = $user_name.' has booked an package from '.$vendor_name;
                $img_url        = $userimage;
                // $img_url      = 'https://medicalwale.s3.amazonaws.com/images/img/medical_logo.png';
                $tag            = 'text';
                $agent          = $vendor_info->agent;;
                $connect_type   = 'lab_booking';
                // Web notification FCM function by ghanshyam parihar date:4 Feb 2019
                $click_action = 'https://labs.medicalwale.com/booking_controller/booking_appointment/'.$listing_id;
                // $click_action = 'https://vendor.sandbox.medicalwale.com/labs/booking_controller/booking_appointment/'.$listing_id;
                $this->send_gcm_web_notify($title_web, $message, $web_token, $img_url, $tag, $agent, $connect_type,$click_action);
                // Web notification FCM function by ghanshyam parihar date:4 Feb 2019 Ends
            // For lab center vendor website firebase push notification by ghanshyam parihar ends :: Added date: 05 Feb 2019
            
            if ($rst) {
                return array(
                    'status' => 201,
                    'message' => 'success',
                    'booking_id'=>$booking_id
                );
            }
        } else {
            $lab_booking = array(
                'user_id' => $user_id,
                'patient_id' => $patient_id,
                'booking_id' => $booking_id,
                'package_id' => $package_id,
                'listing_id' => $listing_id,
                'user_name' => $user_name,
                'user_email' => $email,
                'user_mobile' => $mobile,
                'user_gender' => $gender,
                'branch_id' => $branch_id,
                'vendor_id' => $vendor_id,
                'booking_date' => $created_at,
                'status' => $status,
                'trail_booking_date' => $trail_booking_date,
                'trail_booking_time' => $trail_booking_time,
                'payment_mode' => $payment_mode,
                'joining_date' => $joining_date,
                'booking_location' => $booking_location,
                'booking_address' => $booking_address,
                'booking_mobile' => $booking_mobile
            );
            $rst         = $this->db->insert('booking_master', $lab_booking);
            $appointment_id = $this->db->insert_id();
            if($package_id == ''){
                if ($test_ids != '') {
                    $Testids = explode(',', $test_ids);
                    foreach ($Testids as $tid) {
                        $test_data = array(
                            'booking_id' => $booking_id,
                            'test_id' => $tid
                        );
                        $rst       = $this->db->insert('booking_test', $test_data);
                    }
                }
            }
            
            $insertTolabBookingDetails = array(
                'user_id'=> $user_id,
                'patient_id'=> $patient_id,
                'listing_id'=> $listing_id,
                'vendor_type'=> $vendor_id,
                'branch_id'=> $branch_id,
                'branch_name'=> $branch_name,
                'at_home'=> $at_home,
                'address_line1'=> $address_line1,
                'address_line2'=> $address_line2,
                'city'=> $city,
                'state'=> $state,
                'pincode'=> $pincode,
                'mobile_no'=>$mobile ,
                'email_id'=> $email,
                'address_id'=> $address_id,
                'test_id'=> $test_ids,
                'package_id'=> $package_id,
                'booking_date'=> $trail_booking_date,
                'booking_time'=> $trail_booking_time,
                'booking_id'=> $booking_id 
                );
        
            $rst_comp         = $this->db->insert('lab_booking_details', $insertTolabBookingDetails);  
            $this->insert_notification_post_question($user_id, $appointment_id,$listing_id);
            //////// notification for gcm ***********************************************************************
            //added by jakir on 01-june-2018 for notification on activation 
            $user_plike = $this->db->query("SELECT name FROM users WHERE id='$user_id'");
            $img_count  = $this->db->select('media.source')->from('media')->join('users', 'users.avatar_id=media.id')->where('users.id', $user_id)->get()->num_rows();
            if ($img_count > 0) {
                $profile_query = $this->db->select('media.source')->from('media')->join('users', 'users.avatar_id=media.id')->where('users.id', $user_id)->get()->row();
                $img_file      = $profile_query->source;
                $userimage     = 'https://d2c8oti4is0ms3.cloudfront.net/images/healthwall_avatar/' . $img_file;
            } else {
                $userimage = 'https://d2c8oti4is0ms3.cloudfront.net/images/img/default_user.jpg';
            }
            $getusr               = $user_plike->row_array();
            $usr_name             = $getusr['name'];
            $msg                  = $user_name . ',your package has been booked successfully and Booking Id :' . $booking_id . ' for future reference.';
            $customer_token       = $this->db->query("SELECT token,agent, token_status FROM users WHERE id = '$user_id'");
            $title                = $user_name . ',your package has been booked successfully and Booking Id :' . $booking_id . ' for future reference.';
            $customer_token_count = $customer_token->num_rows();
            if ($customer_token_count > 0) {
                $token_status = $customer_token->row_array();
                $agent        = $token_status['agent'];
                $reg_id       = $token_status['token'];
                $img_url      = $userimage;
                $tag          = 'text';
                $key_count    = '1';
                $this->send_gcm_notify($title, $reg_id, $msg, $img_url, $tag, $agent);
            }
            //end
            ////////////////////***********************************excotel text message user****************************************** 
            $user_info    = $this->db->select('phone,name,token,token_status,agent')->from('users')->where('id', $user_id)->get()->row();
            $token_status = $user_info->token_status;
            $user_phone   = $user_info->phone;
            $user_name    = $user_info->name;
            $message      = $user_name . ',your package has been booked successfully and Booking Id :' . $booking_id . ' for future reference.';
            $post_data    = array(
                'From' => '02233721563',
                'To' => $user_phone,
                'Body' => $message
            );
            $exotel_sid   = "aegishealthsolutions";
            $exotel_token = "a642d2084294a21f0eed3498414496229958edc5";
            $url          = "https://" . $exotel_sid . ":" . $exotel_token . "@twilix.exotel.in/v1/Accounts/" . $exotel_sid . "/Sms/send";
            $ch           = curl_init();
            curl_setopt($ch, CURLOPT_VERBOSE, 1);
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_FAILONERROR, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_data));
            $http_result = curl_exec($ch);
            curl_close($ch);
            /////////*******************************************excotel text message vendor ***************************************************
            $vendor_info  = $this->db->select('phone,name,token,token_status,agent,web_token')->from('users')->where('id', $listing_id)->get()->row();
            $token_status = $vendor_info->token_status;
            $vendor_phone = $vendor_info->phone;
            $vendor_name  = $vendor_info->name;
            $message      = $vendor_name . ', Your lab package has been booked by patient ' . $user_name . ' successfully and Booking Id is ' . $booking_id . ' for future reference.';
            $post_data    = array(
                'From' => '02233721563',
                'To' => $vendor_phone,
                'Body' => $message
            );
            $exotel_sid   = "aegishealthsolutions";
            $exotel_token = "a642d2084294a21f0eed3498414496229958edc5";
            $url          = "https://" . $exotel_sid . ":" . $exotel_token . "@twilix.exotel.in/v1/Accounts/" . $exotel_sid . "/Sms/send";
            $ch           = curl_init();
            curl_setopt($ch, CURLOPT_VERBOSE, 1);
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_FAILONERROR, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_data));
            $http_result = curl_exec($ch);
            curl_close($ch);
            
            
            // For lab center vendor website firebase push notification by ghanshyam parihar starts date: 05 Feb 2019
                $web_token      = $vendor_info->web_token;
                $title_web      = $user_name.' has booked an package from '.$vendor_name;
                $img_url        = $userimage;
                // $img_url      = 'https://medicalwale.s3.amazonaws.com/images/img/medical_logo.png';
                $tag            = 'text';
                $agent          = $vendor_info->agent;;
                $connect_type   = 'lab_booking';
                
                // Web notification FCM function by ghanshyam parihar date:4 Feb 2019
                $click_action = 'https://labs.medicalwale.com/booking_controller/booking_appointment/'.$listing_id;
                // $click_action = 'https://vendor.sandbox.medicalwale.com/labs/booking_controller/booking_appointment/'.$listing_id;
                $this->send_gcm_web_notify($title_web, $message, $web_token, $img_url, $tag, $agent, $connect_type,$click_action);
                // Web notification FCM function by ghanshyam parihar date:4 Feb 2019 Ends
            
            // For lab center vendor website firebase push notification by ghanshyam parihar ends date: 05 Feb 2019
            
            if ($rst) {
                return array(
                    'status' => 201,
                    'message' => 'success',
                    'booking_id'=>$booking_id
                );
            }
        }
    }
    
    // Web notification FCM function by ghanshyam parihar date:16 Jan 2019
    function send_gcm_web_notify($title, $msg, $reg_id, $img_url, $tag, $agent, $type,$click_action) {
            date_default_timezone_set('Asia/Kolkata');
            $date = date('j M Y h:i A');
            if (!defined("GOOGLE_GCM_URL"))
                define("GOOGLE_GCM_URL", "https://fcm.googleapis.com/fcm/send");
            $fields = array(
                'to' => $reg_id,
                'priority' => "high",
                $agent === 'android' ? 'notification' : 'notification' => array(
                     "title"=> $title,
                     "body" => $msg,
                     "click_action"=> $click_action,
                     "icon"=> $img_url
                )
            );
            $headers = array(
                GOOGLE_GCM_URL,
                'Content-Type: application/json',
                $agent === 'android' ? 'Authorization: key=AAAASZs-aSM:APA91bEQ0SZFS7YnRRK95O2Jp_PdzVC8t_osgDK0UdWXeQRo06fEedknj2b26yfX_YPkLq85h0lc3hUBlnSSPD1qvfikzFYiHd8tlt7BeuOg3f5WRwQxmz19WbEGbZEX894zZEF5iRO5' : 'Authorization: key=AIzaSyCN1vVES0Jb3zVHeNCYPAMNnPYTl96H1uE'
            );
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, GOOGLE_GCM_URL);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
            $result = curl_exec($ch);
            //print_r($result);
            if ($result === FALSE) {
                die('Problem occurred: ' . curl_error($ch));
            }
            curl_close($ch);
    }
    // Web notification FCM function by ghanshyam parihar date:16 Jan 2019 Ends
    
   public function insert_notification_post_question($user_id, $booking_id, $doctor_id){
      $data = array(
                           'user_id'        => $user_id,
                           'post_id'         => $booking_id,
                           'timeline_id'   => $user_id,
                           'type'          => 'Appointment',
                           'seen'          => '1',
                           'notified_by'   => $doctor_id,
                           'description'   => 'Appointment Booking',
                           'created_at'    => curr_date(),
                           'updated_at'    => curr_date()
                           
                   );
       //print_r($data);
       $this->db->insert("notifications", $data);        if($this->db->affected_rows() > 0)
       {
           
           return true; // to the controller
       }
       else{
           return false;
       }
   }  
    
    
    
    
    
     public function tyrocare_lab_booking($vendor_type, $user_id, $address, $amount, $report_code, $pincode, $bencount, $mobile, $email, $order_by, $service_type, $hc, $ref_code, $reports, $bendataxml, $booking_date, $booking_time, $payment_method, $product, $booking_id, $status,$reference_id,$leadId,$passon){
    
        date_default_timezone_set('Asia/Kolkata');
        $created_at   = date('Y-m-d H:i:s');
       /* echo"SELECT * FROM booking_master WHERE booking_id = '$booking_id'";*/
        $query        = $this->db->query("SELECT * FROM booking_master WHERE booking_id = '$booking_id'");
        $count        = $query->num_rows();
        if ($count > 0) {
            $lab_booking = array(
                'user_id' => $user_id,
                'booking_id' => $booking_id,
                'user_name' => $order_by,
                'user_email' => $email,
                'user_mobile' => $mobile,
                'booking_date' => $created_at,
                'status' => $status,
                'vendor_id' =>$vendor_type,
                'payment_mode' => $payment_method,
                'joining_date' => $booking_date
                
            );
            $this->db->where('booking_id', $booking_id);
            $rst = $this->db->update('booking_master', $lab_booking);
            
            $insertTolabBookingDetails = array(
                'user_id'=> $user_id,
                'amount'=> $amount,
                'report_code'=> $report_code,
                'becount'=> $bencount,
                'hc'=> $hc,
                'ref_code'=> $ref_code,
                'reports'=> $reports,
                'bendataxml'=> $bendataxml,
                'product'=> $product,
                'vendor_type'=> $vendor_type,
                'address_line1'=> $address,
                'address_line2'=>$address ,
                'pincode'=> $pincode,
                'mobile_no'=> $mobile,
                'email_id'=> $email,
                'booking_date'=> $booking_date,
                'booking_time'=> $booking_time,
                'booking_id'=> $booking_id,
                'reference_id' => $reference_id,
                'lead_id' => $leadId,
                'passon'=>$passon
                );
            
            $this->db->where('booking_id', $booking_id);
            $rst_comp         = $this->db->update('lab_booking_details', $insertTolabBookingDetails);    
            
            //////// notification for gcm ***********************************************************************
            //added by jakir on 01-june-2018 for notification on activation 
            
            if($reference_id != '')
          {
            
            $user_plike = $this->db->query("SELECT name FROM users WHERE id='$user_id'");
            $img_count  = $this->db->select('media.source')->from('media')->join('users', 'users.avatar_id=media.id')->where('users.id', $user_id)->get()->num_rows();
            if ($img_count > 0) {
                $profile_query = $this->db->select('media.source')->from('media')->join('users', 'users.avatar_id=media.id')->where('users.id', $user_id)->get()->row();
                $img_file      = $profile_query->source;
                $userimage     = 'https://d2c8oti4is0ms3.cloudfront.net/images/healthwall_avatar/' . $img_file;
            } else {
                $userimage = 'https://d2c8oti4is0ms3.cloudfront.net/images/img/default_user.jpg';
            }
            $getusr               = $user_plike->row_array();
            $usr_name             = $getusr['name'];
            $msg                  = $order_by . ',your package has been booked successfully and Booking Id :' . $booking_id . ' for future reference.';
            $customer_token       = $this->db->query("SELECT token,agent, token_status FROM users WHERE id = '$user_id'");
            $title                = $order_by . ',your package has been booked successfully and Booking Id :' . $booking_id . ' for future reference.';
            $customer_token_count = $customer_token->num_rows();
            if ($customer_token_count > 0) {
                $token_status = $customer_token->row_array();
                $agent        = $token_status['agent'];
                $reg_id       = $token_status['token'];
                $img_url      = $userimage;
                $tag          = 'text';
                $key_count    = '1';
                $this->send_gcm_notify($title, $reg_id, $msg, $img_url, $tag, $agent);
            }
            //end
            ////////////////////***********************************excotel text message user****************************************** 
            $user_info    = $this->db->select('phone,name,token,token_status,agent')->from('users')->where('id', $user_id)->get()->row();
            $token_status = $user_info->token_status;
            $user_phone   = $user_info->phone;
            $user_name    = $user_info->name;
            $message      = $user_name . ',your package has been booked successfully and Booking Id :' . $booking_id . ' for future reference.';
            $post_data    = array(
                'From' => '02233721563',
                'To' => $user_phone,
                'Body' => $message
            );
            $exotel_sid   = "aegishealthsolutions";
            $exotel_token = "a642d2084294a21f0eed3498414496229958edc5";
            $url          = "https://" . $exotel_sid . ":" . $exotel_token . "@twilix.exotel.in/v1/Accounts/" . $exotel_sid . "/Sms/send";
            $ch           = curl_init();
            curl_setopt($ch, CURLOPT_VERBOSE, 1);
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_FAILONERROR, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_data));
            $http_result = curl_exec($ch);
            curl_close($ch);
            
          }
            /////////*******************************************excotel text message vendor ***************************************************
           /* $vendor_info  = $this->db->select('phone,name,token,token_status,agent')->from('users')->where('id', $listing_id)->get()->row();
            $token_status = $vendor_info->token_status;
            $vendor_phone = $vendor_info->phone;
            $vendor_name  = $vendor_info->name;
            $message      = $vendor_name . ',your  lab package has been booked by patient :' . $user_id . 'successfully and Booking Id :' . $booking_id . ' for future reference.';
            $post_data    = array(
                'From' => '02233721563',
                'To' => $vendor_phone,
                'Body' => $message
            );
            $exotel_sid   = "aegishealthsolutions";
            $exotel_token = "a642d2084294a21f0eed3498414496229958edc5";
            $url          = "https://" . $exotel_sid . ":" . $exotel_token . "@twilix.exotel.in/v1/Accounts/" . $exotel_sid . "/Sms/send";
            $ch           = curl_init();
            curl_setopt($ch, CURLOPT_VERBOSE, 1);
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_FAILONERROR, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_data));
            $http_result = curl_exec($ch);
            curl_close($ch);*/
            if ($rst) {
                return array(
                    'status' => 201,
                    'message' => 'success',
                    'booking_id' => $booking_id
                );
            }
        } else {
            $lab_booking = array(
                'user_id' => $user_id,
                'booking_id' => $booking_id,
                'user_name' => $order_by,
                'user_email' => $email,
                'user_mobile' => $mobile,
                'booking_date' => $created_at,
                'status' => $status,
                'vendor_id' =>$vendor_type,
                'payment_mode' => $payment_method,
                'joining_date' => $booking_date
            );
            $rst         = $this->db->insert('booking_master', $lab_booking);
            
           
            
            $insertTolabBookingDetails = array(
                'user_id'=> $user_id,
                'amount'=> $amount,
                'report_code'=> $report_code,
                'becount'=> $bencount,
                'hc'=> $hc,
                'ref_code'=> $ref_code,
                'reports'=> $reports,
                'bendataxml'=> $bendataxml,
                'product'=> $product,
                'vendor_type'=> $vendor_type,
                'address_line1'=> $address,
                'address_line2'=>$address ,
                'pincode'=> $pincode,
                'mobile_no'=> $mobile,
                'email_id'=> $email,
                'booking_date'=> $booking_date,
                'booking_time'=> $booking_time,
                'booking_id'=> $booking_id,
                'reference_id' => $reference_id,
                'lead_id' => $leadId,
                'passon'=>$passon
                );
        
            $rst_comp         = $this->db->insert('lab_booking_details', $insertTolabBookingDetails);    
            //////// notification for gcm ***********************************************************************
            //added by jakir on 01-june-2018 for notification on activation 
          if($reference_id != '')
          {
            $user_plike = $this->db->query("SELECT name FROM users WHERE id='$user_id'");
            $img_count  = $this->db->select('media.source')->from('media')->join('users', 'users.avatar_id=media.id')->where('users.id', $user_id)->get()->num_rows();
            if ($img_count > 0) {
                $profile_query = $this->db->select('media.source')->from('media')->join('users', 'users.avatar_id=media.id')->where('users.id', $user_id)->get()->row();
                $img_file      = $profile_query->source;
                $userimage     = 'https://d2c8oti4is0ms3.cloudfront.net/images/healthwall_avatar/' . $img_file;
            } else {
                $userimage = 'https://d2c8oti4is0ms3.cloudfront.net/images/img/default_user.jpg';
            }
            $getusr               = $user_plike->row_array();
            $usr_name             = $getusr['name'];
            $msg                  = $order_by . ',your package has been booked successfully and Booking Id :' . $booking_id . ' for future reference.';
            $customer_token       = $this->db->query("SELECT token,agent, token_status FROM users WHERE id = '$user_id'");
            $title                = $order_by . ',your package has been booked successfully and Booking Id :' . $booking_id . ' for future reference.';
            $customer_token_count = $customer_token->num_rows();
            if ($customer_token_count > 0) {
                $token_status = $customer_token->row_array();
                $agent        = $token_status['agent'];
                $reg_id       = $token_status['token'];
                $img_url      = $userimage;
                $tag          = 'text';
                $key_count    = '1';
                $this->send_gcm_notify($title, $reg_id, $msg, $img_url, $tag, $agent);
            }
            //end
            ////////////////////***********************************excotel text message user****************************************** 
            $user_info    = $this->db->select('phone,name,token,token_status,agent')->from('users')->where('id', $user_id)->get()->row();
            $token_status = $user_info->token_status;
            $user_phone   = $user_info->phone;
            $user_name    = $user_info->name;
            $message      = $user_name . ',your package has been booked successfully and Booking Id :' . $booking_id . ' for future reference.';
            $post_data    = array(
                'From' => '02233721563',
                'To' => $user_phone,
                'Body' => $message
            );
            $exotel_sid   = "aegishealthsolutions";
            $exotel_token = "a642d2084294a21f0eed3498414496229958edc5";
            $url          = "https://" . $exotel_sid . ":" . $exotel_token . "@twilix.exotel.in/v1/Accounts/" . $exotel_sid . "/Sms/send";
            $ch           = curl_init();
            curl_setopt($ch, CURLOPT_VERBOSE, 1);
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_FAILONERROR, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_data));
            $http_result = curl_exec($ch);
            curl_close($ch);
          }
            /////////*******************************************excotel text message vendor ***************************************************
            /*$vendor_info  = $this->db->select('phone,name,token,token_status,agent')->from('users')->where('id', $listing_id)->get()->row();
            $token_status = $vendor_info->token_status;
            $vendor_phone = $vendor_info->phone;
            $vendor_name  = $vendor_info->name;
            $message      = $vendor_name . ',your  lab package has been booked by patient :' . $user_id . 'successfully and Booking Id :' . $booking_id . ' for future reference.';
            $post_data    = array(
                'From' => '02233721563',
                'To' => $vendor_phone,
                'Body' => $message
            );
            $exotel_sid   = "aegishealthsolutions";
            $exotel_token = "a642d2084294a21f0eed3498414496229958edc5";
            $url          = "https://" . $exotel_sid . ":" . $exotel_token . "@twilix.exotel.in/v1/Accounts/" . $exotel_sid . "/Sms/send";
            $ch           = curl_init();
            curl_setopt($ch, CURLOPT_VERBOSE, 1);
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_FAILONERROR, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_data));
            $http_result = curl_exec($ch);
            curl_close($ch);*/
            
            
            if ($rst) {
                return array(
                    'status' => 201,
                    'message' => 'success',
                    'booking_id' => $booking_id
                );
            }
        }
    }
    
    
    public function send_gcm_notify($title, $reg_id, $msg, $img_url, $tag, $agent){
        date_default_timezone_set('Asia/Kolkata');
        $date = date('j M Y h:i A');
        if (!defined("GOOGLE_GCM_URL"))
            define("GOOGLE_GCM_URL", "https://fcm.googleapis.com/fcm/send");
        $fields  = array(
            'to' => $reg_id,
            'priority' => "high",
            $agent === 'android' ? 'data' : 'notification' => array(
                "title" => $title,
                "message" => $msg,
                "notification_image" => $img_url,
                "tag" => $tag,
                'sound' => 'default',
                "notification_type" => 'thyro_lab_booking',
                "notification_date" => $date
            )
        );
        $headers = array(
            GOOGLE_GCM_URL,
            'Content-Type: application/json',
            $agent === 'android' ? 'Authorization: key=AIzaSyDTr3BzDHKj_6FnUiZXT__VCmamH-_gupM' : 'Authorization: key=AIzaSyCN1vVES0Jb3zVHeNCYPAMNnPYTl96H1uE'
        );
        $ch      = curl_init();
        curl_setopt($ch, CURLOPT_URL, GOOGLE_GCM_URL);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
        $result = curl_exec($ch);
        if ($result === FALSE) {
            die('Problem occurred: ' . curl_error($ch));
        }
        curl_close($ch);
    }
    
    
    public function lab_test_list($user_id, $page){
        $limit = 5;
        $start = 0;
        if ($page > 0) {
            if (!is_numeric($page)) {
                $page = 1;
            }
        }
        $test_in_home_list = array();
        $test_in_lab_list = array();
        $start      = ($page - 1) * $limit;
        $query      = $this->db->query("SELECT * FROM `lab_test_details` WHERE `user_id` = '$user_id'");
        $total_user = $query->num_rows();
        $qRows      = $query->row();
        if ($total_user > 0) {
            //echo "SELECT * FROM `tbl_invoice_attachment` WHERE `invoice_id` = '$qRows->id'";
            $query        = $this->db->query("SELECT * FROM `lab_test_details` WHERE `user_id` = '$user_id' order by id DESC limit $start,$limit");
            $num_count    = $query->num_rows();
            $qRows_attach = $query->result();
            if ($num_count > 0) {
                foreach ($qRows_attach as $test_row) {
                   
                    $user_id        = $test_row->user_id;
                        $test           = $test_row->test;
                        $test_id        = $test_row->test_id;
                        $price          = $test_row->price;
                        $offer          = $test_row->offer;
                        $executive_rate = $test_row->executive_rate;
                        $home_delivery  = $test_row->home_delivery;
                        if ($home_delivery == "0") {
                            $test_in_lab_list[] = array(
                                'user_id' => $user_id,
                                'test_id' => $test_id,
                                'test' => $test,
                                'price' => $price,
                                'offer' => $offer,
                                'executive_rate' => $executive_rate,
                                'home_delivery' => "0"
                            );
                        } else {
                            $test_in_home_list[] = array(
                                'user_id' => $user_id,
                                'test_id' => $test_id,
                                'test' => $test,
                                'price' => $price,
                                'offer' => $offer,
                                'executive_rate' => $executive_rate,
                                'home_delivery' => "1"
                            );
                        }
                }
            } else {
               $test_in_home_list = array();
               $test_in_lab_list = array();
            }
            $tests = array(
                'total' => $total_user,
                'home_test_done' => $test_in_home_list,
                'lab_test_done' => $test_in_lab_list
            );
            return array(
                'status' => 200,
                'message' => 'success',
                'data' => $tests
            );
        } else {
            return array(
                'status' => 201,
                'message' => 'No data found!'
            );
        }
    }
    
    public function lab_booked_list($user_id, $listing_id){
        
        $count_query = $this->db->query("SELECT * from lab_booking_details where user_id='$user_id' and listing_id='$listing_id'");
        $lab_booked       = $count_query->num_rows();
        if ($lab_booked > 0) {
            foreach ($count_query->result_array() as $Lbooked) {
                    
                
                 $Lab_Bkooed_list[] = array(
                    'user_id'=> $Lbooked['user_id'],
                    'patient_id'=> $Lbooked['patient_id'],
                    'listing_id'=> $Lbooked['listing_id'],
                    'vendor_type'=> $Lbooked['vendor_type'],
                    'branch_id'=> $Lbooked['branch_id'],
                    'branch_name'=> $Lbooked['branch_name'],
                    'at_home'=> $Lbooked['at_home'],
                    'address_line1'=> $Lbooked['address_line1'],
                    'address_line2'=> $Lbooked['address_line2'],
                    'city'=> $Lbooked['city'],
                    'state'=> $Lbooked['state'],
                    'pincode'=> $Lbooked['pincode'],
                    'mobile_no'=> $Lbooked['mobile_no'],
                    'email_id'=> $Lbooked['email_id'],
                    'address_id'=> $Lbooked['address_id'],
                    'test_id'=> $Lbooked['test_id'],
                    'package_id'=> $Lbooked['package_id'],
                    'booking_date'=> $Lbooked['booking_date'],
                    'booking_time'=> $Lbooked['booking_time'],
                    'booking_id'=> $Lbooked['booking_id'] 
                );
            }
            return $Lab_Bkooed_list;
        }else{
            return $Lab_Bkooed_list= array();
        }
        
    }
    
    public function tyrocare_booked_list($vendor_type,$userid){
        
        $count_query = $this->db->query("SELECT * from lab_booking_details where vendor_type='$vendor_type' and user_id='$userid' and reference_id!=''");
                $lab_booked       = $count_query->num_rows();
        if ($lab_booked > 0) {
            foreach ($count_query->result_array() as $Lbooked) {
                    
                $uid =$Lbooked['user_id'];    
            $user_query = $this->db->query("SELECT email,phone,name FROM users WHERE id='$uid'");
                $email = $user_query->row()->email;
                $phone = $user_query->row()->phone;
                $user_name = $user_query->row()->name;        
                    
                $bk_id = $Lbooked['booking_id'];   
                /*echo"SELECT status FROM booking_master WHERE booking_id='$bk_id'";*/
            $book_query = $this->db->query("SELECT status FROM booking_master WHERE booking_id='$bk_id'");
            if(sizeof($book_query) > 0){
                $status = $book_query->row()->status;
            } else{
                $status = "";
            }
            
            
            //NAWAZ
            //echo "SELECT report_path FROM reports WHERE booking_id='$bk_id'";
            $report_path ='';
            $book_query_path = $this->db->query("SELECT report_path FROM reports WHERE booking_id='$bk_id'");
            $report_path_count =  $book_query_path->num_rows();;
            if($report_path_count > 0){
                $report_path = $book_query_path->row()->report_path;
            }
            
                      
                    
                $Lab_Bkooed_list[] = array(
                'user_id'=> $Lbooked['user_id'], 
                'user_name'=>$user_name,
                'amount'=> $Lbooked['amount'],
                'report_code'=> $Lbooked['report_code'],
                'becount'=> $Lbooked['becount'],
                'hc'=> $Lbooked['hc'],
                'ref_code'=> $Lbooked['ref_code'],
                'reports'=> $Lbooked['reports'],
                'bendataxml'=> $Lbooked['bendataxml'],
                'product'=> $Lbooked['product'],
                'vendor_type'=> $Lbooked['vendor_type'],
                'address_line1'=> $Lbooked['address_line1'],
                'pincode'=> $Lbooked['pincode'],
                'mobile_no'=> $Lbooked['mobile_no'],
                'email_id'=> $Lbooked['email_id'],
                'booking_date'=> $Lbooked['booking_date'],
                'booking_time'=> $Lbooked['booking_time'],
                'booking_id'=> $Lbooked['booking_id'],
                'reference_id'=> $Lbooked['reference_id'],
                'lead_id'=> $Lbooked['lead_id'],
                'status'=>$status,
                'report_path'=>$report_path
                );
            }
            return $Lab_Bkooed_list;
        }else{
            return $Lab_Bkooed_list= array();
        }
        
    }
    
    
    //to display instruction for perticular test
     public function lab_instruction_details($user_id,$id){
         $query = $this->db->query("SELECT * FROM labs_instruction WHERE id='$id'");
         $query_details = $query->row_array();
          $count = $query->num_rows();
          if($count>0)
          {
                $sample_type = $query_details['sample_type'];
                $test_name   = $query_details['test_name'];
                $instruction = $query_details['instruction'];
                
                $instruction_data = array(
                      'sample_type' => $sample_type,
                      'test_name' => $test_name,
                      'instruction' => $instruction
                    );
                
                return array(
                'status' => 201,
                'message' => 'success',
                'data' => $instruction_data
            );
          }     
          else
          {
               return array(
                'status' => 201,
                'message' => 'success',
                'data' => array()
            );
          }
     }
     
     
       
    //Added by Swapnali 
    public function lab_tests($user_id){
        $result = $this->db->query("SELECT * FROM `lab_all_test`")->result_array();
          return $result;
    }
    
    // lab_vendor_by_test
    public function lab_vendor_by_test1($user_id,$test_id){
        //SELECT * FROM `lab_test_details` LIMIT 10 OFFSET 10

        $testInfo = $this->db->query("SELECT * FROM `lab_all_test` WHERE `id` = '$test_id'")->row_array();
        $testName = $testInfo['test'];
        $results = $this->db->query("SELECT * FROM `lab_test_details` WHERE `test_id` = '$test_id' limit 20")->result_array();
        foreach($results as $r){
            $vendorId = $r['user_id'];
            $vendorInfo = $this->db->query("SELECT * FROM `lab_center` WHERE `is_active` = 1 AND `user_id` = '$vendorId'")->row_array();
            if(!empty($vendorInfo)){
                $r['vendor_info'] = $vendorInfo;
            } else {
                $r['vendor_info'] = (object)[];
            }
            
            $res[] = $r;
        }
        $test['test_name'] = $testName;
        $test['test_available'] = $res;
        
        // print_r($res);
        // die();
        return $test;
    }
    
      public function lab_vendor_by_test($user_id,$test_id,$per_page,$page_no){
        //SELECT * FROM `lab_test_details` LIMIT 10 OFFSET 10
       
            // $image1             = 'https://d2c8oti4is0ms3.cloudfront.net/images/healthwall_avatar/' . $image;
        if($per_page == 0 || $page_no == 0){
            $testInfo = $this->db->query("SELECT * FROM `lab_all_test` WHERE `id` = '$test_id'")->row_array();
            $testName = $testInfo['test'];
            // $results = $this->db->query("SELECT * FROM `lab_test_details` WHERE `test_id` = '$test_id' limit 20")->result_array();
            $results = $this->db->query("SELECT lt.* FROM `lab_test_details` as lt join lab_center as lc on (lt.user_id = lc.user_id ) WHERE lc.`is_active` = 1 AND `test_id` = '$test_id'")->result_array();
            
            foreach($results as $r){
                $vendorId = $r['user_id'];
                $vendorInfo = $this->db->query("SELECT * FROM `lab_center` WHERE `is_active` = 1 AND `user_id` = '$vendorId'")->row_array();
                if(!empty($vendorInfo)){
                    foreach($vendorInfo as $key => $value){
                       if($key == 'profile_pic' ){
                            $vendorInfo[$key] = 'https://d2c8oti4is0ms3.cloudfront.net/images/healthwall_avatar/'.$vendorInfo['profile_pic'] ;
                        }
                    }
                    
                    $r['vendor_info'] = $vendorInfo;
                } else {
                    $r['vendor_info'] = (object)[];
                }
                
                $res[] = $r;
            }
            $test['test_name'] = $testName;
            $test['test_available'] = $res;
        } else {
            $offset = $per_page*($page_no - 1);
            
            $testInfo = $this->db->query("SELECT * FROM `lab_all_test` WHERE `id` = '$test_id'")->row_array();
            $testName = $testInfo['test'];
            // SELECT lt.* FROM `lab_test_details` as lt join lab_center as lc on (lt.user_id = lc.user_id ) WHERE `test_id` = '1' 
            // SELECT count(lt.id) FROM `lab_test_details` as lt join lab_center as lc on (lt.user_id = lc.user_id ) WHERE `test_id` = '1'

            //$results = $this->db->query("SELECT * FROM `lab_test_details` WHERE `test_id` = '$test_id' LIMIT $per_page OFFSET $offset")->result_array();
            // $totalRowCount = $this->db->query("SELECT COUNT(`id`) as count FROM `lab_test_details` WHERE `test_id` = '$test_id'")->row_array();
            
            $results = $this->db->query("SELECT lt.* FROM `lab_test_details` as lt join lab_center as lc on (lt.user_id = lc.user_id ) WHERE lc.`is_active` = 1 AND `test_id` = '$test_id' LIMIT $per_page OFFSET $offset")->result_array();
            $totalRowCount = $this->db->query("SELECT count(lt.id) as count FROM `lab_test_details` as lt join lab_center as lc on (lt.user_id = lc.user_id ) WHERE lc.`is_active` = 1 AND `test_id` = '$test_id'")->row_array();
            
            
            
            $totalData = $totalRowCount['count'];
            $last_page = ceil($totalData/$per_page);
            foreach($results as $r){
                $vendorId = $r['user_id'];
                $vendorInfo = $this->db->query("SELECT * FROM `lab_center` WHERE  `is_active` = 1 AND `user_id` = '$vendorId'")->row_array();
                if(!empty($vendorInfo)){
                     foreach($vendorInfo as $key => $value){
                       if($key == 'profile_pic' ){
                            $vendorInfo[$key] = 'https://d2c8oti4is0ms3.cloudfront.net/images/healthwall_avatar/'.$vendorInfo['profile_pic'] ;
                        }
                    }
                    $r['vendor_info'] = $vendorInfo;
                } else {
                    $r['vendor_info'] = (object)[];
                }
                
                $res[] = $r;
            }
            $test['test_name'] = $testName;
            $test['data_count'] = $totalData;
            $test['per_page'] = $per_page;
            $test['current_page'] = $page_no;
            $test['first_page'] = 1;
            $test['last_page'] = $last_page;
            $test['test_available'] = $res;
        }
       
        return $test;
    }
    
    public function lab_test_by_vendor($vendor_id){
        $data = array();
        $data =  $this->db->query("SELECT * FROM `lab_test_details` WHERE `user_id` = '$vendor_id'")->result_array();
     
        return $data;
    }
    
    public function update_email($user_id,$email){
       $up=$this->db->query("UPDATE users SET email='$email' WHERE id='$user_id'");
       $data=  array(
                'status' => 201,
                'message' => 'success');
        return $data;
    }
    //end  
}




