<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Partnercoupon extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('PartnercouponModel');
    }

    public function index() {
        json_output(400, array(
            'status' => 400,
            'message' => 'Bad request.'
        ));
    }
    
      public function vendor_get_users() {
        $this->load->model('PartnercouponModel');
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array('status' => 400, 'message' => 'Bad request.'));
        } else {
            $check_auth_client = $this->PartnercouponModel->check_auth_client();
            if ($check_auth_client == true) {
                $response = $this->PartnercouponModel->auth();
                if ($response['status'] == 200) {
                  
                    $params = json_decode(file_get_contents('php://input'), TRUE);
                    
                    $vendor_id = $params['vendor_id'];
                    // $user_id = $params['user_id'];
                    // $coupon = $params['coupon'];
                    // if ($vendor_id == "" || $user_id == "" || $coupon == "") {
                    if ($vendor_id == "") {
                        $resp = array('status' => 400, 'message' => 'please enter vendor id');
                    } else {
                       
                        $resp = $this->PartnercouponModel->vendor_get_users($vendor_id);
                    }
                    simple_json_output($resp);
                }
            }
            
        }
    }
}