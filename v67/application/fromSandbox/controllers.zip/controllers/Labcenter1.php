<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Labcenter1 extends CI_Controller {

    public function __construct() {
        parent::__construct();
         $this->load->model('LoginModel');
         $this->load->model('LabcenterModel1');
    }

    public function index() {
        json_output(400, array('status' => 400, 'message' => 'Bad request.'));
    }
    
     //Added by Swapnali 
    public function lab_tests(){ 
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array('status' => 400, 'message' => 'Bad request.'));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $response = $this->LoginModel->auth();
                if ($response['status'] == 200) {
                    $params = json_decode(file_get_contents('php://input'), TRUE);
                    if ($params['user_id'] == "") {
                        $resp = array('status' => 400, 'message' => 'please enter user_id');
                    } else {
                        $user_id = $params['user_id'];
                        $resp = $this->LabcenterModel1->lab_tests($user_id);
                    }
                    json_outputs($resp);
                }
            }
        }
    }
    
    public function lab_vendor_by_test(){ 
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array('status' => 400, 'message' => 'Bad request.'));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $response = $this->LoginModel->auth();
                if ($response['status'] == 200) {
                    $params = json_decode(file_get_contents('php://input'), TRUE);
                    if ($params['user_id'] == "" || $params['test_id'] == "")  {
                        $resp = array('status' => 400, 'message' => 'please enter user_id and test_id');
                    } else {
                        $user_id = $params['user_id'];
                        $test_id = $params['test_id'];
                        
                        
                        if(array_key_exists("per_page",$params)){
                            $per_page = $params['per_page'];
                        } else {
                            $per_page = 0;
                        }
                        
                        if(array_key_exists("page_no",$params)){
                            $page_no = $params['page_no'];
                        } else {
                            $page_no = 0;
                        }
                        $resp = $this->LabcenterModel1->lab_vendor_by_test($user_id,$test_id,$per_page,$page_no);
                    }
                    json_outputs($resp);
                }
            }
        }
    }
    
    public function lab_test_by_vendor(){ 
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method != 'POST') {
            json_output(400, array('status' => 400, 'message' => 'Bad request.'));
        } else {
            $check_auth_client = $this->LoginModel->check_auth_client();
            if ($check_auth_client == true) {
                $response = $this->LoginModel->auth();
                if ($response['status'] == 200) {
                    $params = json_decode(file_get_contents('php://input'), TRUE);
                    if ($params['user_id'] == "" || $params['vendor_id'] == "")  {
                        $resp = array('status' => 400, 'message' => 'please enter user_id and vendor_id');
                    } else {
                        $user_id = $params['user_id'];
                        $vendor_id = $params['vendor_id'];
                       
                        $resp = $this->LabcenterModel1->lab_test_by_vendor($vendor_id);
                    }
                    json_outputs($resp);
                }
            }
        }
    }
}