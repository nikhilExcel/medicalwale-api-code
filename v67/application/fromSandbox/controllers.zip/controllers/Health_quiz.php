<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Health_quiz extends CI_Controller {

	public function __construct()
    {
        parent::__construct();
         $this->load->model('Health_quizModel');
          $this->load->model('LoginModel');
        /*
        $check_auth_client = $this->SexeducationModel->check_auth_client();
		if($check_auth_client != true){
			die($this->output->get_output());
		}
		*/
    }
	public function index()
	{
	    json_output(400,array('status' => 400,'message' => 'Bad request.'));
	}
	
	
	public function Get_all_quizdata()
	{
	       	$method = $_SERVER['REQUEST_METHOD'];
		if($method != 'POST'){
			json_output(400,array('status' => 400,'message' => 'Bad request.'));
		} else {
			$check_auth_client = $this->Health_quizModel->check_auth_client();
			if($check_auth_client == true){
		        $response = $this->LoginModel->auth();
		        if($response['status'] == 200){
					$params = json_decode(file_get_contents('php://input'), TRUE);
					/*print_r($params);
					die();*/
					if ($params['user_id'] == "") {
						$resp = array('status' => 400,'message' =>  'please enter fields');
					} else {
					    $user_id       = $params['user_id'];
					    $test_no       = $params['test_no'];
					 $resp  = $this->Health_quizModel->Get_all_quizdata($user_id,$test_no);
					}
					    simple_json_output($resp);
				
		        }
			}
		}
	}
	
	public function Get_result_data()
	{
	       	$method = $_SERVER['REQUEST_METHOD'];
		if($method != 'POST'){
			json_output(400,array('status' => 400,'message' => 'Bad request.'));
		} else {
			$check_auth_client = $this->Health_quizModel->check_auth_client();
			if($check_auth_client == true){
		        $response = $this->LoginModel->auth();
		        if($response['status'] == 200){
					$params = json_decode(file_get_contents('php://input'), TRUE);
					/*print_r($params);
					die();*/
					if ($params['user_id'] == "") {
						$resp = array('status' => 400,'message' =>  'please enter fields');
					} else {
					    $user_id       = $params['user_id'];
					    $is_winner       = $params['is_winner'];
					    $total_score   = $params['total_score'];
					    $total_question = $params['total_question'];
					    $total_point = $params['total_point'];
					    $opponent_id = $params['opponent_id'];
					   $resp  = $this->Health_quizModel->Get_result_data($user_id,$is_winner,$total_score,$total_question,$total_point,$opponent_id);
					}
					    simple_json_output($resp);
				
		        }
			}
		}
	}
	
	public function Get_all_history()
	{
	       	$method = $_SERVER['REQUEST_METHOD'];
		if($method != 'POST'){
			json_output(400,array('status' => 400,'message' => 'Bad request.'));
		} else {
			$check_auth_client = $this->Health_quizModel->check_auth_client();
			if($check_auth_client == true){
		        $response = $this->LoginModel->auth();
		        if($response['status'] == 200){
					$params = json_decode(file_get_contents('php://input'), TRUE);
					/*print_r($params);
					die();*/
					if ($params['user_id'] == "") {
						$resp = array('status' => 400,'message' =>  'please enter fields');
					} else {
					    $user_id       = $params['user_id'];
					 $resp  = $this->Health_quizModel->Get_all_history($user_id);
					}
					    simple_json_output($resp);
				
		        }
			}
		}
	}
	
	
}